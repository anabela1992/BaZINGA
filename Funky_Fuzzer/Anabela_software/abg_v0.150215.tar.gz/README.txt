=== Anywhere Board Games ===

 Released under LGPL by Robert Buccigrossi
 For more information go to http://anywhereboardgames.com

=== Installation ===

 - Set up a PHP5 instance under Apache
 - Uncompress this directory in your www docs directory
 - Navigate to index.html with IE9/Chrome/Firefox or iPhone, iPad, and Android
 - Click on the background to add a piece (any image URL)

=== NOTE ===
 - Right now the server works by saving a JSON file as /tmp/bgaworld.json .  
   Until we can save and restore board state, free to backup and restore this 
   json file when you like the state of a game.
