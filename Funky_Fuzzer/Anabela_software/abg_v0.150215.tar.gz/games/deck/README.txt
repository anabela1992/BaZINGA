Thanks to Nicu Buculei, the openclipart.org project, and the
commons.wikimedia.org project for this beautiful set of cards.

This deck is released under the Creative Commons
CC0 1.0 Universal Public Domain Dedication.
