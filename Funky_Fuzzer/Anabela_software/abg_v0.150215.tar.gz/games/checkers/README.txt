Thanks to Nicolas Francois for posting a checkboard set on
POV-Ray's forums that became the inspiration (and a wonderful
tutorial) for this set.
