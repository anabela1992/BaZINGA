DROP TABLE IF EXISTS `acp2se`;
CREATE TABLE `acp2se` (
  `ID` text NOT NULL,
  `Version` text NOT NULL,
  `Copy` text NOT NULL
) ENGINE=MyISAM;
INSERT INTO `acp2se` VALUES ('1', '<b>v0.10.2</b>', '� 2007 G.O.C.� - Glenn Ongena Corporation�.</br>� 2007 The Chaser & Kinger7.</br>');

