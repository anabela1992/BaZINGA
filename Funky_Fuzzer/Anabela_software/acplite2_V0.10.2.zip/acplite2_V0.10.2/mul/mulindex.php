<?php
session_start();
if ($_SESSION['login'] != "1")
{
header('Location: mulogin.php');
exit();
}
?>
<html>
<head>
<title>Admin Control Panel 2 Lite</title>
    <link href="main.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor='#000000' text="#FFFFFF">
<?php
	echo "<center><h1>Admin Control Panel <I>Lite</I> 2</h1>";
	echo "<center><u><b>~ Admin Tools ~</u></b>";
	echo "<center><a href=mulsearchu2.php>Admin Tool - User Full Information</a>";
	echo "<center><a href=muladmin.php>Admin Tool - Add new Admin</a>";
	echo "<center><a href=mulpmf.php>Admin Tool - Force users to use PM</a>";
	echo "<center><a href=mulqblock.php>Admin Tool - Quik block/lock user</a>";
	echo "<center><a href=mulqdblock.php>Admin Tool - Quik deblock/unlock user</a></p>";
	echo "<center><u><b>~ Multi Tool ~</u></b>";
	echo "<center>Under Contruction of converting.</p>";
	echo "<center><u><b>~ Cheats ~</u></b>";
	echo "<center><a href=mulcheat4.php>Cheats - Change user postcount</a>";
	echo "<center><a href=mulcheat5.php>Cheats - Change user regdate</a>";
	echo "<center><a href=mulcheat7.php>Cheats - Change user rating</a>";
	echo "<center><a href=mulcheat8.php>Cheats - Change thread viewcount</a>";
?>
<?php
include("../lib/config.inc.php");
mysql_connect("$sqlhost", "$sqluser", "$sqlpassword")or die("cannot connect");
mysql_select_db("$sqldb")or die("cannot select DB");
$sql = 'SELECT * FROM `acp2se` LIMIT 0, 30'; 
$result=mysql_query($sql);

if($result){
	while($row = mysql_fetch_array($result))
	  {
	  echo "</p>";
	  echo "<center>" . $row['Version'] . "</center>"; 
	  echo "<center>" . $row['Copy'] . "</center>";
	  }

	echo "<tr><td bgcolor='#c0c0c0'colspan='5'>&nbsp;</td></tr></table></center>";

}
else {
	echo "</p><b>Instal first the ACP 2 SE information!</br>&copy; 2007 The Chaser - Kinger7</b>";
}
mysql_close();
?>
</body>
</html>