<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Readme</title>
</head>

<body>
<p><br />
  &deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.-&gt;-[Admin Control Panel 2 SE]&lt;-.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;<br />
</p>
<p>[Change Log]<br />
  v0.0.1		First beta - Shows the database<br />
  v0.1-9.1-x	Beta's - No info<br />
  v0.10.2		Latest beta - Shows a list with users that have the same IP's, and the total User list.</p>
<p>v1.0.1-9	First version v1.0.X - No info<br />
  v1.0.10		Latest v1.0.x - You can click on the IP's on the user list, or on the IP checker page to see a list with users with that IP.</p>
<p>v1.1.1		First version v1.1.x - No info<br />
  v1.1.2		Latest v1.1.x - User list and checker with click possibillity added by Md5 hashes.</p>
<p>v1.2.1-4	First version v.1.2.x - No info<br />
  v1.2.5		Latest v1.2.x - Adds a page system for md5/IP user list. you can now sort the users by 100,250,500,1000,10000.</p>
<p>v1.3.1		First and Latest v1.3.x - The pages are protected by a inlog system. You have to log in by username and password.</p>
<p>v1.4.1-3	First version v.1.4.x - No info<br />
  v1.4.4		Latest v1.4.x - Now you can sort the usersname/mail/postcount/IP/Md5 by Alfabet.</p>
<p>v2.0.1		First version v2.0.x - It's possible to use it on all servers that you want. ~ first public release.<br />
  v2.0.2		Bugfix - It's now possible to sort the usersname/mail/postcount/IP/Md5 by Alfabet on the userlist pages to.</p>
<p>v2.1.1		First and Latest version v2.1.x - If you want to change the skin, you just edit layout.css.</p>
<p>v3.0.0		First and Latest v3.0.x - Now its works with all board numbers whitout editing the core files of the Multi Tool Checker</p>
<p>v3.1.1		First and Latest version v3.1.x - Index page added. You can go on every page to the index page. On the index page you can find all links.</p>
<p>v3.2.1		First version v3.2.x - Now its possibel to search data by username<br />
  v3.2.2		Second version v3.2.x - Now its possibel to klik on the IP/Md5 to see if there are users with the same IP/Md5<br />
  v3.2.3		Latest version/Bugfix - All functions are now working with all board numbers.</p>
<p>v3.3.1		First and Latest version v3.3.x - Now its possibel to search data by IP to find all users with that IP.</p>
<p>v3.4.1		First and Latest version v3.4.x - A exstra page for the board's that have the Black Intel Modification installed. If not, this page is not special.</p>
<p>v3.5.1		First and Latest version v3.5.x - Now there is a new userlist page. When you push on the IP, you will see all posts that are maden with that IP. On the page after clicking on a IP, you can click on: postID: to view the post on the board. -|- ThreadID: to view the thread on the board. -|- Username: to view the profile on the board. -|- IP: to view all IP's the user have on the board. -|-</p>
<p>v3.6.1		First version v3.6.x - Now there is a new userlist page. If you click on the username you will see all IP's that that user ever have. If you click on a IP that you see after clicking the username, you can check that IP for recognising it in the registred or posted IP's.</p>
<p>v4.0.0 RC1	First RC of v4.x.x - Preparetion to v4.0.x. A wbb skin is intigrated. Now its not able anymore to just change the skin by editing layout.css. It uses a css of wbb.<br />
  v4.0.0 RC2	Second RC of v4.x.x - New look on index. Its now a Admin Control Panel '2' for you wbb. added cheats for statistics.<br />
  v4.0.0		First and Latest version v.4.0.x - First public release of 'Admin Control Panel 2'.</p>
<p>v4.1.1		First and Latest version v4.1.x - New cheat: Now you can change the users postcount!</p>
<p>v4.2.1		First version v4.2.x - New cheat: Now you can change the users regdate! ~maded for Gruzchic. + Multi Tool: Search User for all IP's<br />
  v4.2.2		Latest version v4.2.x - Bugfix - Index look fixed.</p>
<p>v4.3.1		First version v4.3.x - Added Black Intel Tool; You can read now all Pm's that are stored on your board. *NOTE*If you use this tool, please know that you are maybe doing a violation of the user's privacy.<br />
  v4.3.2		Second version v.4.3.x - Black Intel Tool 'User List' has been changed to 'Passwords'. It is just a change in the index look.<br />
  v4.3.3		Latest version 4.3.x - Bugfix - All functions are now working with all board numbers.</p>
<p>v4.4.1		First version v4.4.x - New cheat, you can change the last registred user on the index stats. ~maded for Gruzchic<br />
  v4.4.2		Second and latest version v4.4.x - Bugfix - Cheats - Index last registrated user is now working.</p>
<p>v4.5.1		First version v4.5.x - New cheat, you can change the rating of a user.<br />
  v4.5.2		Second and latest version v4.5.x - bugfix on index page.</p>
<p>v5.0.0 RC1	First RC of v5.x.x - Preparetion to v5.0.x. CSS style imported again. ACP2 Files have now a main folder in acp folder. First move has been made to intigrate ACP2 in ACP of WBB.<br />
  v5.0.0 RC2	Second RC of v5.x.x - Working RC. Praperations are made for install files.<br />
  v5.0.0 RC3	Third RC of v5.x.x - Plugin in MySQL are maded.<br />
  v5.0.0 RC4	Fourth RC of v5.x.x - Making install files.<br />
  v5.0.0 RC5	Fifth RC of v5.x.x - Try to clear out all dutch to english.<br />
  v5.0.0		First intigration is made. More will be done in the nexst versions. Now the tool is called Admin Control Panel 2 SE.<br />
  v5.0.1		Bugfix - Now the readme has changes to install.<br />
  v5.0.3		Bugfix - It's possible to use it on all servers that you want.<br />
  v5.0.4		Cleared data.</p>
<p>v5.1.0 RC1	First RC of v5.1.x - Making update file and Admin Tool function.<br />
  v5.1.0		Now there is a new section called 'Admin Tools'. The first function is called: User Full Information.</p>
<p>v5.2.0		New tool: Admin Tools ~ Ad new Admin</p>
<p>v5.3.0		New tool: Admin tools ~ Now you can force users to use PM. ~maded for pappy<br />
  v5.3.1		Bug-fix - mulpmf.php index look fixed. ~ Latest version with Black-Intel Control.</p>
<p>*NOTE* On this versions there are now Black Intel modifications.<br />
  If you still want this, you will need to wait on a special edition that will be availibel if you ask.<br />
  This edition will not be able to download on the woltlab.de boards.<br />
  Version v5.3.1 is never released! Use update to v5.3.2-MINUS.</p>
<p>v5.3-MINUS RC	Transported RC of a version of v5.3.x ~killed black intel control<br />
  v5.3-MINUS RC2	Secon trasported RC of a version of v5.3.x ~Making update system to v5.3.2<br />
  v5.3.2-MINUS	Killed Black Intel Tools + Update files ready.</p>
<p>v5.4.0		Added new cheat: Change thread viewcount</p>
<p>v5.5.0		Added new Admin Tool: Quik block/lock user</p>
<p>v5.6.0		Added new Admin Tool: Quik deblock/unlock user<br />
  v5.6.1		Bugfix - index link deblock fixed. || block and deblock tool are working now.<br />
  v5.6.2		Bugix - mulcheat5.php index look fixed.<br />
  [/Change Log]<br />
</p>
<p>[How to update?]<br />
  0) Edit the installes.php in the upload folder and set the mysql data right.<br />
  1) Upload the folder 'mul' into your acp.<br />
  2) Now go to thes link:<br />
  http://*your boards link*/acp/mul/installer/installer.php<br />
  3) Import the file (sql)<br />
  4) Now, delete the whole installer folder.<br />
  [/How to update?]<br />
</p>
<p>[Readme-Install]<br />
  0) Edit the installes.php in the installer folder and set the mysql data right.<br />
  1) Upload all files.<br />
  2) Edit installer_v5.0.0.sql with the right board numbers. if your board has number '2'. Pls edit bb1 to bb2.<br />
  (put 'mul' folder into the 'acp' folder of wbb)<br />
  2) Edit mulcheck.php for the password and username by:<br />
  'admin' =&gt; 'adminpass',<br />
  where admin is the username and adminpass the password.<br />
  You can add easly new users by adding under it:<br />
  'yournewname' =&gt; 'yournewpassword',<br />
  3) Now go to thes link:<br />
  http://*your boards link*/acp/mul/installer/installer.php<br />
  4) Import the file that you want with: Start Install/update.<br />
  5) Now, delete the whole installer folder.<br />
  6) In the WBB ACP, import &quot;taal.lng&quot; and choose overwrite.<br />
</p>
<p>gtz,<br />
  TC<br />
  [/Readme-Install]<br />
</p>
<p>[Readme-Uninstall]<br />
  You will see if it is so far.<br />
  [/Readme-Uninstall]<br />
</p>
<p>[Functions]<br />
  Admin Tool:<br />
  Admin tool - User Full Information ~ With this you can see all data around the user. You see more then the normal wbb acp let you see.<br />
  Admin tool - Ad new Admin ~ With this tool, you can add a new admin if neccesarry! (in case you are hacked.)<br />
  Admin Tool - Force users to use PM ~ With this tool, you force your users to use PM yes or not.<br />
  Admin Tool - Quik block/lock user~ You can block/ban/lock a user fast with just one button.<br />
  Admin Tool - Quik deblock/unlock user~ You can deblock/deban/unlock a user fast with just one button.</p>
<p>Multi Tool:<br />
  Multi Tool - User List for IP ~ See the list of the users and pres on the IP to see users whit that IP.<br />
  Multi Tool - Multi IP Checker ~ See a list of all IP's that multiple users have. Pres the IP to see who.<br />
  Multi Tool - User List for Md5 ~ See the list of the users and pres on the md5 hash to see users whit that md5.<br />
  Multi Tool - Multi Md5 Checker ~ See a list of all md5's that multiple users have. Pres the md5 to see who.<br />
  Multi Tool - User List for Post IP ~ See the list of the users and press the IP. The IP you have pressed is now what you will see whit all posts that have been made with. You can click on: postID: to view the post on the board. -|- ThreadID: to view the thread on the board. -|- Username: to view the profile on the board. -|- IP: to view all IP's the user have on the board.<br />
  Multi Tool - User List for all IP's ~ See the list of the users and press the name to see 2 tables. You wil see now all IP's that user have. click on the left IP to view all users with the same IP as the registered IP. click on the right IP to view all users with the same IP of the IP to made a post.<br />
  Multi Tool - Search User ~ Search by username to view the result and press the IP to view on users that have that IP.<br />
  Multi Tool - Search User by IP ~ Search by IP to view the result and press the IP to view on users that have that IP.<br />
  Multi Tool - Search User for all IP's ~ Search by username to view and control all IP's.</p>
<p>Cheats:<br />
  Cheats - Index thread count ~ Here you can change the total threats display on the index page.<br />
  Cheats - Index post count ~ Here you can change the total posts display on the index page.<br />
  Cheats - Index user count ~ Here you can change the total users display on the index page.<br />
  Cheats - Index last registrated user ~ Here you can change the last registred user on the index stats.<br />
  Cheats - Change user postcount ~ Here you can change the users post count.<br />
  Cheats - Change user regdate ~ Here you can change the users regdate.<br />
  Cheats - Change user rating ~ Here you can change the rating of the user.<br />
  Cheats - Change thread viewcount ~ change the viewcount of a thread.<br />
  [/Functions]</p>
<p>[NOTE]<br />
  #1) This tool may only be used on payed Woltlab Buring Board versions.</p>
<p>#2) Please know that this 'Admin Control Panel 2' is not 100% safe for your board.<br />
  It's always possibel that you can hack in this tool. Better secured login possibillity's are planed.</p>
<p>#3) The block/deblock Admin Tool is just a fast way to block someone.<br />
  pls know that its better to block/deblock someone into the wbb acp.<br />
  [/NOTE]<br />
</p>
<p>&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.-&gt;[Copyright]&lt;-.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg; <br />
  &copy; 2007 G.O.C.&reg; - Glenn Ongena Corporation&reg;.<br />
  &copy; 2007 The Chaser &amp; Kinger7.<br />
  Thanx to RC for teaching new skills<br />
  &deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.-&gt;[/Copyright]&lt;-.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg; <br />
</p>
<p>&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.-&gt;-[/Admin Control Panel 2 SE]&lt;-.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil;.&middot;&deg;&macr;&deg;&middot;.&cedil; </p>
</body>
</html>
