<?php
session_start();
if ($_SESSION['login'] != "1")
{
header('Location: mulogin.php');
exit();
}
?>
<html>
<head>
<title>ACP 2 SESE - Admin Tools</title>
    <link href="main.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor='#000000' text="#FFFFFF">
<?
include("../lib/config.inc.php");
mysql_connect("$sqlhost", "$sqluser", "$sqlpassword")or die("cannot connect");
mysql_select_db("$sqldb")or die("cannot select DB");

if ($_POST['submit'] && $_POST['name']) 
{ 
	$name = $_POST['name'];
	 echo "<center>";
     echo "<form method=\"POST\" action=\"" . $_SERVER['PHP_SELF'] . "\">"; 
     echo "<h1>Add new Admin</h1>";
	 echo "<center><a href=mulindex.php>Admin Control Panel 2 - Index</p></a>";
     echo "<label class=\"addmsg\">Put the name of the new Admin: </label>"; 
     echo "<input type=\"text\" name=\"name\" value=\"" . $_POST['name'] . "\"><br><br>"; 
     echo "<input type=\"submit\" name=\"submit\" value=\"Submit\"></p>"; 
     echo "</form>";
     echo "<center><b>Put a username in this field. That user will be admin.</br>the password to go log in your board will be: <u>Admin</u></b></center></p>"; 
	$sql = "INSERT INTO `bb1_users` (`username`, `password`, `email`, `userposts`, `groupid`, `rankid`, `title`, `regdate`, `lastvisit`, `lastactivity`, `usertext`, `signature`, `icq`, `aim`, `yim`, `msn`, `homepage`, `birthday`, `avatarid`, `gender`, `showemail`, `admincanemail`, `usercanemail`, `invisible`, `usecookies`, `styleid`, `activation`, `blocked`, `daysprune`, `timezoneoffset`, `startweek`, `dateformat`, `timeformat`, `emailnotify`, `buddylist`, `ignorelist`, `receivepm`, `emailonpm`, `pmpopup`, `umaxposts`, `showsignatures`, `showavatars`, `showimages`, `nosessionhash`, `ratingcount`, `ratingpoints`, `threadview`) VALUES 
('$name', 'e3afed0047b08059d0fada10f400c1e5', 'Admin@Admin.com', 0, 1, 1, '', 1182711623, 1182711623, 1182711623, '', '', '0', '', '', '', '', '0000-00-00', 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, '1', 0, 'm-d-Y', 'H:i', 0, '', '', 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0)";  
    $res = mysql_query($sql); 

    if ($res) {
		echo "<table border='1' cellpadding='2' cellspacing='2' width='850'>
		<tr bgcolor='#C0C0C0'>
		<th width='850'>You have added a defauld Admin. His name is: $name .</br> The defauld password will be: <b>Admin</b> </th>	
		</tr>";

		echo "<tr><td bgcolor='#c0c0c0'colspan='1'>&nbsp;</td></tr></table></center>";
	}
    else
	{
    	echo "<p>Could change it. Try Again.</p>"; 
	}
		echo "</center>";
} 
else 
{ 
     if ($_POST['submit']) 
         echo "<p>There's one field you need to fill in. And even that you haven't done.</p>"; 
     
     echo "<center>";
     echo "<form method=\"POST\" action=\"" . $_SERVER['PHP_SELF'] . "\">"; 
     echo "<h1>Add new Admin</h1>";
	 echo "<center><a href=mulindex.php>Admin Control Panel 2 - Index</a></p>";
     echo "<label class=\"addmsg\">Put the name of the new Admin: </label>"; 
     echo "<input type=\"text\" name=\"name\" value=\"" . $_POST['name'] . "\"><br><br>"; 
     echo "<input type=\"submit\" name=\"submit\" value=\"Submit\"></p>"; 
     echo "</form>";
     echo "<center><b>Put a username in this field. That user will be admin.</br>the password to go log in your board will be: <u>Admin</u></b></center></p>"; 
     echo "</center>";
     
} 
?>
<?php
include("../lib/config.inc.php");
mysql_connect("$sqlhost", "$sqluser", "$sqlpassword")or die("cannot connect");
mysql_select_db("$sqldb")or die("cannot select DB");
$sql = 'SELECT * FROM `acp2se` LIMIT 0, 30'; 
$result=mysql_query($sql);

if($result){
	while($row = mysql_fetch_array($result))
	  {
	  echo "</p>";
	  echo "<center>" . $row['Version'] . "</center>"; 
	  echo "<center>" . $row['Copy'] . "</center>";
	  }

	echo "<tr><td bgcolor='#c0c0c0'colspan='5'>&nbsp;</td></tr></table></center>";

}
else {
	echo "</p><b>Instal first the ACP 2 SE information!</br>&copy; 2007 The Chaser - Kinger7</b>";
}
mysql_close();
?>
</body>
</html>