<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="nl" xml:lang="nl">
    <head>
        <title>Loginsystem</title>
        <link href="main.css" rel="stylesheet" type="text/css" />
    </head>
    <body bgcolor="#000000" text="#FFFFFF" link="#FF0000" alink="#FF0000" vlink="#FF0000"><br />

        <form method="post" action="mulcheck.php">
            Username: <input type="text" name="username" size="20" maxlength="20"><br />
            Password: <input type="password" name="wachtwoord" size="20" maxlength="20"><br /><br />
            <input type="submit" value="Log in!" />
        </form><br /><br />

    </body>
</html> 