<?php
session_start();
if ($_SESSION['login'] != "1")
{
header('Location: mulogin.php');
exit();
}
?>
<html>
<head>
<title>ACP 2 SE - Cheats</title>
    <link href="main.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor='#000000' text="#FFFFFF">
<?
include("../lib/config.inc.php");
mysql_connect("$sqlhost", "$sqluser", "$sqlpassword")or die("cannot connect");
mysql_select_db("$sqldb")or die("cannot select DB");

if ($_POST['submit'] && $_POST['name']) 
{ 
	$users = $_POST['name'];
	$posts = $_POST['posts'];
	 echo "<center>";
     echo "<form method=\"POST\" action=\"" . $_SERVER['PHP_SELF'] . "\">"; 
     echo "<h1>Change user postcount</h1>";
	 echo "<center><a href=mulindex.php>Admin Control Panel 2 - Index</p></a>";
	 echo "Pls know that the max post limited is: 16777215.</br>";
     echo "<label class=\"addmsg\">Username:</label>"; 
     echo "<input type=\"text\" name=\"name\" value=\"" . $_POST['name'] . "\"><br><br>";
     echo "<label class=\"addmsg\">Change userposts to:</label>"; 
     echo "<input type=\"text\" name=\"posts\" value=\"" . $_POST['posts'] . "\"><br><br>";  
     echo "<input type=\"submit\" name=\"submit\" value=\"Submit\"></p>"; 
     echo "</form>";
	echo "Changed to: ".$users ;
	$sql = "UPDATE bb".$n."_users SET userposts='$posts' WHERE username='$users'";  
    $res = mysql_query($sql); 

    if ($res) {
		echo "<table border='1' cellpadding='2' cellspacing='2' width='850'>
		<tr bgcolor='#C0C0C0'>
		<th width='850'>You have changed the postcount of the user: $users to: $posts. If you want to undon you actions, go to the ACP of wbb and refresh the postcounts.</th>	
		</tr>";

		echo "<tr><td bgcolor='#c0c0c0'colspan='1'>&nbsp;</td></tr></table></center>";
	}
    else
	{
    	echo "<p>Could change it. Try Again.</p>"; 
	}
		echo "</center>";
} 
else 
{ 
     if ($_POST['submit']) 
         echo "<p>There's one field you need to fill in. And even that you haven't done.</p>"; 
     
     echo "<center>";
     echo "<form method=\"POST\" action=\"" . $_SERVER['PHP_SELF'] . "\">"; 
     echo "<h1>Change user postcount</h1>";
	 echo "<center><a href=mulindex.php>Admin Control Panel 2 - Index</a></p>";
	 echo "Pls know that the max post limited is: 16777215.</br>";
     echo "<label class=\"addmsg\">Username:</label>"; 
     echo "<input type=\"text\" name=\"name\" value=\"" . $_POST['name'] . "\"><br><br>"; 
     echo "<label class=\"addmsg\">Change userposts to:</label>"; 
     echo "<input type=\"text\" name=\"posts\" value=\"" . $_POST['posts'] . "\"><br><br>";  
     echo "<input type=\"submit\" name=\"submit\" value=\"Submit\"></p>"; 
     echo "</form>";
     echo "</center>";
     
} 
?>
<?php
include("../lib/config.inc.php");
mysql_connect("$sqlhost", "$sqluser", "$sqlpassword")or die("cannot connect");
mysql_select_db("$sqldb")or die("cannot select DB");
$sql = 'SELECT * FROM `acp2se` LIMIT 0, 30'; 
$result=mysql_query($sql);

if($result){
	while($row = mysql_fetch_array($result))
	  {
	  echo "</p>";
	  echo "<center>" . $row['Version'] . "</center>"; 
	  echo "<center>" . $row['Copy'] . "</center>";
	  }

	echo "<tr><td bgcolor='#c0c0c0'colspan='5'>&nbsp;</td></tr></table></center>";

}
else {
	echo "</p><b>Instal first the ACP 2 SE information!</br>&copy; 2007 The Chaser - Kinger7</b>";
}
mysql_close();
?>
</body>
</html>