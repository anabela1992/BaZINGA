<?php
session_start();
if ($_SESSION['login'] != "1")
{
header('Location: mulogin.php');
exit();
}
?>
<html>
<head>
<title>ACP 2 SE - Admin Tools</title>
    <link href="main.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor='#000000' text="#FFFFFF">
<?
include("../lib/config.inc.php");
mysql_connect("$sqlhost", "$sqluser", "$sqlpassword")or die("cannot connect");
mysql_select_db("$sqldb")or die("cannot select DB");

if ($_POST['submit'] && $_POST['name']) 
{ 
	$username = $_POST['name'];
	 echo "<center>";
     echo "<form method=\"POST\" action=\"" . $_SERVER['PHP_SELF'] . "\">"; 
     echo "<h1>User Full Information</h1>";
	 echo "<center><a href=mulindex.php>Admin Control Panel 2 - Index</p></a>";
     echo "<label class=\"addmsg\">Username: </label>"; 
     echo "<input type=\"text\" name=\"name\" value=\"" . $_POST['name'] . "\"><br><br>"; 
     echo "<input type=\"submit\" name=\"submit\" value=\"Search\"></p>"; 
     echo "</form>";
	 echo "<b>0 means mostly NO</br>1 means mosly YES<br>If a field is empy, its not filled in.</b></p>";
	$sql = "SELECT * FROM bb".$n."_users WHERE username = '$username'";  
    $res = mysql_query($sql); 
    if ($res) {
		while($row = mysql_fetch_array($res))
		  {
			echo "<table border='1' cellpadding='2' cellspacing='2' width='800'>
<tr><td bgcolor='#c0c0c0'colspan='5'>&nbsp;</td></tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>ID:</th><td height='15'>" . $row['userid'] . "</td> </tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Name:</th><td height='15'>" . $row['username'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Password MD5:</th><td height='15'>" . $row['password'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Email:</th><td height='15'>" . $row['email'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Posts:</th><td height='15'>" . $row['userposts'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Group Combination ID:</th><td height='15'>" . $row['groupid'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Rank ID:</th><td height='15'>" . $row['rankid'] . "</td>
</tr>
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>User titel:</th><td height='15'>" . $row['title'] . "</td>
</tr>
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Registration date:</th><td height='15'>" . $row['regdate'] . "</td>
</tr>
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Lastvisit:</th><td height='15'>" . $row['lastvisit'] . "</td>
</tr>
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Laatst actief:</th><td height='15'>" . $row['lastactivity'] . "</td>
</tr>
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>User Text:</th><td height='15'>" . $row['usertext'] . "</td>
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Signature:</th><td height='15'>" . $row['signature'] . "</td>
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>ICQ:</th><td height='15'>" . $row['icq'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>AIM:</th><td height='15'>" . $row['aim'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>YIM:</th><td height='15'>" . $row['yim'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>MSN:</th><td height='15'>" . $row['msn'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Homepage:</th><td height='15'>" . $row['homepage'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Birthday:</th><td height='15'>" . $row['birthday'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Avatar ID:</th><td height='15'>" . $row['avatarid'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Gender:</th><td height='15'>" . $row['gender'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Showemail:</th><td height='15'>" . $row['showemail'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Admin can mail:</th><td height='15'>" . $row['admincanemail'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>User can mail:</th><td height='15'>" . $row['usercanemail'] . "</td></tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Ghost:</th><td height='15'>" . $row['invisible'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Auto login:</th><td height='15'>" . $row['usecookies'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Style ID:</th><td height='15'>" . $row['styleid'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Activation:</th><td height='15'>" . $row['activation'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Blocked:</th><td height='15'>" . $row['blocked'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Daysprune:</th><td height='15'>" . $row['daysprune'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Time zone offset:</th><td height='15'>" . $row['timezoneoffset'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Start week on:</th><td height='15'>" . $row['startweek'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Date format:</th><td height='15'>" . $row['dateformat'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Time format:</th><td height='15'>" . $row['timeformat'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Email notification:</th><td height='15'>" . $row['emailnotify'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Buddylist:</th><td height='15'>" . $row['buddylist'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Ignorlist:</th><td height='15'>" . $row['ignorelist'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Allow PM:</th><td height='15'>" . $row['receivepm'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Email by new PM:</th><td height='15'>" . $row['emailonpm'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Popup by new PM:</th><td height='15'>" . $row['pmpopup'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Users max posts per page:</th><td height='15'>" . $row['umaxposts'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Show signature to user:</th><td height='15'>" . $row['showsignatures'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Show avatare to user:</th><td height='15'>" . $row['showavatars'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Show images to user:</th><td height='15'>" . $row['showimages'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>nosessionhash:</th><td height='15'>" . $row['nosessionhash'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>User rating votes:</th><td height='15'>" . $row['ratingcount'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>User rating points:</th><td height='15'>" . $row['ratingpoints'] . "</td> 
</tr>
<tr>
<th width='200' bgcolor='#C0C0C0'>Threadview:</th><td height='15'>" . $row['threadview'] . "</td> 
</tr>



			<tr><td bgcolor='#c0c0c0'colspan='5'>&nbsp;</td></tr></table></center>";
		  }
	}
    else
	{
    	echo "<p>Couldn't find user. Try Again.</p>"; 
	}
		echo "</center>";
} 
else 
{ 
     if ($_POST['submit']) 
         echo "<p>There's one field you need to fill in. And even that you haven't done.</p>"; 
     
     echo "<center>";
     echo "<form method=\"POST\" action=\"" . $_SERVER['PHP_SELF'] . "\">"; 
     echo "<h1>User Full Information</h1>";
	 echo "<center><a href=mulindex.php>Admin Control Panel 2 - Index</a></p>";
     echo "<label class=\"addmsg\">Username: </label>"; 
     echo "<input type=\"text\" name=\"name\" value=\"" . $_POST['name'] . "\"><br><br>"; 
     echo "<input type=\"submit\" name=\"submit\" value=\"Search\"></p>"; 
     echo "</form>";
     echo "</center>";
     
} 
?>
<?php
include("../lib/config.inc.php");
mysql_connect("$sqlhost", "$sqluser", "$sqlpassword")or die("cannot connect");
mysql_select_db("$sqldb")or die("cannot select DB");
$sql = 'SELECT * FROM `acp2se` LIMIT 0, 30'; 
$result=mysql_query($sql);

if($result){
	while($row = mysql_fetch_array($result))
	  {
	  echo "</p>";
	  echo "<center>" . $row['Version'] . "</center>"; 
	  echo "<center>" . $row['Copy'] . "</center>";
	  }

	echo "<tr><td bgcolor='#c0c0c0'colspan='5'>&nbsp;</td></tr></table></center>";

}
else {
	echo "</p><b>Instal first the ACP 2 SE information!</br>&copy; 2007 The Chaser - Kinger7</b>";
}
mysql_close();
?>
</body>
</html>