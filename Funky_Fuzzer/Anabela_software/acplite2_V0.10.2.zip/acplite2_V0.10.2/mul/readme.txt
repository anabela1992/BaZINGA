
��.�.�����.�.�����.�.�����.�.�����.�.->-[Admin Control Panel Lite 2]<-.�.�����.�.�����.�.�����.�.�����.�.��


[Change Log]
v0.0.0		BETA - Imported ACP 2 SE
v0.0.1		BETA - Edited sql for ACP Lite 2
v0.0.2		BETA - Added css for ACP Lite 2 and installer
v0.0.3		BETA - Testing and editing Admin Tools
v0.1.0		BETA - Converted: Admin Tool - User Full Information
v0.2.0		BETA - converted: Admin Tool - Add new Admin
v0.3.0		BETA - converted: Admin Tool - Force users to use PM
v0.4.0		BETA - converted: Admin Tool - Admin Tool - Quik block/lock user
v0.5.0		BETA - converted: Admin Tool - Admin Tool - Quik deblock/unlock user
v0.6.0		BETA - converted: Cheats - Change user postcount
v0.7.0		BETA - converted: Cheats - Change user regdate
v0.8.0		BETA - converted: Cheats - Change user rating
v0.9.0		BETA - converted: Cheats - Change thread viewcount
v0.10.0		BETA - Fixed index and maded all work
v0.10.1		BETA - First public release
[/Change Log]


[How to update?]
1) Upload the folder 'mul' into your acp.
2) Now go to this link:
http://*your boards link*/acp/mul/installer/installer.php
3) Import the file that you want.
4) Now, delete the whole installer folder.
[/How to update?]


[Readme-Install]
1) Edit sql's from:
mul/installer/
with the right board numbers. if your board has number '2'. Pls edit bb1 to bb2.
2) Upload folder 'mul' into your 'acp' folder.
3) Edit mulcheck.php for the password and username by:
'admin' => 'adminpass',
where admin is the username and adminpass the password.
You can add easly new users by adding under it:
'yournewname' => 'yournewpassword',
4) Now go to thes link:
http://*your boards link*/acp/mul/installer/installer.php
4) Import the file that you want with: Start Install/update/uninstall.
5) Now, delete the whole installer folder.
You can acces the ACP 2 Lite under:
http://*your boards link*/acp/mul/mulindex.php


gtz,
TC
[/Readme-Install]


[Functions]
Admin Tool:
Admin tool - User Full Information ~ With this you can see all data around the user. You see more then the normal wbb acp let you see.
Admin tool - Ad new Admin ~ With this tool, you can add a new admin if neccesarry! (in case you are hacked.)
Admin Tool - Force users to use PM ~ With this tool, you force your users to use PM yes or not.
Admin Tool - Quik block/lock user~ You can block/ban/lock a user fast with just one button.
Admin Tool - Quik deblock/unlock user~ You can deblock/deban/unlock a user fast with just one button.

Cheats:
Cheats - Change user postcount ~ Here you can change the users post count.
Cheats - Change user regdate ~ Here you can change the users regdate.
Cheats - Change user rating ~ Here you can change the rating of the user.
Cheats - Change thread viewcount ~ change the viewcount of a thread.
[/Functions]

[NOTE]
#1) This tool may only be used on payed Woltlab Buring Board Lite versions.

#2) Please know that this 'Admin Control Panel 2' is not 100% safe for your board.
It's always possibel that you can hack in this tool. Better secured login possibillity's are planed.

#3) The block/deblock Admin Tool is just a fast way to block someone.
pls know that its better to block/deblock someone into the wbb acp.

#4) We have seen that there are logs into the mysql database that you can't see into the light version.
We will work to special functions into the ACP Lite 2 that you can view them.
[/NOTE]

[thnx for skills]
[/thnx for skills]

��.�.�����.�.�����.�.->[Copyright]<-.�.�����.�.�����.�.�� 
� 2007 G.O.C.� - Glenn Ongena Corporation�.
� 2007 The Chaser & Kinger7.
��.�.�����.�.�����.�.->[/Copyright]<-.�.�����.�.�����.�.�� 


��.�.�����.�.�����.�.�����.�.�����.�.->-[/Admin Control Panel Lite 2]<-.�.�����.�.�����.�.�����.�.�����.� 