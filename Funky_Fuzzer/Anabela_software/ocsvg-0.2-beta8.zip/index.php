<?php
// Init owncloud
if(!class_exists('OC')) {
	try {
		// OC < 4
		include_once('../../lib/base.php');
	} catch(Exception $e) {
		// OC >= 4
		require_once('lib/base.php');
	}
}
OC_Util::checkLoggedIn();
OC_Util::checkAppEnabled('files_svgedit');
// load required style sheets:
OC_Util::addStyle('files_svgedit', 'ocsvg');
$v = OC_Util::getVersion();
if($v[0] < 4) {
    OC_Util::addStyle('files_svgedit', 'ocsvg.oc3');
} else {
    OC_Util::addStyle('files_svgedit', 'ocsvg.oc4');
}
// load required javascripts:
OC_Util::addScript('files_svgedit', 'svg-edit/embedapi');
OC_Util::addScript('files_svgedit', 'ocsvgEditor');
OC_Util::addScript('files_svgedit', 'canvg/canvg');
OC_Util::addScript('files_svgedit', 'canvg/rgbcolor');
OC_Util::addScript('files_svgedit', 'base64');
//OC_Util::addScript('files_svgedit', 'jsPDF/libs/sprintf');
//OC_Util::addScript('files_svgedit', 'jsPDF/jspdf');
OC_Util::addScript('files_svgedit', 'jsPDF/jspdf.min');
OC_Util::addScript('files_svgedit', 'svgToPdf');
OC_App::setActiveNavigationEntry('files_index');
$path = $_GET['file'];
if(method_exists('OC_Filesystem', 'is_writable')) {
	$writable = OC_Filesystem::is_writable($path);
} else {
	$writable = OC_Filesystem::is_writeable($path);
}
if(isset($_GET['file']) and $writable) {
    $filecontents = OC_Filesystem::file_get_contents($path);
    $filemtime = OC_Filesystem::filemtime($path);
} else {
    $filecontents = "";
    $filemtime = 0;
}
    
$tmpl = new OC_TEMPLATE( "files_svgedit", "editor", "user" );
$tmpl->assign('fileContents', json_encode($filecontents), false);
$tmpl->assign('filemTime', $filemtime, false);
$tmpl->assign('filePath', json_encode($path), false);
$tmpl->printPage();
?>
