<?php
	/*
		divine 0.1.3alpha
		divine.php
	*/	
	
	define('DIVINE_HOST', 'YOUR HOST HERE', true);
	define('DIVINE_USER', 'YOUR USER HERE', true);
	define('DIVINE_PASS', 'YOUR PASSWORD HERE', true);
	define('DIVINE_DB', 'YOUR DATABASE HERE', true);
	define('DIVINE_DOMAIN', 'YOUR DOMAIN HERE', true);
	define('DIVINE_PATH', '/', true);
	define('DIVINE_COOKIE', 'divine', true);
	
	class divine_database {
		var $link;
		var $host;
		var $user;
		var $password;
		var $name;
		
		function __divine_database($h=NULL,$u=NULL,$p=NULL,$n=NULL)
		{
			if($h){
				$this->Connect($h,$u,$p,$n);
			} else {
				$this->Connect();
			}
		}
		
		function divine_database($h=NULL,$u=NULL,$p=NULL,$n=NULL)
		{
			$this->__divine_database($h,$u,$p,$n);
		}
		
		function Connect($h=DIVINE_HOST,$u=DIVINE_USER,$p=DIVINE_PASS,$n=DIVINE_DB)
		{
			$this->link = mysql_connect($h,$u,$p);
			if(!$this->link || !mysql_select_db($n, $this->link)){
				echo 'Could not connect to divine database!';
			}
		}
		
		function Execute($q)
		{
			if(!$this->link){
				$this->Connect();
			}
			return mysql_query($q, $this->link);
		}
		
		function GetRow($r=NULL,$q=NULL)
		{
			if($r){
				return mysql_fetch_array($r);
			} else {
				if(($r = $this->Execute($q)) !== false){
					return mysql_fetch_array($r);
				} else {
					return false;
				}
			}
		}
		
		function GetObject($class, $id)
		{
			return $this->GetRow(NULL, "SELECT * FROM `$class` WHERE `id` = '$id'");
		}
		
		function GetSelectValue($q, $data)
		{
			$tmp = $this->GetRow(NULL, $q);
			return $tmp[$data];
		}
		
		function NumRows($query)
		{
			return mysql_num_rows($this->Execute($query));
		}
		
		function SaveObject($class, $id = NULL)
		{
			$tmp = get_class_vars(get_class($class));
			foreach($tmp as $k => $v){
				$tmp[$k] = $class->$k;
			}
			if($id){
				$q = $this->CreateQuery(get_class($class), $tmp, 'update', "`id` = '$id'");
			} else if($class->id){
				$q = $this->CreateQuery(get_class($class), $tmp, 'update', "`id` = '$class->id'");
			} else {
				$q = $this->CreateQuery(get_class($class), $tmp, 'insert');
			}
			return $this->Execute($q);
		}
		
		function PrepareInput($string){
    		return addslashes($string);
  		}
		
		function CreateQuery($table, $data, $action = 'insert', $parameters = '') {
			if(is_array($data)){
				reset($data);
			}
			if ($action == 'insert') {
				$query = 'INSERT INTO `' . $table . '` (';
				while (list($columns, ) = each($data)) {
					$query .= '`' . $columns . '`, ';
				}
      			$query = substr($query, 0, -2) . ') VALUES (';
      			reset($data);
      			while (list(, $value) = each($data)) {
        			switch ((string)$value) {
          			case 'now()':
            			$query .= 'now(), ';
            			break;
          			case 'null':
            			$query .= 'null, ';
        	    		break;
        	  		default:
        	    		$query .= '\'' . $this->PrepareInput($value) . '\', ';
        	    		break;
        			}
      			}
      			$query = substr($query, 0, -2) . ')';
    		} elseif ($action == 'update') {
      			$query = 'UPDATE `' . $table . '` SET ';
      			while (list($columns, $value) = each($data)) {
        			switch ((string)$value) {
        	  		case 'now()':
        	    		$query .= '`' . $columns. '` = now(), ';
        	    		break;
        	  		case 'null':
        	    		$query .= '`' . $columns .= '` = null, ';
        	    		break;
        	  		default:
        	    		$query .= '`' . $columns . '` = \'' . $this->PrepareInput($value) . '\', ';
        	    		break;
        			}
      			}
      			$query = substr($query, 0, -2) . ' WHERE ' . $parameters;
    		} elseif($action == 'drop'){
    			$query = 'DROP `' . $table . '` WHERE ' . $parameters;
    		} elseif($action == 'delete'){
    			$query = 'DELETE FROM `' . $table . '` WHERE ' . $parameters;
    		}
			return $query;
  		}
		
		function Disconnect()
		{
			if($this->link){
				mysql_close($this->link);
			}
		}
	}
	
	class divine_object {
		var $id;
		
		function __divine_object ($id = NULL)
		{
			global $db;
			
			if($id){
				$tmp = $db->GetObject(get_class($this), $id);
				if($tmp == false){
					$this->id = false;
					return false;
				}
				foreach($tmp as $k => $v){
					$this->$k = $v;
				}
			}
		}
		
		function divine_object ($id = NULL)
		{
			if($id){
				$this->__divine_object($id);
			}
		}
		
		function save($id = NULL)
		{
			global $db;
			
			if($id){
				$db->SaveObject($this, $id);
			} else {
				$db->SaveObject($this);
			}
		}
		
		function delete($id = NULL)
		{
			global $db;
			
			$class = get_class($this);
			if($id){
				$db->Execute("DELETE FROM `$class` WHERE `id` = '$id'");
			} else if($this->id) {
				$db->Execute("DELETE FROM `$class` WHERE `id` = '$this->id'");
			}
		}
	}
	
	class divine_user extends divine_object {
		var $username;
		var $password;
		var $email;
		var $registered;
		var $avatar;
		var $info;
	}
	
	class divine_xml {
		var $xml;
		
		function __divine_xml ($data=NULL)
		{
			if($data){
				$this->encode($data);
			}
		}
		
		function divine_xml($data=NULL)
		{
			if($data){
				$this->__divine_xml($data);
			}
		}
		
		function encode($data, $cname = '')
		{
			if(is_array($data)){
				$tmp = $data;
				$class = $cname;
			} else {
				$class = get_class($data);
				$tmp = get_class_vars($class);
			}
			$this->xml = '<?xml version="1.0" ?>' . "\r\n" . '<' . $class . ' id="' . $class . '">' . "\r\n";
			foreach($tmp as $k => $v){
				switch($k){
					case 'id':
					case 'html':
						break;
						
					case 'title':
					case 'content':
						$this->xml .= '<' . $k . ' id="' . $k . '">' . htmlentities($data->$k) . '</' . $k . '>' . "\r\n";
						break;
						
					default:
						$this->xml .= '<' . $k . ' id="' . $k . '">' . $data->$k . '</' . $k . '>' . "\r\n";
						break;
				}
			}
			$this->xml .= '</' . $class . '>';
		}
		
		function output()
		{
			header('Content-type: text/xml');
			echo $this->xml;
		}
	}
	
	class divine_error {
		var $type;
		var $style;
		var $msg;
		
		function __divine_error($message,$type='error',$style='color: red; font-size: 12px; font-weight: bold;',$now=true)
		{
			$this->type = $type;
			$this->style = $style;
			$this->msg = $message;
			if($now==true){
				$this->output();
			}
		}
		
		function divine_error($message,$type='error',$style='color: red; font-size: 12px; font-weight: bold;',$now=true)
		{
			$this->__divine_error($message,$type,$style,$now);
		}
		
		function output()
		{
			$d = new divine_xml($this);
			$d->output();
		}
	}
	
	$db = new divine_database();
?>