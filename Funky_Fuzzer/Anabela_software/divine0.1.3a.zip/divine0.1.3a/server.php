<?php
	/*
		divine 0.1.3a
		server.php
		
		This files serves the MySQL and filesystem response in either plaintext or XML format
		to the divine AJAX system.
		
		It recieves the requests through either GET ($_REQUEST) or POST ($_POST) format.
		
		The requests are as follows:
		
		server.php?action=. . .
			
			Action:			Returns:
			
			getFiles:		xml
				path =(path to get files from in filesystem)
			
			getFolder:		xml
				path =(path to get folder contents in filesystem)
	*/
	
	require('divine.php');
	
	if($_REQUEST['action']){
		switch($_REQUEST['action']){
			
			case 'getFiles':
				$dir = opendir($_REQUEST['path']);
				if(!$dir){
					$error = new divine_error('Path not found!');
					break;
				} else {
					$output = '<?xml version=\'1.0\' encoding=\'utf-8\' ?>' . "\r\n" . '<getFilesResponse path="' . $_REQUEST['path'] . '">';
					while(($file = readdir($dir)) !== false){
						if($file == '..' || $file == '.'){
							continue;
						} else {
							$t = strtolower($file);
							if(is_dir($_REQUEST['path'] . '/' . $file)){
								$type = 'folder';
							} else {
								if(strpos($t, '.png') || strpos($t, '.jpg') || strpos($t, '.gif')){
									$type = 'image';
								} else if(strpos($t, '.doc') || strpos($t, '.rtf')){
									$type = 'document';
								} else if(strpos($t, '.htm')){
									$type = 'html';
								} else if(strpos($t, '.mov') || strpos($t, '.wmv') || strpos($t, '.mpg') || strpos($t, '.rm')){
									$type = 'video';
								} else if(strpos($t, '.mp3') || strpos($t, '.wma') || strpos($t, '.wav') || strpos($t, '.mid')){
									$type = 'audio';
								} else if(strpos($t, '.txt')){
									$type = 'text';
								} else {
									$type = 'file';
								}
							}
							if($type == 'image'){
								list($w, $h) = getimagesize($_REQUEST['path'] . '/' . $file);
								$extra = ' width="' . $w . '" height="' . $h . '"';
							} else {
								$extra = '';
							}
							$output .=  "\r\n" . '<file type="' . $type . '"' . $extra . '>' . $file . '</file>';
						}
					}
					$output .=  "\r\n" . '</getFilesResponse>';
					header('Content-type: text/xml');
					echo $output;
				}
				break;
			
			case 'getFolder':
				$dir = opendir($_REQUEST['path']);
				if(!$dir){
					$error = new divine_error('Path not found!');
					break;
				} else {
					$output = '<?xml version=\'1.0\' encoding=\'utf-8\' ?>' . "\r\n" . '<getFolderResponse path="' . $_REQUEST['path'] . '">';
					while(($file = readdir($dir)) !== false){
						if($file == '..' || $file == '.'){
							continue;
						} else {
							$t = strtolower($file);
							if(is_dir($_REQUEST['path'] . '/' . $file)){
								$type = 'folder';
							} else {
								if(strpos($t, '.png') || strpos($t, '.jpg') || strpos($t, '.gif')){
									$type = 'image';
								} else if(strpos($t, '.doc') || strpos($t, '.rtf')){
									$type = 'document';
								} else if(strpos($t, '.htm')){
									$type = 'html';
								} else if(strpos($t, '.mov') || strpos($t, '.wmv') || strpos($t, '.mpg') || strpos($t, '.rm')){
									$type = 'video';
								} else if(strpos($t, '.mp3') || strpos($t, '.wma') || strpos($t, '.wav') || strpos($t, '.mid')){
									$type = 'audio';
								} else if(strpos($t, '.txt')){
									$type = 'text';
								} else {
									$type = 'file';
								}
							}
							if($type == 'image'){
								list($w, $h) = getimagesize($_REQUEST['path'] . '/' . $file);
								$extra = ' width="' . $w . '" height="' . $h . '"';
							} else {
								$extra = '';
							}
							$output .=  "\r\n" . '<file type="' . $type . '"' . $extra . '>' . $file . '</file>';
						}
					}
					$output .=  "\r\n" . '</getFolderResponse>';
					header('Content-type: text/xml');
					echo $output;
				}
				break;
			
			case 'getFile':
				$content = file_get_contents($_REQUEST['path']);
				if(!$content){
					$error = new divine_error('File not found!');
					break;
				} else {
					$output = '<?xml version=\'1.0\' encoding=\'utf-8\' ?>' . "\r\n" . '<getFileResponse path="' . $_REQUEST['path'] . '">';
					$output .= '<content>' . $content . '</content>' . "\r\n";
				}
				$output .= '</getFileResponse>';
				header('Content-type: text/xml');
				echo $output;
				break;
			
			case 'load':
				echo file_get_contents($_REQUEST['dest']);
				break;
			
			case 'sendComment':
				mail('creator@notanos.com', 'divine Comment', $_REQUEST['comment'], 'From: comment@notanos.com');
				break;
			
			default:
				break;
				
		}
	}
?>