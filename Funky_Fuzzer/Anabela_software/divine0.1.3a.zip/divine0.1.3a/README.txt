README - divine alpha 0.1.3

1. Installation

To install divine, import the divine.sql file with phpMyAdmin or another
relevant tool. It will start off the a demo account, which can be changed.
Also, edit the 'divine.php' file and change the define statements as follows:

define('DIVINE_HOST', YOUR DATABASE HOST, true);
define('DIVINE_USER', YOUR DATABASE NAME, true);
define('DIVINE_PASS', YOUR DATABASE PASSWORD, true);
define('DIVINE_DB', YOUR DATABASE, true);
define('DIVINE_DOMAIN', YOUR DOMAIN, true);
define('DIVINE_PATH', YOUR PATH, true);

Upload all of the files and folders in this folder in their current structure
(besides this file, CHANGELOG, and the LICENSE file) to any PHP-enabled website.

The default installation is a replication of the divine demo site (see
http://demo.notanos.com).

2. The divine system

divine is an AJAX system, and incorporates Javascript to do nearly everything
related to the client.

To create a divine window, one would do the following:

var newWindow = new divine_window();
newWindow.title = 'This is a test';
newWindow.position = 'center';
newWindow.add();

This will add it to the DOM and create the window on screen.

Play with the divine objects and see what you can make, this README is
too short to tell you much more (and I've yet to write it all down.)

3. Browser Support
Mozilla Firefox (http://www.getfirefox.com) is the best supported browser
at the moment, but Internet Explorer nows functions as expected as well.

4. divine Documentation
Documentation is underway and will be actively developed alongside the
divine project. See http://www.notanos.com/docs for more information.

5. Other Contributions
The default iconset provided with divine is based on the Tango Icon Project
at http://tango.freedesktop.org. They both are licensed under the Creative
Commons Attribution-ShareAlike 2.5 License, available at:
http://www.creativecommons.org/licenses/by-sa/2.5/legalcode

- Elijah Horton
divine Creator
creator@notanos.com