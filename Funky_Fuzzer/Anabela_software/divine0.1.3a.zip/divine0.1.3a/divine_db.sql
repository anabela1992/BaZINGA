-- phpMyAdmin SQL Dump
-- version 2.7.0-pl2
-- http://www.phpmyadmin.net
-- 
-- Host: www.notanos.com
-- Generation Time: Aug 29, 2006 at 07:54 PM
-- Server version: 5.0.15
-- PHP Version: 4.3.3
-- 
-- divine Default SQL Import
-- 
-- 
-- Database: `divine_db`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `divine_user`
-- 

CREATE TABLE `divine_user` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `registered` int(11) NOT NULL,
  `avatar` varchar(64) NOT NULL,
  `info` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='divine User Table' AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `divine_user`
-- 

INSERT INTO `divine_user` VALUES (1, 'demo', 'demo', 'demo@demo.com', 0, '', '');
