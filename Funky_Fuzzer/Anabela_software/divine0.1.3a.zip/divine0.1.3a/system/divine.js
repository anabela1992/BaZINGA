/*
	divine 0.1.2alpha
	by Elijah Horton
	divine.js
	
	www.notanos.com
*/

function Browser()
{
	var ua, s, i;
	this.isIE  = false;
	this.isNS  = false;
	this.version = null;
	ua = navigator.userAgent;
	s = "MSIE";
	if ((i = ua.indexOf(s)) >= 0) {
		this.isIE = true;
		this.version = parseFloat(ua.substr(i + s.length));
		return;
	}
	s = "Netscape6/";
	if ((i = ua.indexOf(s)) >= 0) {
		this.isNS = true;
		this.version = parseFloat(ua.substr(i + s.length));
		return;
	}
	s = "Gecko";
	if ((i = ua.indexOf(s)) >= 0) {
		this.isNS = true;
		this.version = 6.1;
		return;
	}
}

String.prototype.wordWrap = function(m, b, c){
    var i, j, s, r = this.split("\n");
    if(m > 0) for(i in r){
        for(s = r[i], r[i] = ""; s.length > m;
            j = c ? m : (j = s.substr(0, m).match(/\S*$/)).input.length - j[0].length
            || m,
            r[i] += s.substr(0, j) + ((s = s.substr(j)).length ? b : "")
        );
        r[i] += s;
    }
    return r.join("\n");
};


function divine_system ()
{
	this.setDesktop = function(){
		var m = document.getElementById('menubar');
		m.style.width = this.desktopWidth + 'px';
		var d = document.getElementById('desktop');
		d.style.width = this.desktopWidth + 'px';
		d.style.height = (this.desktopHeight-m.offsetHeight) + 'px';
	}
	this.resize = function(){
		if (window.innerHeight) // all except Explorer
		{
			this.windowWidth = window.innerWidth - 16; //-16 to compensate for scrollbars, disable if you have smaller desktop
			this.windowHeight = window.innerHeight - 16;
		}
		else if (document.documentElement && document.documentElement.clientHeight) // Explorer 6 Strict Mode
		{
			this.windowWidth = document.documentElement.clientWidth - 16;
			this.windowHeight = document.documentElement.clientHeight - 16;
		}
		else if (document.body) // other Explorers
		{
			this.windowWidth = document.body.clientWidth - 16;
			this.windowHeight = document.body.clientHeight - 16;
		}
		this.screenWidth = screen.availWidth;
		this.screenHeight = screen.availHeight;
		this.windowHeight -= 21; //compensate for menubar height
	}
	if(browser.isNS){
		this.allowOpacity = true;
		this.img = '.png';
	} else {
		this.allowOpacity = false;
		this.img = '.gif';
	}
	this.theme = 'divine';
	this.title = 'divine 0.1.1 ALPHA';
	this.desktopWidth = '2048';
	this.desktopHeight = '2048';
}

var browser = new Browser();
var divine = new divine_system();
var divine_windows = new Object();
var divine_icons = new Object();
var divine_menus = new Object();
var topZIndex = 0;
var staggerIndex = 0;

function divine_window()
{
	this.id = '';
	this.title = '';
	this.css = 'window';
	this.movable = 'y';
	this.widgets = 'all';
	this.overflow = 'auto';
	this.position = 'absolute';
	this.resizable = 'y';
	this.modal = 'n';
	this.left = '200px';
	this.minLeft = '0px';
	this.maxLeft = divine.desktopWidth + 'px';
	this.top = '200px';
	this.minTop = '21px';
	this.maxTop = divine.desktopHeight + 'px';
	this.width = '200px';
	this.minWidth = '100px';
	this.maxWidth = divine.windowWidth + 'px';
	this.height = '200px';
	this.minHeight = '100px';
	this.maxHeight = divine.windowHeight + 'px';
	this.grown = false;
	this.shrunk = false;
	this.zIndex = doZIndex;
	this.content = '';
	this.script = '';
	this.html = '';
	this.node = false;
	this.xmlimport = xml_import;
	this.make = divine_window_make;
	this.drop = function() { delete divine_windows[this.id]; }
	this.add = function() { if(this.html!=''){ DOMAdd(this.html); this.node = document.getElementById(this.id); this.zIndex(++topZIndex);  } else { this.make(); this.add(); } }
	this.run = function(stuff) {
		var stuff = stuff || false;
		if(stuff!=false){
			eval(stuff);
		} else if(this.script!=''){
			eval(this.script);
		}
	}
	this.setTitle = function(text){
		if(this.node){
			this.node.childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[0].nodeValue = text;
			this.title = text;
		} else {
			document.getElementById(this.id).childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[0].nodeValue = text;
			this.title = text;
		}
	}
}

function divine_window_make(n)
{
	var wid, wtitle, wcontent;
	var n = n || false;
	if(n){
		wid = n;
	} else {
		wid = 'w' + (getCount('w')+1);
	}
	this.id = wid;
	if(this.title=='' || this.title==undefined){
		wtitle = '&nbsp;';
	} else {
		wtitle = this.title;
	}
	if(this.content=='' || this.content==undefined){
		wcontent = '&nbsp;';
	} else {
		wcontent = this.content;
	}
	getPosition(this);
	this.html = '<table border="0" cellpadding="0" cellspacing="0" style="position: absolute; top: ' + this.top + '; left: ' + this.left + '; width: ' + this.width + '; height: ' + this.height + ';" class="' + this.css + '" id="' + wid + '">';
	if(this.modal!='y'){
		this.html += '<tr id="titlerow"><td><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td id="title"';
		if(this.movable=='y'){
			this.html += 'onmousedown="dragStart(event, \'' + wid + '\');" style="cursor: move;"';
		}
		if(this.widgets == 'all' || this.widgets == 'yyy' || this.widgets == 'yyn' || this.widgets == 'ynn' || this.widgets == 'shk' || this.widgets == 'yny'){
			this.html += 'ondblclick="shrinkWind(\'' + wid + '\');"';
		}
		this.html += '>' + wtitle + '</td><td id="widgets">';
		switch(this.widgets){
			case 'all':
			case 'yyy':
				this.html += '<span class="widgets"><a href="#" onclick="shrinkWind(\'' + wid + '\'); blur();">-</a><a href="#" onclick="growWind(\'' + wid + '\'); blur();">+</a><a href="#" onclick="closeWind(\'' + wid + '\');">X</a></span>';
				break;
			case 'yyn':
				this.html += '<span class="widgets"><a href="#" onclick="shrinkWind(\'' + wid + '\'); blur();">-</a><a href="#" onclick="growWind(\'' + wid + '\'); blur();">+</a></span>';
				break;
			case 'ynn':
			case 'shk':
				this.html += '<span class="widgets"><a href="#" onclick="shrinkWind(\'' + wid + '\'); blur();">-</a></span>';
				break;
			case 'nnn':
			case 'no':
				break;
			case 'nyn':
			case 'grw':
				this.html += '<span class="widgets"><a href="#" onclick="growWind(\'' + wid + '\'); blur();">+</a></span>';
				break;
			case 'yny':
				this.html += '<span class="widgets"><a href="#" onclick="shrinkWind(\'' + wid + '\'); blur();">-</a><a href="#" onclick="closeWind(\'' + wid + '\');">X</a></span>';
				break;
			case 'nny':
			case 'cls':
			default:
				this.html += '<span class="widgets"><a href="#" onclick="closeWind(\'' + wid + '\');">X</a></span>';
				break;
		}
		this.html += '</td></tr></table></td><td class="shadow"><img src="img/spacer.gif" width="1" height="1" alt="" /></td></tr>';
		this.html += '<tr><td class="content"';
	} else {
		this.html += '<tr><td class="modal"';
	}
	this.html += ' id="' + wid + 'content" style="overflow: ' + this.overflow + ';" height="100%" valign="top">' + wcontent + '</td><td class="shadow" id="side"';
	if(this.resizable=='y'){
	 this.html += ' style="cursor: e-resize;" onmousedown="resizeStart(event, \'' + wid + '\', \'r\');"';
	}
	this.html += '><img src="img/spacer.gif" width="1" height="1" alt="" /></td></tr><tr><td id="bottom"';
	if(this.resizable=='y'){
		this.html += ' style="cursor: s-resize;" onmousedown="resizeStart(event, \'' + wid + '\', \'b\');"';
	}
	this.html += '><img src="img/spacer.gif" width="1" height="1" alt="" /></td><td id="corner"';
	if(this.resizable=='y'){
		this.html += 'style="cursor: se-resize;" onmousedown="resizeStart(event, \'' + wid + '\', \'br\');"';
	}
	this.html += '><img src="img/spacer.gif" width="1" height="1" alt="" /></td></tr></table>';
	divine_windows[this.id] = this;
}

function divine_icon ()
{
	this.id = '';
	this.title = '';
	this.type = 'file';
	this.path = '';
	this.action = '';
	this.icon = '';
	this.css = 'icon';
	this.left = 20;
	this.top = 40;
	this.width = '32px';
	this.height = '32px';
	this.selected = false;
	this.position = 'absolute';
	this.zIndex = doZIndex;
	this.html = '';
	this.node = false;
	this.xmlimport = xml_import;
	this.make = divine_icon_make;
	this.drop = function() { delete divine_icons[this.id]; }
	this.add = function() {
		for(x in divine_icons){
			this.top += 60;
			if(this.top+60 > (divine.windowHeight)){
				this.top = 40;
				this.left += 80;
			}
		}
		this.top = this.top + 'px';
		this.left = this.left + 'px';
		if(this.html!=''){
			DOMAdd(this.html);
			this.zIndex(++topZIndex);
			this.node = document.getElementById(this.id);
		} else {
			this.make();
			this.add();
		}
	}
	this.addTo = function(id){
		this.position = 'view';
		if(this.html!=''){
			DOMAdd(this.html, id + 'content');
			this.node = document.getElementById(this.id);
			this.zIndex(++topZIndex);
		} else {
			this.make();
			this.addTo(id);
		}
	}
}

function divine_icon_make (n)
{
	var n = n || false;
	if(n){
		mid = n;
	} else {
		mid = 'i' + (getCount('i')+1);
	}
	this.id = mid;
	if(this.title=='' || this.title==undefined){
		mtitle = '&nbsp;';
	} else {
		mtitle = this.title;
		mtitle = mtitle.wordWrap(20, "<br/>", false);
	}
	if(this.icon=='' || this.icon==undefined){
		this.icon = this.type;
	}
	if(this.position != 'view'){
		getPosition(this);
		var pos = 'position: absolute; left: ' + this.left + '; top: ' + this.top + ';';
	} else {
		var pos = 'margin: 2px; margin-top: 10px; top: 0px; left: 0px;';
	}
	this.html = '<div class="' + this.css + '" style="' + pos + ' width: 100px; height: ' + this.height + ';" id="' + mid + '"><center>';
	this.html += '<img src="img/icons/' + this.icon + divine.img + '" alt="' + this.title + '" width="' + parseInt(this.width, 10) + '" height="' + parseInt(this.height, 10) + '" border="0"';
	this.html += ' onclick="selectIcon(\'' + mid + '\');" onmousedown="selectIcon(\'' + mid + '\'); dragStart(event, \'' + mid + '\');"';
	if(this.action != ''){
		this.html += ' ondblclick="' + this.action + '"';
	} else if(this.type == 'image' || this.type == 'text'){
		this.html += ' ondblclick="openFile(\'' + mid + '\');"';
	} else if(this.type == 'folder' || this.type == 'computer'){
		this.html += ' ondblclick="openFolder(\'' + mid + '\');"';
	} else if(this.type == 'html'){
		this.html += ' ondblclick="openHTML(\'' + mid + '\');"';
	} else if(this.type == 'application'){
		this.html += ' ondblclick="divine.run(\'' + mid + '\');"';
	}
	this.html += '/><br/>';
	this.html += '<span id="' + mid + 'text' + '" class="text" ondblclick="editIconText(\'' +  mid + '\');">' + mtitle + '</span></center></div>';
	divine_icons[this.id] = this;
}

function selectIcon(which)
{
	var obj = document.getElementById(which);
	var icon = divine_icons[which];
	for(x in divine_icons){
		deselectIcon(x);
	}
	icon.selected = true;
	obj.className = icon.css + 'Sel';
}

function deselectIcon(which)
{
	var obj = document.getElementById(which);
	var icon = divine_icons[which];
	icon.selected = false;
	obj.className = icon.css;
}

function divine_menu (rc)
{
	var rc = rc || false;
	this.rightClick = rc;
	this.id = '';
	this.title = '';
	this.css = 'menu';
	this.icon = '';
	this.iconW = '18';
	this.iconH = '18';
	this.items = Object();
	this.numItems = 0;
	this.shown = false;
	this.html = '';
	this.htmlCaller = '';
	this.node = false;
	this.callerNode = false;
	this.addItem = function(title, href, lnk){ var lnk = lnk || false; if(lnk){this.items[this.numItems] = new divine_menu_item(title, href, lnk);} else {this.items[this.numItems] = new divine_menu_item(title, href);} this.numItems++; }
	this.addSep = function() { this.items[this.numItems] = new divine_menu_item('---', ''); this.numItems++; }
	this.dropItem = function(i){ if(this.items[i]){ delete this.items[i]; } }
	this.make = divine_menu_make;
	this.drop = function() { if(divine_menus[this.id]) { delete divine_menus[this.id]; } }
	this.add = function() {
		if(this.rightClick==true){
			if(this.html!=''){
				DOMAdd(this.html);
				this.node = document.getElementById(this.id);
			} else {
				this.make();
				this.add();
			}
		} else {
			if(this.html!='' && this.htmlCaller !=''){
				var menubar = document.getElementById('menubar');
				menubar.innerHTML += this.htmlCaller;
				DOMAdd(this.html);
				divine_menus[this.id] = this;
				this.node = document.getElementById(this.id);
				this.callerNode = document.getElementById(this.id+'caller');
			} else {
				this.make();
				this.add();
			}
		}
	}
}

function divine_menu_item (title, href, lnk)
{
	this.title = title;
	this.href = href;
	var lnk = lnk || false;
	if(lnk){
		this.lnk = lnk;
	}
}

function divine_menu_make (n)
{
	var n = n || false;
	if(n){
		mid = n;
	} else {
		mid = 'm' + (getCount('m')+1);
	}
	if(this.rightClick==true){
		mid = mid + 'rc';
	}
	this.id = mid;
	if(this.title=='' || this.title==undefined){
		mtitle = '&nbsp;';
	} else {
		mtitle = this.title;
	}
	this.html = '<div id="' + mid + '" class="' + this.css + '">';
	for(x in this.items){
		if(this.items[x].title != '---' && !this.items[x].lnk){
			var href = this.items[x].href || '';
			this.html += '<a href="#" onclick="blur(); ' + href + ' hide(\'' + mid + '\');">' + this.items[x].title + '</a>';
		} else if(this.items[x].title != '---' && this.items[x].lnk == true){
			var href = this.items[x].href || '';
			this.html += '<a href="' + href + '" onclick="blur(); hide(\'' + mid + '\');">' + this.items[x].title + '</a>';
		} else {
			this.html += '<div class="sep"><img src="img/spacer.gif" width="1" height="1" alt="" /></div>';
		}
	}
	this.html += '</div>';
	if(this.icon!=''){
		this.htmlCaller = '<a href="#" id="' + mid + 'caller" onclick="blur(); doMenu(\'' + mid + '\');" onmouseover="checkMenu(\'' + mid + '\');"><img src="' + this.icon + divine.img + '" width="' + this.iconW + '" height="' + this.iconH + '" border="0" alt="' + this.title + '"/></a>';
	} else {
		this.htmlCaller = '<a href="#" id="' + mid + 'caller" onclick="blur(); doMenu(\'' + mid + '\');" onmouseover="checkMenu(\'' + mid + '\');">' + mtitle + '</a>';
	}
}

function getPageOffsetLeft(el) {
  var x;

  // Return the x coordinate of an element relative to the page.

  x = el.offsetLeft;
  if (el.offsetParent != null)
    x += getPageOffsetLeft(el.offsetParent);

  return x;
}

function getPageOffsetTop(el) {
  var y;

  // Return the y coordinate of an element relative to the page.

  y = el.offsetTop;
  if (el.offsetParent != null)
    y += getPageOffsetTop(el.offsetParent);

  return y;
}

function show(objId) {
	var obj = document.getElementById(objId);
	if(!obj){
		return;
	}
	if(obj.style.display != 'block'){
		obj.style.display = 'block';
	}
}

function hide(objId) {
	var obj = document.getElementById(objId);
	if(!obj){
		return;
	}
	if(obj.style.display != 'none'){
		obj.style.display = 'none';
		if(objId.search('m') != -1){ //is a menu
			divine_menus[objId].shown = false;
		}
	}
}

function doMenu(which) {
	var obj = document.getElementById(which);
	var vision = obj.style.display;
	if(vision == 'block'){
		obj.style.display = 'none';
		divine_menus[which].shown = false;
	} else {
		var tmpobj = document.getElementById(which + 'caller');
		var x = getPageOffsetLeft(tmpobj);
  		if (browser.isIE) {
    		x += tmpobj.offsetParent.clientLeft;
  		}
		obj.style.left = x + 'px';
		obj.style.display = 'block';
		divine_menus[which].shown = true;
		for(x in divine_menus){
			if(divine_menus[x].shown==true && divine_menus[x].id != which){
				divine_menus[x].shown = false;
				hide(x);
			}
		}
	}
}

function checkMenu(which)
{
	var obj = document.getElementById(which);
	var vision = obj.style.display;
	if(vision != 'block'){
		tmpobj = document.getElementById(which + 'caller');
		x = getPageOffsetLeft(tmpobj);
  		if (browser.isIE) {
    		x += tmpobj.offsetParent.clientLeft;
  		}
		obj.style.left = x + 'px';
		for(x in divine_menus){
			if(divine_menus[x].shown==true && divine_menus[x].id != which){
				divine_menus[x].shown = false;
				hide(x);
				divine_menus[which].shown = true;
				obj.style.display = 'block';
			}
		}
	}
}

function xml_import(xml)
{
	if(xml){
		var finished = false;
		var curNode = xml.documentElement.firstChild;
		while(finished==false){
			eval('this.' + curNode.nodeName + ' = ' + curNode.nodeValue + ';');
			if(curNode.nextSibling){
				curNode = curNode.nextSibling;
			} else {
				finished = true;
			}
		}
	}
}

function getCount(type, reg)
{
	var i = 1;
	var reg = reg || false;
	var type = type || 'w';
	if(reg==true){
		eval('for(x in ' + type + '){ i++; }');
		return i;
	} else {
		while(document.getElementById(type + i)){
			i++;
		}
		i--;
		return i;
	}
}

function getPosition(tmp, offX, offY)
{
	var offX = offX || 0;
	var offY = offY || 0;
	
	if(tmp.position=='center'){
		if(tmp.width.search('%') != '-1' && tmp.width != 'auto'){
			tmp.width = divine.windowWidth * (parseInt(tmp.width)/100);
		}
		if(tmp.height.search('%') != '-1' && tmp.height != 'auto'){
			tmp.height = divine.windowHeight * (parseInt(tmp.height)/100);
		}
		if(tmp.width != 'auto'){
			tmp.left = ((divine.windowWidth/2) - (parseInt(tmp.width)/2)) + offX + 'px';
		} else {
			tmp.left = (divine.windowWidth/2) + offX + 'px';
		}
		if(tmp.height != 'auto'){
    		tmp.top = ((divine.windowHeight/2) - (parseInt(tmp.height)/2)) + offY + 'px';
		} else {
			tmp.top = (divine.windowHeight/2) + offY + 'px';
		}
	}
	if(tmp.position=='centerx' || tmp.position=='centerw' || tmp.position=='top' || tmp.position=='bottom'){
		if(tmp.width.search('%') != '-1' && tmp.width != 'auto'){
			tmp.width = divine.windowWidth * (parseInt(tmp.width)/100);
		}
		if(tmp.width != 'auto'){
    		tmp.left = ((divine.windowWidth/2) - (parseInt(tmp.width)/2)) + offX + 'px';
		} else {
			tmp.left = (divine.windowWidth/2) + offX + 'px';
		}
	}
	if(tmp.position=='centery' || tmp.position=='centerh' || tmp.position=='left' || tmp.position=='right'){
		if(tmp.height.search('%') != '-1' && tmp.height != 'auto'){
			tmp.height = divine.windowHeight * (parseInt(tmp.height)/100);
		}
		if(tmp.height != 'auto'){
    		tmp.top = ((divine.windowHeight/2) - (parseInt(tmp.height)/2)) + offY + 'px';
		} else {
			tmp.top = (divine.windowHeight/2) + offY + 'px';
		}
	}
	if(tmp.position=='left' || tmp.position=='topleft' || tmp.position=='bottomleft'){
		tmp.left = 0 + offX + 'px';
	}
	if(tmp.position=='right' || tmp.position=='topright' || tmp.position=='bottomright'){
		tmp.left = (divine.windowWidth-parseInt(tmp.width)) + offX + 'px';
	}
	if(tmp.position=='topleft' || tmp.position=='topright' || tmp.position=='top'){
		tmp.top = 0 + offY + 'px';
	} else if(tmp.position=='bottomleft' || tmp.position=='bottomright' || tmp.position=='bottom'){
		tmp.top = (divine.windowHeight-parseInt(tmp.height)) + offY + 'px';
	}
	if(tmp.position=='stagger'){
		var stagTop = 0;
		var stagLeft = 0;
		var  i = 0;
		staggerIndex++;
		if(staggerIndex > 25){
			staggerIndex = 1;
		}
		while(i < staggerIndex){
			stagTop += 24;
			stagLeft += 24;
			if(stagTop > (divine.windowHeight-parseInt(tmp.height))){
				stagTop = 24;
			}
			if(stagLeft > (divine.windowWidth-parseInt(tmp.width))){
				stagLeft = 24;
			}
			i++;
		}
		tmp.top = stagTop + 'px';
		tmp.left = stagLeft + 'px';
	}
	if(parseInt(tmp.top) < 21){ //push elements off menubar
		tmp.top = '21px';
	}
}

function closeWind(which)
{
	DOMDelete(which);
	if(divine_windows[which]){
		divine_windows[which].drop();
	}
}

function shrinkWind(which)
{
	var obj = document.getElementById(which);
	var w = divine_windows[which];
	objRow = obj.rows[1];
	if(obj.style.zIndex < topZIndex){
		obj.style.zIndex = ++topZIndex;
	}
	if(w.shrunk != true){
		obj.style.height = 'auto';
		objRow.style.display = 'none';
		w.shrunk = true;
	} else {
		obj.style.height = divine_windows[which].height;
		objRow.style.display = 'table-row';
		w.shrunk = false;
	}
}

function growWind(which)
{
	var obj = document.getElementById(which);
	var w = divine_windows[which];
	
	if(w.shrunk==true){
		shrinkWind(which);
	} else {
		if(obj.style.zIndex < topZIndex){
			obj.style.zIndex = ++topZIndex;
		}
	}
	if(w.grown==true && w.resizable!='n'){
		obj.style.width = w.width;
		obj.style.height = w.height;
		obj.style.top = w.top;
		obj.style.left = w.left;
		w.grown = false;
	} else if(w.resizable!='n') {
		obj.style.width = w.maxWidth;
		obj.style.height = w.maxHeight;
		obj.style.left = '0px';
		obj.style.top = '21px';
		w.grown = true;
	}
	if(w.onResize){
		eval(w.onResize);
	}
}

// Global object to hold drag information.

var dragObj = new Object();

/*
	zIndex Zoning
	
	Desktop (wallpaper): 1
	Menubar: 20000
	Menus: 20001+
	Icons (on desktop): 100+
	Windows: 10000+
*/

function doZIndex(n)
{
	var n = n || false;
	if(n){ //set z-index
		if(this.node){
			this.node.style.zIndex = n;
		} else {
			document.getElementById(this.id).style.zIndex = n;
		}
	} else { //get z-index
		if(this.node){
			return this.node.style.zIndex;
		} else {
			return document.getElementById(this.id).style.zIndex;
		}
	}
}

function moveZIndex(level, array, start)
{
	var level = level + start || 'top';
	var z = start;
	var otherZ, myZ, x;
	myZ = this.zIndex();
	
	if(level=='top'){
		for(x in array){
			otherZ = array[x].zIndex();
			if(otherZ > myZ){
				array[x].zIndex(otherZ-1);
			}
			z++;
		}
		if(myZ < z){
			this.zIndex(z);
		}
	} else if(level=='bottom'){
		for(x in array){
			otherZ = array[x].zIndex();
			if(otherZ < myZ){
				array[x].zIndex(otherZ+1);
			}
		}
		if(myZ > start){
			this.zIndex(start);
		}
	} else {
		if(myZ > level){
			for(x in array){
				otherZ = array[x].zIndex();
				if(otherZ < myZ && otherZ >= level){
					array[x].zIndex(otherZ+1);
				}
			}
			
		} else if(myZ < level){
			for(x in array){
				otherZ = array[x].zIndex();
				if(otherZ > myZ && otherZ <= level){
					array[x].zIndex(otherZ-1);
				}
			}
		}
		this.zIndex(level);
	}
}

function dragStart(event, id) {

  var el;
  var x, y;

  // If an element id was given, find it. Otherwise use the element being
  // clicked on.

  if (id)
    dragObj.elNode = document.getElementById(id);
  else {
    if (browser.isIE)
      dragObj.elNode = window.event.srcElement;
    if (browser.isNS)
      dragObj.elNode = event.target;

    // If this is a text node, use its parent element.

    if (dragObj.elNode.nodeType == 3)
      dragObj.elNode = dragObj.elNode.parentNode;
  }

  // Get cursor position with respect to the page.

  if (browser.isIE) {
    x = window.event.clientX + document.documentElement.scrollLeft
      + document.body.scrollLeft;

    y = window.event.clientY + document.documentElement.scrollTop
      + document.body.scrollTop;
  }
  if (browser.isNS) {
    x = event.clientX + window.scrollX;
    y = event.clientY + window.scrollY;
  }

  // Save starting positions of cursor and element.

  dragObj.cursorStartX = x;
  dragObj.cursorStartY = y;
  dragObj.elStartLeft  = parseInt(dragObj.elNode.style.left, 10);
  dragObj.elStartTop   = parseInt(dragObj.elNode.style.top,  10);

  if(isNaN(dragObj.elStartLeft)) dragObj.elStartLeft = 0;
  if(isNaN(dragObj.elStartTop))  dragObj.elStartTop  = 0;
  if(divine.allowOpacity == true){
  	dragObj.dragOpacity = 0.75;
  }
  if(id.search('w') != -1){	//id is a window
  	dragObj.type = 'window';
	var w = divine_windows[id];
	dragObj.minLeft = parseInt(w.minLeft, 10);
	dragObj.maxLeft = parseInt(w.maxLeft, 10);
	dragObj.minTop = parseInt(w.minTop, 10);
	dragObj.maxTop = parseInt(w.maxTop, 10);
	dragObj.width = parseInt(w.width, 10);
	dragObj.height = parseInt(w.height, 10);
	if(w.dragOpacity && divine.allowOpacity == true){
		dragObj.dragOpacity=w.dragOpacity;
	}
  } else {
  	dragObj.minLeft = '0';
  	dragObj.maxLeft = divine.windowWidth;
  	dragObj.minTop = '21';
  	dragObj.maxTop = divine.windowHeight;
  	dragObj.type = 'other';
	dragObj.width = '32';
	dragObj.height = '32';
  }
  dragObj.id = id;
  // Update element's z-index.
  if(dragObj.dragOpacity!='1.0' && divine.allowOpacity == true){
	dragObj.elNode.style.opacity = dragObj.dragOpacity;
  }
  if(dragObj.elNode.style.zIndex < topZIndex){
  	dragObj.elNode.style.zIndex = ++topZIndex;
  }

  // Capture mousemove and mouseup events on the page.

  if (browser.isIE) {
    document.attachEvent("onmousemove", dragGo);
    document.attachEvent("onmouseup",   dragStop);
	window.event.cancelBubble = true;
	window.event.returnValue = false;
  }
  if (browser.isNS) {
    document.addEventListener("mousemove", dragGo,   true);
    document.addEventListener("mouseup",   dragStop, true);
	event.preventDefault();
  }
}

function dragGo(event) {

  var x, y;

  // Get cursor position with respect to the page.

  if (browser.isIE) {
    x = window.event.clientX + document.documentElement.scrollLeft
      + document.body.scrollLeft;
    y = window.event.clientY + document.documentElement.scrollTop
      + document.body.scrollTop;
  }
  if (browser.isNS) {
    x = event.clientX + window.scrollX;
    y = event.clientY + window.scrollY;
  }

  // Move drag element by the same amount the cursor has moved.
  	var movX  = (dragObj.elStartLeft + x - dragObj.cursorStartX);
	var movY  = (dragObj.elStartTop  + y - dragObj.cursorStartY);
	if(movX >= dragObj.minLeft && movX <= dragObj.maxLeft && (movX + dragObj.width) <= divine.desktopWidth){
  		dragObj.elNode.style.left = movX + "px";
	} else if(movX < dragObj.minLeft){
		dragObj.elNode.style.left = dragObj.minLeft + "px";
	} else if(movX > dragObj.maxLeft){
		dragObj.elNode.style.left = dragObj.maxLeft + "px";
	} else if((movX + dragObj.width) > divine.desktopWidth){
		dragObj.elNode.style.left = (divine.desktopWidth - dragObj.width) + "px";
	}
	if(movY >= dragObj.minTop && movY <= dragObj.maxTop && (movY + dragObj.height) <= divine.desktopHeight){
  		dragObj.elNode.style.top = movY + "px";
	} else if(movY < dragObj.minTop){
		dragObj.elNode.style.top = dragObj.minTop + "px";
	} else if(movY > dragObj.maxTop){
		dragObj.elNode.style.top = dragObj.maxTop + "px";
	} else if((movY + dragObj.height) > divine.desktopHeight){
		dragObj.elNode.style.top = (divine.desktopHeight - dragObj.height) + "px";
	}
	if(dragObj.type == 'window'){
		divine_windows[dragObj.id].left = dragObj.elNode.style.left;
		divine_windows[dragObj.id].top = dragObj.elNode.style.top;
  	}

	if (browser.isIE) {
		window.event.cancelBubble = true;
		window.event.returnValue = false;
	}
	if (browser.isNS){
		event.preventDefault();
	}
}

function dragStop(event) {

  // Stop capturing mousemove and mouseup events.

  if (browser.isIE) {
    document.detachEvent("onmousemove", dragGo);
    document.detachEvent("onmouseup",   dragStop);
  }
  if (browser.isNS) {
    document.removeEventListener("mousemove", dragGo,   true);
    document.removeEventListener("mouseup",   dragStop, true);
  }
  if(dragObj.dragOpacity!='1.0' && divine.allowOpacity == true){
  	dragObj.elNode.style.opacity = 1.0;
  }
}

var resizeObj = new Object();

function resizeStart(event, id, dir) {

  var el;
  var x, y;

  // If an element id was given, find it. Otherwise use the element being
  // clicked on.

  if (id)
    resizeObj.elNode = document.getElementById(id);
  else {
    if (browser.isIE)
      resizeObj.elNode = window.event.srcElement;
    if (browser.isNS)
      resizeObj.elNode = event.target;

    // If this is a text node, use its parent element.

    if (resizeObj.elNode.nodeType == 3)
      resizeObj.elNode = resizeObj.elNode.parentNode;
  }

  // Get cursor position with respect to the page.

  if (browser.isIE) {
    x = window.event.clientX + document.documentElement.scrollLeft
      + document.body.scrollLeft;
    y = window.event.clientY + document.documentElement.scrollTop
      + document.body.scrollTop;
  }
  if (browser.isNS) {
    x = event.clientX + window.scrollX;
    y = event.clientY + window.scrollY;
  }

  // Save starting positions of cursor and element.

  resizeObj.cursorStartX = x;
  resizeObj.cursorStartY = y;
  resizeObj.direction = dir;
  if(id.search('w') != -1){	//id is a window
  	resizeObj.type = 'window';
	var w = divine_windows[id];
  	resizeObj.minWidth = parseInt(w.minWidth, 10);
  	resizeObj.maxWidth = parseInt(w.maxWidth, 10);
  	resizeObj.minHeight = parseInt(w.minHeight, 10);
  	resizeObj.maxHeight = parseInt(w.maxHeight, 10);
  	resizeObj.left  = parseInt(w.left, 10);
  	resizeObj.top   = parseInt(w.top,  10);
	if(w.onResize){
		resizeObj.onResize = w.onResize;
	}
  } else {
  	resizeObj.minWidth = '32';
  	resizeObj.maxWidth = divine.windowWidth;
  	resizeObj.minHeight = '32';
  	resizeObj.maxHeight = divine.windowHeight;
	resizeObj.left  = resizeObj.elNode.style.left;
  	resizeObj.top   = resizeObj.elNode.style.top;
  	resizeObj.type = 'other';
  }
  resizeObj.id = id;
  
  // Update element's z-index.

  if(resizeObj.elNode.style.zIndex < topZIndex){
  	resizeObj.elNode.style.zIndex = ++topZIndex;
  }

  // Capture mousemove and mouseup events on the page.

  if (browser.isIE) {
    document.attachEvent("onmousemove", resizeGo);
    document.attachEvent("onmouseup",   resizeStop);
    window.event.cancelBubble = true;
    window.event.returnValue = false;
  }
  if (browser.isNS) {
    document.addEventListener("mousemove", resizeGo,   true);
    document.addEventListener("mouseup",   resizeStop, true);
    event.preventDefault();
  }
}

function resizeGo(event) {

  var x, y;

  // Get cursor position with respect to the page.

  if (browser.isIE) {
    x = window.event.clientX + document.documentElement.scrollLeft
      + document.body.scrollLeft;
    y = window.event.clientY + document.documentElement.scrollTop
      + document.body.scrollTop;
  }
  if (browser.isNS) {
    x = event.clientX + window.scrollX;
    y = event.clientY + window.scrollY;
  }

  // Move drag element by the same amount the cursor has moved.
	var movX = (x - resizeObj.left);
	var movY = (y - resizeObj.top);
	switch(resizeObj.direction){
		
		case 'r':
		case 'e':
			if(movX >= resizeObj.minWidth && movX <= resizeObj.maxWidth){
  				resizeObj.elNode.style.width = movX + "px";
  			} else if(movX < resizeObj.minWidth){
				resizeObj.elNode.style.width = resizeObj.minWidth + "px";
			} else if(movX > resizeObj.maxWidth){
				resizeObj.elNode.style.width = resizeObj.maxWidth + "px";
			}
			break;
		case 'b':
		case 's':
			if(movY >= resizeObj.minHeight && movY <= resizeObj.maxHeight){
  				resizeObj.elNode.style.height = movY + "px";
  			} else if(movY < resizeObj.minHeight){
				resizeObj.elNode.style.height = resizeObj.minHeight + "px";
			} else if(movY > resizeObj.maxHeight){
				resizeObj.elNode.style.height = resizeObj.maxHeight + "px";
			}
			break;
			
		case 'br':
		case 'rb':
		case 'se':
		case 'es':
		default:
			if(movX >= resizeObj.minWidth && movX <= resizeObj.maxWidth){
  				resizeObj.elNode.style.width = movX + "px";
  			} else if(movX < resizeObj.minWidth){
				resizeObj.elNode.style.width = resizeObj.minWidth + "px";
			} else if(movX > resizeObj.maxWidth){
				resizeObj.elNode.style.width = resizeObj.maxWidth + "px";
			}
			if(movY >= resizeObj.minHeight && movY <= resizeObj.maxHeight){
  				resizeObj.elNode.style.height = movY + "px";
  			} else if(movY < resizeObj.minHeight){
				resizeObj.elNode.style.height = resizeObj.minHeight + "px";
			} else if(movY > resizeObj.maxHeight){
				resizeObj.elNode.style.height = resizeObj.maxHeight + "px";
			}
			break;
	}
	if(resizeObj.type == 'window'){
		divine_windows[resizeObj.id].width = resizeObj.elNode.style.width;
		divine_windows[resizeObj.id].height = resizeObj.elNode.style.height;
  	}
	if(resizeObj.onResize){
		eval(resizeObj.onResize);
	}

  if (browser.isIE) {
    window.event.cancelBubble = true;
    window.event.returnValue = false;
  }
  if (browser.isNS)
    event.preventDefault();
}

function resizeStop(event) {

  // Stop capturing mousemove and mouseup events.

  if (browser.isIE) {
    document.detachEvent("onmousemove", resizeGo);
    document.detachEvent("onmouseup",   resizeStop);
  }
  if (browser.isNS) {
    document.removeEventListener("mousemove", resizeGo,   true);
    document.removeEventListener("mouseup",   resizeStop, true);
  }
}

function DOMAdd(html, id)
{
	var id = id || 'desktop';
	document.getElementById(id).innerHTML += html;
}

function DOMDelete(id)
{
	var obj = document.getElementById(id);
	obj.parentNode.removeChild(obj);
}

function getXmlHttpObject(){
    var http=false;
    try {http=new XMLHttpRequest();} catch (e1){
    try {http=new ActiveXObject("Msxml2.xmlhttp");} catch (e2){
    try {http=new ActiveXObject("Microsoft.xmlhttp");} catch (e3){http=false;}}}
    return http;
}

function divine_ajax(url,request,callback,xml)
{
	var http = getXmlHttpObject();
	var mode = request?"POST":"GET";
	var xml = xml || false;
    http.open(mode, url, true);
	if(mode=="POST"){
		http.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	}
	if(xml==true){
		http.onreadystatechange=function(){ if(http.readyState==4){ callback(http.responseXML); } };
	} else {
    	http.onreadystatechange=function(){ if(http.readyState==4){ callback(http.responseText); } };
	}
    http.send(request);
}

divine_system.prototype.setWallpaper = function(img)
{
	document.body.background = img;
}

divine_system.prototype.setTheme = function(theme, path)
{
	var path = path || false;
	if(path){
		document.getElementById('theme').href=path + theme + '/' + theme + '.css';
	} else {
		document.getElementById('theme').href='themes/' + theme + '/' + theme + '.css';
	}
}

divine_system.prototype.setRightClick = function(obj)
{
	var o = document.getElementById(obj);
	if(o){
		if (browser.isIE) {
    		o.attachEvent("oncontextmenu", divine.rightClick);
  		}
  		if (browser.isNS) {
    		o.addEventListener("contextmenu", divine.rightClick, true);
  		}
	} else {
		return false;
	}
}

divine_system.prototype.clearRightClick = function(obj)
{
	var o = document.getElementById(obj);
	if(o){
		if (browser.isIE) {
    		o.detachEvent("oncontextmenu", divine.rightClick);
  		}
  		if (browser.isNS) {
    		o.removeEventListener("contextmenu", divine.rightClick, true);
  		}
	} else {
		return false;
	}
}

divine_system.prototype.rightClick = function(event, id)
{
	var node;
	
	if(id){
		node = document.getElementById(id);
	} else if (browser.isIE){
      node = window.event.srcElement;
	} else if (browser.isNS){
      node = event.target;
	}
	if (node.nodeType == 3){
      node = node.parentNode;
  	}
	
	if (browser.isIE) {
    	x = window.event.clientX + document.documentElement.scrollLeft
    	  + document.body.scrollLeft;
    	y = window.event.clientY + document.documentElement.scrollTop
    	  + document.body.scrollTop;
	}
  	if (browser.isNS) {
    	x = event.clientX + window.scrollX;
    	y = event.clientY + window.scrollY;
  	}
	
	var obj = document.getElementById(node.id+'rc');
	if(obj){
		obj.style.left = x + 'px';
		obj.style.top = y + 'px';
		obj.style.display = 'block';
	}
	if (browser.isIE) {
    	document.attachEvent("onmouseup", killRightClick);
    	window.event.cancelBubble = true;
    	window.event.returnValue = false;
	}
  	if (browser.isNS) {
    	document.addEventListener("mouseup", killRightClick, true);
    	event.preventDefault();
	}
}

function killRightClick(event, id)
{
	var node;
	
	if(id){
		node = document.getElementById(id);
	} else if (browser.isIE){
      node = window.event.srcElement;
	} else if (browser.isNS){
      node = event.target;
	}
	if (node.nodeType == 3){
      node = node.parentNode;
  	}
	var n = document.getElementById(node.id+'rc');
	if(n){
		n.style.display = 'none';
	}
	
	if (browser.isIE) {
		document.detachEvent("onmouseup", killRightClick);
	}
	if (browser.isNS) {
		document.removeEventListener("mouseup", killRightClick, true);
	}
}

divine_system.prototype.init = function ()
{
	divine.resize();
	var menu = new divine_menu();
	menu.title = 'd';
	menu.icon = 'img/divine_widget';
	menu.iconW = 11;
	menu.iconH = 15;
	menu.addItem('divine Website', 'openBrowser(\'http://www.notanos.com\');');
	menu.addItem('Send Comment', 'openCommentWindow();');
	menu.addSep();
	menu.addItem('Logout', 'index.php?logout=true', true);
	menu.add();
	menu = new divine_menu();
	menu.title = 'File';
	menu.addItem('New Window', 'openTestWindow();');
	menu.addSep();
	menu.addItem('Close All', 'for(x in divine_windows){ closeWind(divine_windows[x].id); }');
	menu.add();
	menu = new divine_menu();
	menu.title = 'Edit';
	menu.addItem('Undo', '');
	menu.addSep();
	menu.addItem('Copy', '');
	menu.addItem('Paste', '');
	menu.addItem('Preferences. . .', '');
	menu.add();
	var w = new divine_window();
	w.title = divine.title;
	w.position = 'absolute';
	w.width = '268px';
	w.height = '100px';
	w.position = 'center';
	w.movable = 'n';
	w.resizable = 'n';
	w.modal = 'y';
	w.content = '<center><img src="img/divine_logo.jpg" width="260" height="80" border="0" alt="divine ALPHA" /><br/><span class="systemtext" style="color: #3584ba">Starting Up. . .</span><br/></center>';
	w.add();
	w.run('var t = setTimeout("DOMDelete(\'' + w.id + '\'); openWelcomeWindow();", 2000);');
	divine.setTheme('divine');
	divine.setDesktop();
	divine.setWallpaper('wallpapers/rockies.jpg');
	var m = new divine_menu(true);
	m.addItem('Hey', 'alert(\'Hey!\');');
	m.addItem('New Window', 'openTestWindow();');
	m.addItem('Close All', 'for(x in divine_windows){ closeWind(divine_windows[x].id); }');
	m.addSep();
	m.addItem('divine Website', 'openBrowser(\'http://www.notanos.com\');');
	m.addItem('Send Comment', 'openCommentWindow();');
	m.addSep();
	m.addItem('Logout', 'index.php?logout=true', true);
	m.make('desktop');
	m.add();
	divine.setRightClick('desktop');
	var i = new divine_icon();
	i.title = 'My Computer';
	i.path = 'My Computer';
	i.type = 'computer';
	i.add();
	var testicon = new divine_icon();
	testicon.title = 'Open a Test Window';
	testicon.icon = 'script';
	testicon.action = 'openTestWindow();';
	testicon.add();
	
	var forumicon = new divine_icon();
	forumicon.title = 'Browser';
	forumicon.type = 'html';
	forumicon.icon = 'browser';
	forumicon.path = 'http://www.notanos.com/';
	forumicon.add();
	
	divine_ajax('server.php','action=getFiles&path=desktop', handleXML, true);
}

divine_system.prototype.run = function(which) {
	var app = divine_icons[which];
	//run . . .
}

function editIconText(which, done)
{
	var done = done || false;
	var icon = divine_icons[which];
	if(icon.editing==true && done==true){
		var node = document.getElementById(which + 'text');
		icon.title = document.getElementById(which + 'textEdit').value;
		node.innerHTML = icon.title.wordWrap(20, '<br/>', false);
		delete icon.editing;
	} else if(icon.editing==false || !icon.editing) {
		for(x in divine_icons){
			if(divine_icons[x].editing==true){
				var node = document.getElementById(x + 'text');
				divine_icons[x].title = document.getElementById(x + 'textEdit').value;
				node.innerHTML = divine_icons[x].title;
				delete divine_icons[x].editing;
			}
		}
		var node = document.getElementById(which + 'text');
		node.innerHTML = '<input type="text" class="text" id="' + which + 'textEdit" value="' + icon.title + '" size="' + icon.title.length + '" maxlength="63" onkeypress="this.size=this.value.length+2" onblur="editIconText(\'' + which + '\', true);" style="border: 0px; padding: 1px; text-align: center;" />';
		icon.editing=true;
	}
}

function openTestWindow()
{
	var testwindow = new divine_window();
	testwindow.title = 'Test Window';
	testwindow.width = '400px';
	testwindow.height = '300px';
	testwindow.position = 'center';
	testwindow.content = '<center><p style="color: red; font-family: Verdana; font-size: 24px;">Hello, World!</p></center>';
	testwindow.minWidth = '300px';
	testwindow.maxWidth = '600px';
	testwindow.minHeight = '200px';
	testwindow.maxHeight = '400px';
	testwindow.add();
}

function openWelcomeWindow()
{
	var hi = new divine_window();
	hi.title = 'Welcome to divine!';
	hi.position = 'center';
	hi.content = '<p style="padding: 4px; font-family: Verdana; font-size: 12px; text-align: center;">Welcome to divine, the Dynamic, Interactive, Virtual InterNet Environment. Feel free to look around and try out the desktop experience, and keep up with the latest divine development efforts at <a href="http://www.notanos.com" target="_blank">www.NotAnOS.com</a><br/><br/>- the developer</p>';
	hi.add();
	var whatsnew = new divine_window();
	whatsnew.title = 'Whats New';
	whatsnew.position = 'topright';
	whatsnew.content = '<ul style="margin-left: 16px; padding: 4px; font-family: Verdana; font-size: 12px;"><li>Updated theme</li><li>New folder browsing</li><li>Expanded window positioning</li><li>New text file editor</li><li>Improved web browser</li><li>Fixed window index issues</li><li>General code cleanup</li><li>And more!</li></ul><p style="padding: 4px; font-family: Verdana; font-size: 12px; text-align: center;">Like what you see?<br/><a href="#" onclick="openCommentWindow();">Comments</a></p>';
	whatsnew.add();
}

function openCommentWindow()
{
	var comment = new divine_window();
	comment.title = 'Send Comment';
	comment.resizable = 'n';
	comment.width = '250px';
	comment.height = '200px';
	comment.position = 'center';
	comment.content = '<p style="padding: 4px; font-family: Verdana; font-size: 10px;">Please be helpful with your comments, and remember that this is a work in progress.</p><textarea style="font-family: Verdana; font-size: 10px; width: 238px; height: 100px;"></textarea><br/><center><input style="font-family: Verdana; font-size: 10px;" type="button" value="Send Comment" onclick="sendComment(this);"></center>';
	comment.add();
}


function sendComment(me)
{
	divine_ajax('server.php', 'action=sendComment&comment=' + me.parentNode.parentNode.childNodes[1].value, handleXML, true);
	me.parentNode.parentNode.innerHTML = '<br/><br/><p style="font-family: Verdana; font-size: 14px; color: blue; text-align: center; font-weight: bold;">Comment sent! Thank you for making divine better!</p>';
}

function openHTML(which)
{
	var html = divine_icons[which];
	openBrowser(html.path);
}

function openBrowser(path)
{
	var w = new divine_window();
	w.title = 'Browsing: ' + path;
	w.width = '600px';
	w.height = '400px';
	w.position = 'center';
	w.dragOpacity = 1.0;
	w.content = '<div style="height: 24px; padding: 2px; background-color: #cccccc; border-bottom: 1px solid #666666; font-family: Verdana; font-size: 9px;"><strong>URL:</strong><input type="text" value="' + path + '" style="font-family: Verdana; font-size: 9px;" size="60" /><input type="submit" value="Go" onclick="divine_windows[\'w' + (getCount('w')+1) + '\'].setTitle(\'Browsing: \' + this.parentNode.childNodes[1].value); this.parentNode.parentNode.childNodes[1].src=this.parentNode.childNodes[1].value;"  style="font-family: Verdana; font-size: 9px;"/></div><iframe src="' + path + '" width="100%" style="height: 376px;" frameborder="0" scrolling="auto"></iframe>';
	w.minWidth = '300px';
	w.maxWidth = '800px';
	w.minHeight = '400px';
	w.maxHeight = '400px';
	w.add();
}

function openEditor(which)
{
	var file = divine_icons[which];
	divine_ajax('server.php', 'action=getFile&path=' + file.path + '/' + file.title, handleXML, true);
}

function openEditorResponse(xml)
{
	var path = xml.documentElement.getAttribute('path');
	var results = xml.getElementsByTagName('content');
	var win = new divine_window();
	win.title = 'Editing: ' + path;
	win.width = '300px';
	win.height = '420px';
	win.resizable = 'y';
	win.position = 'stagger';
	win.overflow = 'auto';
	win.dragOpacity = 1.0;
	var tmpid = (getCount('w')+1);
	win.content = '<textarea id="w' + tmpid + 'editor" style="overflow: auto; top: 0px; left: 0px; border: 0px; font-family: Verdana; font-size: 10px; padding: 4px; height: 417px; width: 288px;">';
	win.onResize = 'document.getElementById("w' + tmpid + 'editor").style.height = parseInt(document.getElementById("w' + tmpid + '").style.height, 10) + "px"; document.getElementById("w' + tmpid + 'editor").style.width = (parseInt(document.getElementById("w' + tmpid + '").style.width, 10)-12) + "px"';
	win.content += results[0].firstChild.nodeValue;
	win.content += '</textarea>';
	win.add();
}

function openFolder(which)
{
	var folder = divine_icons[which];
	switch(folder.path){
		
		case 'My Computer':
			var w = new divine_window();
			w.title = 'My Computer';
			w.width = '400px';
			w.height = '200px';
			w.position = 'center';
			w.content = '<div class="explorer"><div class="actions"><strong>divine Explorer</strong><div><a href="#">System Information</a><br/><a href="#">Control Panel</a></div><br/><strong>Folder Actions</strong><div><a href="#">New Folder</a><br/><a href="#">Rename Folder</a><br/><a href="#">Delete Folder<a/></div></div><div class="view">&nbsp;</div>';
			w.minWidth = '300px';
			w.maxWidth = '600px';
			w.minHeight = '200px';
			w.maxHeight = '400px';
			w.add();
			break;
		
		default:
			divine_ajax('server.php', 'action=getFolder&path=' + folder.path + '/' + folder.title, handleXML, true);
			break;
	}
}

function openFolderResponse(xml)
{
	var path = xml.documentElement.getAttribute('path');
	var results = xml.getElementsByTagName('file');
	var win = new divine_window();
	win.title = 'Explorer - divine://' + path;
	win.width = '400px';
	win.height = '250px';
	win.resizable = 'y';
	win.position = 'stagger';
	win.overflow = 'auto';
	win.dragOpacity = 1.0;
	var tmpid = (getCount('w')+1);
	win.content = '<div id="w' + tmpid + 'explorer" style="overflow: auto; top: 0px; left: 0px; height: 227px; width: 396px;">';
	win.onResize = 'document.getElementById("w' + tmpid + 'explorer").style.height = parseInt(document.getElementById("w' + tmpid + '").style.height, 10) + "px"; document.getElementById("w' + tmpid + 'explorer").style.width = (parseInt(document.getElementById("w' + tmpid + '").style.width, 10)-4) + "px"';
	var numIcons = (getCount('divine_icons', true)+1);
	for(var i = 0; i<results.length; i++){
		var tmp = new divine_icon();
		tmp.title = results[i].firstChild.nodeValue;
		tmp.type = results[i].getAttribute("type");
		tmp.path = path;
		tmp.position = 'view';
		if(tmp.type == 'image'){
			var w = results[i].getAttribute("width");
			var h = results[i].getAttribute("height");
			tmp.action = 'openImage(\'' + 'i' + numIcons + '\', \'' + w + '\', \'' + h + '\');';
		} else if(tmp.type == 'audio' || tmp.type == 'video'){
			tmp.action = 'openMedia(\'' + 'i' + numIcons + '\');';
		} else if(tmp.type == 'folder'){
			tmp.action = 'openFolder(\'' + 'i' + numIcons + '\');';
		} else if(tmp.type == 'text'){
			tmp.action = 'openEditor(\'' + 'i' + numIcons + '\');';
		}
		tmp.make('i' + numIcons);
		divine_icons[tmp.id] = tmp;
		win.content += tmp.html;
		numIcons += 1;
	}
	win.content += '</div>';
	win.add();
}

function openImage(which, width, height)
{
	var file = divine_icons[which];
	var w = new divine_window();
	w.title = file.title;
	if(width >= 200){
		w.width = width + 'px';
	} else {
		w.width = '200px';
	}
	if(height >= 200){
		w.height = height + 'px';
	} else {
		w.height = '200px';
	}
	w.position = 'center';
	w.content = '<center><img src="' + file.path + '/' + file.title + '" width="100%" height="100%" border="0" alt="' + file.title + '"/></center>';
	w.minWidth = '125px';
	w.maxWidth = divine.windowWidth + 'px';
	w.minHeight = '125px';
	w.maxHeight = divine.windowHeight + 'px';
	w.add();
}

function openMedia(which)
{
	var file = divine_icons[which];
	var w = new divine_window();
	w.title = file.title;
	w.resizable = 'n';
	w.dragOpacity = '1.0';
	if(file.type == 'audio'){
		w.content = '<div><center><object width="300" height="42"><param name="src" value="' + file.path + '/' + file.title + '"><param name="autoplay" value="true"><param name="controller" value="true"><embed src="' + file.path + '/' + file.title + '" autostart="false" loop="false" width="300" height="42" controller="true"></embed></object></center></div>';
	} else {
		w.content = '<div><center><object width="300" height="42"><param name="src" value="' + file.path + '/' + file.title + '"><param name="autoplay" value="true"><param name="controller" value="true"><embed src="' + file.path + '/' + file.title + '" autostart="false" loop="false" width="300" height="42" controller="true"></embed></object></center></div>';
	}
	w.width = '320px';
	w.height = '64px';
	w.add();
}

function handleXML(xml)
{
	switch(xml.documentElement.nodeName){
		case 'divine_window':
			var w = new divine_window();
			w.xmlimport(xml);
			w.add();
			break;
		case 'divine_icon':
			var i = new divine_icon();
			i.xmlimport(xml);
			i.add();
			break;
		
		case 'getFilesResponse':
			var path = xml.documentElement.getAttribute('path');
			var results = xml.getElementsByTagName('file');
			for(var i = 0; i<results.length; i++){
				var tmp = new divine_icon();
				tmp.title = results[i].firstChild.nodeValue;
				tmp.type = results[i].getAttribute("type");
				tmp.path = path;
				if(tmp.type == 'image'){
					var w = results[i].getAttribute("width");
					var h = results[i].getAttribute("height");
					tmp.action = 'openImage(\'' + 'i' + (getCount('i')+1) + '\', \'' + w + '\', \'' + h + '\');';
				} else if(tmp.type == 'audio' || tmp.type == 'video'){
					tmp.action = 'openMedia(\'' + 'i' + (getCount('i')+1) + '\');';
				} else if(tmp.type == 'folder'){
					tmp.action = 'openFolder(\'' + 'i' + (getCount('i')+1) + '\');';
				} else if(tmp.type == 'text'){
					tmp.action = 'openEditor(\'' + 'i' + (getCount('i')+1) + '\');';
				}
				tmp.add();
			}
			break;
		
		case 'getFolderResponse':
			openFolderResponse(xml);
			break;
		
		case 'getFileResponse':
			openEditorResponse(xml);
			break;
			
		default:
			break;
	}
}