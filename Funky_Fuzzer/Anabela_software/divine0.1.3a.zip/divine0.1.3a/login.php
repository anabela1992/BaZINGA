<?php
	/*
		divine 0.1.3alpha
		login.php
	*/
	include_once('divine.php');
	if($_POST['goLogin']){
		$id = $db->GetSelectValue("SELECT `id` FROM `divine_user` WHERE `username` = '" . $_POST['user'] . "'", 'id');
		$test = new divine_user($id);
		if($test->id){
			if($test->password==$_POST['pass']){
				session_start();
				$_SESSION['user'] = $test->id;
				setcookie('divine', session_id(), time()+3600, '/');
				$output = '<strong style="color: green;">Login successful!</strong><br/><br/><a href="index.php">Continue</a>';
			} else {
				$output = '<strong style="color: red;">Incorrect password!</strong><br/><br/><a href="index.php">Continue</a>';
			}
		} else {
			$output = '<strong style="color: red;">User does not exist!</strong><br/><br/><a href="index.php">Continue</a>';
		}
	} else if($_REQUEST['forgotPassword']){
		if($_POST['getPassword']){
			$id = $db->GetSelectValue("SELECT `id` FROM `divine_user` WHERE `email` = '" . $_POST['email'] . "'", 'id');
			$test = new divine_user($id);
			if($test->id){
				$message = "Your divine account details:\r\n\r\nUsername:\r\n" . $test->username;
				$message .= "\r\n\r\nPassword:\r\n" . $test->password . "\r\n\r\n\r\n";
				$message .= "Thanks,\r\n- the divine Server\r\nhttp://demo.notanos.com/";
				mail($test->email, 'divine Account Details', $message, 'From: server@notanos.com' . "\r\n" . 'Reply-To: noreply@notanos.com');
				$output = '<strong style="color: blue;">Account details sent!</strong><br/><br/><a href="index.php">Continue</a>';
			} else {
				$output = '<strong style="color: red;">No user has that email!</strong><br/><br/><a href="index.php">Continue</a>';
			}
		} else {
			$output = '<form action="index.php?forgotPassword=true" method="post">
			Please enter your email to retrieve your account.<br/>
			<input type="text" name="email" style="font-size: 10px;"/><br/>
			<input type="submit" name="getPassword" style="font-size: 10px;" value="Retrieve Password"/>
			</form>';
		}
	} else if($_REQUEST['logout']){
		setcookie('divine', '', time()-3600, '/');
		$output = '<strong style="color: blue;">You have been successfully logged out!</strong><br/><br/><a href="index.php">Continue</a>';
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Welcome to divine</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css" media="all">
<!--
body {
	background-image: url(img/divine_login.jpg);
	background-attachment: fixed;
	background-position: center;
	background-repeat: repeat;
	margin: 0px;
	padding: 0px;
	border: 0px;
}

a {
	color: white;
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
-->
</style>
<script language="javascript" type="text/javascript">
<!--
function Browser()
{
	var ua, s, i;
	this.isIE  = false;
	this.isNS  = false;
	this.version = null;
	ua = navigator.userAgent;
	s = "MSIE";
	if ((i = ua.indexOf(s)) >= 0) {
		this.isIE = true;
		this.version = parseFloat(ua.substr(i + s.length));
		return;
	}
	s = "Netscape6/";
	if ((i = ua.indexOf(s)) >= 0) {
		this.isNS = true;
		this.version = parseFloat(ua.substr(i + s.length));
		return;
	}
	s = "Gecko";
	if ((i = ua.indexOf(s)) >= 0) {
		this.isNS = true;
		this.version = 6.1;
		return;
	}
}
var browser = new Browser();
var t;
function centerDiv(){
	var windowWidth, windowHeight;
	if (window.innerHeight) // all except Explorer
	{
		windowWidth = window.innerWidth;
		windowHeight = window.innerHeight;
	}
	else if (document.documentElement && document.documentElement.clientHeight) // Explorer 6 Strict Mode
	{
		windowWidth = document.documentElement.clientWidth;
		windowHeight = document.documentElement.clientHeight;
	}
	else if (document.body) // other Explorers
	{
		windowWidth = document.body.clientWidth;
		windowHeight = document.body.clientHeight;
	}
	var o = document.getElementById('login');
	if(browser.isNS){
		o.style.opacity = 0.05;
		o.style.visibility = 'visible';
		t = setTimeout("fadeIn('login');", 50);
	} else {
		o.style.opacity = 1.0;
		o.style.visibility = 'visible';
	}
	o.style.visibility = 'visible';
	o.style.left = (parseInt(windowWidth)/2)-(parseInt(o.style.width)/2) + 'px';
	o.style.top = (parseInt(windowHeight)/2) + 'px';
}

function pause(y)
{
	var y = y || false;
	if(browser.isIE){
		centerDiv();
		return true;
	}
	if(y == true){
		centerDiv();
	} else {
		t = setTimeout("pause(true);", 750);
	}
}

function fadeIn(which)
{
	var o = document.getElementById(which);
	if(parseFloat(o.style.opacity) < 1.0){
		o.style.opacity = parseFloat(o.style.opacity) + 0.05;
	}
	t = setTimeout("fadeIn('login');", 50);
}

function attachResize()
{
	if(browser.isIE){
		document.attachEvent("onresize", resize);
	}
	if(browser.isNS){
		window.addEventListener("resize", resize, true);
	}
}

function resize()
{
	var x,y;
	var windowWidth, windowHeight;
	if (window.innerHeight) // all except Explorer
	{
		windowWidth = window.innerWidth;
		windowHeight = window.innerHeight;
	}
	else if (document.documentElement && document.documentElement.clientHeight) // Explorer 6 Strict Mode
	{
		windowWidth = document.documentElement.clientWidth;
		windowHeight = document.documentElement.clientHeight;
	}
	else if (document.body) // other Explorers
	{
		windowWidth = document.body.clientWidth;
		windowHeight = document.body.clientHeight;
	}
	x = windowWidth;
	y = windowHeight;
	var m = document.getElementById('login');
	m.style.left = (x/2)-(parseInt(m.style.width)/2) + 'px';
	m.style.top = (y/2) + 'px';
}
// -->
</script>
</head>

<body onload="attachResize(); pause();">
<div id="login" style="background-color: #96c0d9; border: 1px solid #b1d4e9; color: white; font-family: Tahoma, sans-serif; font-size: 12px; width: 280px; position: absolute; visibility: hidden;">
<center>
<div style="padding: 10px;">
<?php
	if($output){
		echo $output;
	} else {
		?>
<strong>Welcome to divine</strong>
<br/>
<br/>
<strong>Use demo : demo</strong>
<br/>
<br/>
<form action="login.php" method="post">
Username:<br/>
<input type="text" name="user" style="font-size: 10px;" /><br/>
Password:<br/>
<input type="password" name="pass" style="font-size: 10px;" /><br/>
<input type="submit" name="goLogin" value="Login" style="font-size: 10px;"/>
</form>
<br/>
<a href="login.php?forgotPassword=true" title="Forgot password?">Forgot password?</a>
<br/>
<?php
	}
?>
</div>
</center>
</div>
</body>
</html>