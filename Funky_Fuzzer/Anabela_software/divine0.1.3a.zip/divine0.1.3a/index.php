<?php
	/*
		divine 0.1.3alpha
		by Elijah Horton
		
		This is a GNU General Public License project.
		www.notanos.com
		demo.notanos.com
		creator@notanos.com
	*/
	require('divine.php');
	
	if($_COOKIE['divine'] && !$_REQUEST['logout']){
		include('desktop.php');
	} else {
		include('login.php');
	}
?>