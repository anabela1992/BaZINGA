<?php

/* *********************************************************************
 *
 *  paCRUD - PHP Ajax CRUD Framework é um framework para
 *  desenvolvimento rápido de sistemas de informação web.
 *  Copyright (C) 2010 Emerson Casas Salvador <salvaemerson@gmail.com>
 *  e Odair Rubleski <orubleski@gmail.com>
 *
 *  This file is part of paCRUD.
 *
 *  paCRUD is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * ******************************************************************* */

pProtect('pacrud_obj_crud');

require_once($pacrudConfig['pacrudPath'].'/controller/obj_crud.php');
require_once($pacrudConfig['pacrudPath'].'/controller/obj_crud_field.php');
require_once($pacrudConfig['pacrudPath'].'/controller/search_obj_search.php');
require_once($pacrudConfig['pacrudPath'].'/controller/search_obj_crud1x1.php');
require_once($pacrudConfig['pacrudPath'].'/controller/search_obj_crud1xn.php');
require_once($pacrudConfig['pacrudPath'].'/controller/search_routines.php');
?>

<fieldset id="crudObjCrud_fieldset">
<legend><?php echo _('Objetos "paCRUD"'); ?></legend>

<div id="crudObjCrud_form">
	<div style="float:right"><button id="bt_mode" onclick="alternateMode()"><?php echo _('Modo Avançado'); ?></button></div>
	<span id="linkCode" style="display:none">
		<a href="" id="linkPhpCode" target="_blank"><?php echo _('Gerar código PHP para este objeto (controller)');?></a><br />
		<a href="" id="linkHtmlCode" target="_blank"><?php echo _('Gerar código HTML para este objeto (view)');?></a><br />
		<a href="" id="linkSqlCode" target="_blank"><?php echo _('Gerar código DDL SQL para este objeto');?></a><br />
		<a href="" id="linkSqlExecute" target="_blank"><?php echo _('Executar código DDL SQL para este objeto');?></a><br />
		<a href="" id="linkSqlInsert" target="_blank"><?php echo _('Gerar comandos SQL Insert para este objeto');?></a>
	</span>
	<table class="pacrudFormTable">
		<tr>
			<td class="pacrudFormLabel"><?php echo _('Nome do Objeto');?>:</td>
			<td class="pacrudFormFields"><input id="obj_name" type="text" size="40" autofocus="autofocus" />*</td>
		</tr>
		<tr>
			<td class="pacrudFormLabel"><?php echo _('Título da Janela');?> (title):</td>
			<td class="pacrudFormFields"><input id="obj_title" type="text" size="40" /></td>
		</tr>
		<tr>
			<td class="pacrudFormLabel"><?php echo _('Schema da Tabela');?> (schema):</td>
			<td class="pacrudFormFields"><input id="obj_schema" type="text" size="40" /></td>
		</tr>
		<tr>
			<td class="pacrudFormLabel"><?php echo _('Nome da Tabela');?> (tableName):</td>
			<td class="pacrudFormFields"><input id="obj_tablename" type="text" size="40" />*</td>
		</tr>
		<tr>
			<td class="pacrudFormLabel"><?php echo _('Rotina');?> (routine):</td>
			<td class="pacrudFormFields"><input id="obj_routine" type="text" size="40" /><?php $searchRoutines->makeButton(); ?></td>
		</tr>
		<tr>
			<td class="pacrudFormLabel"><br /></td>
			<td class="pacrudFormFields"><input id="obj_capslock" type="checkbox" /><?php echo _('Tudo maiúsculo para todos os campos');?> (capsLock)</td>
		</tr>
	</table>
	<div id="advanced_mode_crud" style="display:none">
		<table class="pacrudFormTable">
			<tr>
				<td class="pacrudFormLabel" colspan="2"><hr /></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><br /></td>
				<td class="pacrudFormFields"><input id="obj_parent1x1" type="checkbox" onchange="crudObjCrud.visibleSon1x1();" /><?php echo _('Relacionamento 1x1');?> </td>
			</tr>
		</table>
	
		<div id="crudObjCrud1x1_form" style="display:none;">
			<table class="pacrudFormTable">
				<tr>
					<td class="pacrudFormLabel"><?php echo _('Objeto pai Relacionamento 1x1');?>:</td>
					<td class="pacrudFormFields"><input id="obj_name_parent1x1" type="text" size="40" /><?php $searchObjCrud1x1->makeButton(); ?></td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><?php echo _('Campo Condicional no Objeto Pai');?>:</td>
					<td class="pacrudFormFields"><input id="obj_parent_field_condition" type="text" size="40" /></td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><?php echo _('Valor da Condição');?>:</td>
					<td class="pacrudFormFields"><input id="obj_condition_value" type="text" size="40" /></td>
				</tr>
			</table>
		</div>
	
		<table class="pacrudFormTable">
			<tr>
				<td class="pacrudFormLabel"><?php echo _('Relacionamento 1xN');?> (parent1xN):</td>
				<td class="pacrudFormFields"><input id="obj_parent1xn" type="text" size="40" /><?php $searchObjCrud1xn->makeButton(); ?></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><?php echo _('Qtd Linhas da Tabela');?> (pageLines):</td>
				<td class="pacrudFormFields"><input id="obj_pagelines" type="text" size="9" /></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><?php echo _('Permissao Fixa');?> (permission):</td>
				<td class="pacrudFormFields"><input id="obj_permission" type="text" size="40" /></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><?php echo _('Incluir arquivo de cabeçalho');?> (includeHead):</td>
				<td class="pacrudFormFields"><input id="obj_include_head" type="text" size="40" /></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><?php echo _('Incluir arquivo de Rodapé');?> (includeFooter):</td>
				<td class="pacrudFormFields"><input id="obj_include_footer" type="text" size="40" /></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><?php echo _('Ação ao duplicar registro');?> (onDuplicate):</td>
				<td class="pacrudFormFields">
					<select id="obj_onduplicate">
						<option value=""></option>
						<option value="update">update</option>
<!--					<option value="error">error</option>-->
					</select>
				</td>
			</tr>

			<tr>
				<td class="pacrudFormLabel"><br /></td>
				<td class="pacrudFormFields"><input id="obj_list" type="checkbox" checked="checked" /><?php echo _('Possui Listagem');?> (list) </td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><br /></td>
				<td class="pacrudFormFields"><input id="obj_drawform" type="checkbox" /><?php echo _('Desenhar Formulário');?> (drawForm) </td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><br /></td>
				<td class="pacrudFormFields"><input id="obj_autoclick" type="checkbox" /><?php echo _('Auto Click');?> (autoclick) </td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><br /></td>
				<td class="pacrudFormFields"><input id="obj_debug" type="checkbox" /><?php echo _('Modo Depuração');?> (debug) </td>
			</tr>
		</table>
	</div>
	
	<table class="pacrudFormTable">
		<tr>
			<td class="pacrudFormLabel"><br /></td>
			<td class="pacrudFormFields">
				<?php $crudObjCrud->drawControls(); ?>
			</td>
		</tr>
	</table>
	
	<fieldset id="crudObjCrudField_conteiner" style="display:none;">
	<legend><?php echo _('Campos do objeto CRUD'); ?></legend>
	
		<div id="crudObjCrudField_form" style="display:none">
			<table class="pacrudFormTable">
				<tr>
					<td class="pacrudFormLabel"><br /></td>
					<td class="pacrudFormFields"><input id="field_pk" type="checkbox" /><?php echo _('Chave Primária');?> (pk) *</td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><?php echo _('Nome do campo');?> (name):</td>
					<td class="pacrudFormFields"><input id="field_name" type="text" size="40" />*</td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><?php echo _('Rótulo');?> (label):</td>
					<td class="pacrudFormFields"><input id="field_label" type="text" size="40" /></td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><?php echo _('Tipo de dado');?> (type):</td>
					<td class="pacrudFormFields">
						<select id="field_type">
							<option value="string"><?php echo _('texto'); ?></option>
							<option value="text"><?php echo _('texto longo'); ?></option>
							<option value="integer"><?php echo _('inteiro'); ?></option>
							<option value="serial"><?php echo _('inteiro auto incrementado'); ?></option>
							<option value="numeric"><?php echo _('numérico'); ?></option>
							<option value="date"><?php echo _('data'); ?></option>
							<option value="time"><?php echo _('hora'); ?></option>
							<option value="timestamp"><?php echo _('data e hora'); ?></option>
							<option value="boolean"><?php echo _('boleano'); ?></option>
						</select>*
					</td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><?php echo _('Tamanho');?> (size):</td>
					<td class="pacrudFormFields"><input id="field_size" type="text" size="10" /></td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><br /></td>
					<td class="pacrudFormFields"><input id="field_notnull" type="checkbox" checked="checked" /><?php echo _('Não pode ser nulo');?> (notNull)</td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><br /></td>
					<td class="pacrudFormFields"><input id="field_visible" type="checkbox" checked="checked" /><?php echo _('Visível na listagem');?> (visible)</td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><br /></td>
					<td class="pacrudFormFields"><input id="field_readonly" type="checkbox" /><?php echo _('Somente leitura');?> (readonly)</td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><br /></td>
					<td class="pacrudFormFields"><input id="field_capslock" type="checkbox" /><?php echo _('Tudo maiúsculo para este campo');?> (capsLock)</td>
				</tr>
			</table>
			<div id="advanced_mode_field" style="display:none">
				<table class="pacrudFormTable">
					<tr>
						<td class="pacrudFormLabel" colspan="2"><hr /></td>
					</tr>
					<tr>
						<td class="pacrudFormLabel"><?php echo _('id html');?> (fieldId):</td>
						<td class="pacrudFormFields"><input id="field_fieldid" type="text" size="40" /></td>
					</tr>
					<tr>
						<td class="pacrudFormLabel"><?php echo _('Relação com pacrudSearch');?> (search):</td>
						<td class="pacrudFormFields"><input id="field_search" type="text" size="40" /><?php $searchObjSearch->makeButton(); ?></td>
					</tr>
					<tr>
						<td class="pacrudFormLabel"><?php echo _('Ordenação');?> :</td>
						<td class="pacrudFormFields"><input id="field_order" type="text" size="10" /></td>
					</tr>
					<tr>
						<td class="pacrudFormLabel"><?php echo _('Valor padrão');?> (default):</td>
						<td class="pacrudFormFields"><input id="field_default" type="text" size="40" /></td>
					</tr>
					<tr>
						<td class="pacrudFormLabel"><?php echo _('Código HTML');?> (formCode):</td>
						<td class="pacrudFormFields"><textarea id="field_formcode" cols="30" rows="3"></textarea></td>
					</tr>
					<tr>
						<td class="pacrudFormLabel"><br /></td>
						<td class="pacrudFormFields"><input id="field_virtual" type="checkbox" /><?php echo _('Campo Virtual (pertence a outra tabela)');?> (virtual)</td>
					</tr>
					<tr>
						<td class="pacrudFormLabel"><br /></td>
						<td class="pacrudFormFields"><input id="field_nocreate" type="checkbox" /><?php echo _('Não participa do Create');?> (nocreate)</td>
					</tr>
					<tr>
						<td class="pacrudFormLabel"><br /></td>
						<td class="pacrudFormFields"><input id="field_nohtml" type="checkbox" /><?php echo _('Não desenhar o campo na tela');?> (nohtml)</td>
					</tr>
				</table>
			</div>
			<table class="pacrudFormTable">
				<tr>
					<td class="pacrudFormLabel"><br /></td>
					<td class="pacrudFormFields"><?php $crudObjCrudField->drawControls(); ?></td>
				</tr>
			</table>
		</div>
		<?php $crudObjCrudField->drawCrudList(); ?>
		
	</fieldset>
	<br />
	* <?php echo _('campos de preenchimento obrigatório'); ?>
</div>

<?php
$searchObjSearch->addFieldReturn('obj_name','field_search');
$searchObjCrud1x1->addFieldReturn('obj_name','obj_name_parent1x1');
$searchObjCrud1xn->addFieldReturn('obj_name','obj_parent1xn');
$searchRoutines->addFieldReturn('routine','obj_routine');

$searchObjSearch->crudState('crudObjCrud');
$searchObjCrud1x1->crudState('crudObjCrud');
$searchObjCrud1xn->crudState('crudObjCrud');
$searchRoutines->crudState('crudObjCrud');

$crudObjCrud->drawCrudList();
?>

</fieldset>

<script type="text/javascript">
	crudObjCrud.onStateChange = function() {
		if (this.state == 'view') {
			var linkPhp = '../controller/crud.php?objName='+document.getElementById('obj_name').value+'&phpcode';
			var linkHtml = '../controller/crud.php?objName='+document.getElementById('obj_name').value+'&htmlcode';
			var linkSql = '../controller/crud.php?objName='+document.getElementById('obj_name').value+'&ddl';
			var linkExecSql = '../controller/crud.php?objName='+document.getElementById('obj_name').value+'&executeddl';
			var linkSqlInsert = '../controller/crud.php?objName='+document.getElementById('obj_name').value+'&sqlInsert';
			document.getElementById('linkPhpCode').setAttribute('href',linkPhp);
			document.getElementById('linkHtmlCode').setAttribute('href',linkHtml);
			document.getElementById('linkSqlCode').setAttribute('href',linkSql);
			document.getElementById('linkSqlExecute').setAttribute('href',linkExecSql);
			document.getElementById('linkSqlInsert').setAttribute('href',linkSqlInsert);
			document.getElementById('linkCode').style.display = 'block';
		}
		else {
			document.getElementById('linkCode').style.display = 'none';
		}
		return true;
	}
	
	function alternateMode() {
		if (document.getElementById('advanced_mode_crud').style.display == 'none') {
			document.getElementById('bt_mode').innerHTML = '<?php echo _('Modo Básico'); ?>';
			document.getElementById('advanced_mode_crud').style.display = 'block';
			document.getElementById('advanced_mode_field').style.display = 'block';
		}
		else {
			document.getElementById('bt_mode').innerHTML = '<?php echo _('Modo Avançado'); ?>';
			document.getElementById('advanced_mode_crud').style.display = 'none';
			document.getElementById('advanced_mode_field').style.display = 'none';
		}
	}
</script>
