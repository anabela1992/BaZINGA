<?php
include($pacrudConfig['pacrudPath'].'/view/submission.php');
