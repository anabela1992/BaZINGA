<?php
require_once('pacrud.php');
pProtect('pacrud_groups');

require_once($pacrudConfig['pacrudPath'].'/controller/groups.php');
require_once($pacrudConfig['pacrudPath'].'/controller/groups_syslogin.php');
require_once($pacrudConfig['pacrudPath'].'/controller/search_users.php');
?>

<fieldset>
<legend><?php echo _('Grupos de Usuários'); ?></legend>

<div id="crudGroups_form">
	<br />
	<table class="pacrudFormTable">
		<tr>
			<td class="pacrudFormLabel"><?php echo _('Nome do grupo'); ?>:</td>
			<td class="pacrudFormFields"><input id="groupname" type="text" size="45" autofocus="autofocus" />*</td>
		</tr>
		<tr>
			<td class="pacrudFormLabel"></td>
			<td class="pacrudFormFields"><input id="enabled" type="checkbox" checked="checked" /> <?php echo _('Ativo'); ?></td>
		</tr>
		<tr>
			<td class="pacrudFormLabel"></td>
			<td class="pacrudFormFields"><?php $crudGroups->drawControls(); ?></td>
		</tr>
	</table>
	
	<fieldset id="crudGroupsSyslogin_conteiner" style="display:none">
	<legend><?php echo _('Usuários que participam deste grupo'); ?></legend>
		<div id="crudGroupsSyslogin_form" style="display:none">
			<table class="pacrudFormTable">
				<tr>
					<td class="pacrudFormLabel"><?php echo _('Usuário'); ?>:</td>
					<td class="pacrudFormFields"><input id="username" type="text" size="45" /><?php $searchUsers->makeButton(); ?>*</td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"></td>
					<td class="pacrudFormFields"><?php $crudGroupsSyslogin->drawControls(); ?></td>
				</tr>
			</table>
		</div>
		<?php $crudGroupsSyslogin->drawCrudList(); ?>
	</fieldset>
	<br />
	* <?php echo _('campos de preenchimento obrigatório'); ?>
</div>

<?php 
$crudGroups->drawCrudList(); 
$searchUsers->addFieldReturn('username','username');
$searchUsers->crudState('crudGroupsSyslogin');

?>

</fieldset>
