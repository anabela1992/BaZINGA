<?php

/* *********************************************************************
 *
 *  paCRUD - PHP Ajax CRUD Framework é um framework para
 *  desenvolvimento rápido de sistemas de informação web.
 *  Copyright (C) 2010 Emerson Casas Salvador <salvaemerson@gmail.com>
 *  e Odair Rubleski <orubleski@gmail.com>
 *
 *  This file is part of paCRUD.
 *
 *  paCRUD is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * ******************************************************************* */

pProtect('pacrud_obj_search');

require_once($pacrudConfig['pacrudPath'].'/controller/obj_search.php');
require_once($pacrudConfig['pacrudPath'].'/controller/obj_search_field.php');
?>

<fieldset id="crudObjSearch_fieldset">
<legend><?php echo _('Objetos "pacrudSearch"'); ?></legend>

<div id="crudObjSearch_form">
	<div style="float:right"><button id="bt_mode" onclick="alternateMode()"><?php echo _('Modo Avançado'); ?></button></div>
	<span id="link" style="display:none">
		<a href="" id="linkCode" target="_blank"><?php echo _('Gerar código PHP para este objeto (controller)');?></a><br />
		<a href="" id="linkSqlInsert" target="_blank"><?php echo _('Gerar comandos SQL Insert para este objeto');?></a>
	</span>
	<table class="pacrudFormTable">
		<tr>
			<td class="pacrudFormLabel"><?php echo _('Nome do Objeto'); ?>:</td>
			<td class="pacrudFormFields"><input id="obj_name" type="text" size="30" autofocus="autofocus" />*</td>
		</tr>
		<tr>
			<td class="pacrudFormLabel"><?php echo _('Título da Janela'); ?> (title):</td>
			<td class="pacrudFormFields"><input id="obj_title" type="text" size="30" /></td>
		</tr>
		<tr>
			<td class="pacrudFormLabel"><?php echo _('Schema da Tabela'); ?> (schema):</td>
			<td class="pacrudFormFields"><input id="obj_schema" type="text" size="30" /></td>
		</tr>
		<tr>
			<td class="pacrudFormLabel"><?php echo _('Nome da Tabela'); ?> (tableName):</td>
			<td class="pacrudFormFields"><input id="obj_tablename" type="text" size="30" />*</td>
		</tr>
	</table>
	<div id="advanced_mode_search" style="display:none">
		<table class="pacrudFormTable">
			<tr>
				<td colspan="2"><hr /></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><?php echo _('Qtd Linhas da Tabela'); ?> (pageLines):</td>
				<td class="pacrudFormFields"><input id="obj_pagelines" type="text" size="9" /></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><br /></td>
				<td class="pacrudFormFields"><input id="obj_modal" type="checkbox" checked="checked" /><?php echo _('Modal'); ?> (modal)</td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><br /></td>
				<td class="pacrudFormFields"><input id="obj_autofilter" type="checkbox" checked="checked" /><?php echo _('Auto Filtro'); ?> (autoFilter)</td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><br /></td>
				<td class="pacrudFormFields"><input id="obj_debug" type="checkbox" /><?php echo _('Modo Depuração'); ?> (debug)</td>
			</tr>
		</table>
	</div>
	<table class="pacrudFormTable">
		<tr>
			<td class="pacrudFormLabel"><br /></td>
			<td class="pacrudFormFields">
				<?php $crudObjSearch->drawControls(); ?>
			</td>
		</tr>
	</table>
	
	<fieldset id="crudObjSearchField_conteiner" style="display:none;">
	<legend><?php echo _('Campos do objeto "pacrudSearch"'); ?></legend>
	
		<div id="crudObjSearchField_form" style="display:none">
			<table class="pacrudFormTable">
				<tr>
					<td class="pacrudFormLabel"><br /></td>
					<td class="pacrudFormFields"><input id="field_pk" type="checkbox" /><?php echo _('Chave Primária');?> (pk) *</td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><?php echo _('Nome do campo');?> (name):</td>
					<td class="pacrudFormFields"><input id="field_name" type="text" size="30" />*</td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><?php echo _('Rótulo');?> (label):</td>
					<td class="pacrudFormFields"><input id="field_label" type="text" size="30" /></td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><?php echo _('Tipo de dado');?> (type):</td>
					<td class="pacrudFormFields">
						<select id="field_type">
							<option value="string"><?php echo _('texto'); ?></option>
							<option value="text"><?php echo _('texto longo'); ?></option>
							<option value="integer"><?php echo _('inteiro'); ?></option>
							<option value="serial"><?php echo _('inteiro auto incrementado'); ?></option>
							<option value="numeric"><?php echo _('numérico'); ?></option>
							<option value="date"><?php echo _('data'); ?></option>
							<option value="time"><?php echo _('hora'); ?></option>
							<option value="timestamp"><?php echo _('data e hora'); ?></option>
							<option value="boolean"><?php echo _('boleano'); ?></option>
						</select>*
					</td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><br /></td>
					<td class="pacrudFormFields"><input id="field_visible" type="checkbox" /><?php echo _('Visível');?> (visible)</td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><?php echo _('Ordenação');?> :</td>
					<td class="pacrudFormFields"><input id="field_order" type="text" size="10" /></td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"><br /></td>
					<td class="pacrudFormFields">
						<?php $crudObjSearchField->drawControls(); ?>
					</td>
				</tr>
			</table>
		</div>
		<?php $crudObjSearchField->drawCrudList(); ?>
	</fieldset>
	<br />
	* <?php echo _('campos de preenchimento obrigatório'); ?>
</div>

<?php $crudObjSearch->drawCrudList(); ?>

</fieldset>

<script type="text/javascript">
	crudObjSearch.onStateChange = function() {
		if (this.state == 'view') {
			var link = '../controller/search.php?objName='+document.getElementById('obj_name').value+'&phpcode';
			var linkSqlInsert = '../controller/search.php?objName='+document.getElementById('obj_name').value+'&sqlInsert';
			document.getElementById('linkCode').setAttribute('href',link);
			document.getElementById('linkSqlInsert').setAttribute('href',linkSqlInsert);
			document.getElementById('link').style.display = 'block';
		}
		else {
			document.getElementById('link').style.display = 'none';
		}
		return true;
	}

	function alternateMode() {
		if (document.getElementById('advanced_mode_search').style.display == 'none') {
			document.getElementById('bt_mode').innerHTML = '<?php echo _('Modo Básico'); ?>';
			document.getElementById('advanced_mode_search').style.display = 'block';
		}
		else {
			document.getElementById('bt_mode').innerHTML = '<?php echo _('Modo Avançado'); ?>';
			document.getElementById('advanced_mode_search').style.display = 'none';
		}
	}
</script>
