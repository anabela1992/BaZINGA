<?php
require_once('pacrud.php');
pProtect('pacrud_users');

require_once($pacrudConfig['pacrudPath'].'/controller/users.php');
require_once($pacrudConfig['pacrudPath'].'/controller/syslogin_groups.php');
require_once($pacrudConfig['pacrudPath'].'/controller/search_groups.php');
?>

<fieldset>
<legend><?php echo _('Usuários'); ?></legend>
<div id="crudUsers_form">
	<br />
	<table class="pacrudFormTable">
		<tr>
			<td class="pacrudFormLabel"><?php echo _('Usuário'); ?>:</td>
			<td class="pacrudFormFields"><input id="username" type="text" size="45" autofocus="autofocus" />*</td>
		</tr>
		<tr>
			<td class="pacrudFormLabel"><?php echo _('Nome completo'); ?>:</td>
			<td class="pacrudFormFields"><input id="fullname" type="text" size="45" />*</td>
		</tr>
		<tr>
			<td class="pacrudFormLabel"></td>
			<td class="pacrudFormFields"><input id="enabled" type="checkbox" checked="checked" /> <?php echo _('Ativo'); ?></td>
		</tr>
		<tr>
			<td class="pacrudFormLabel"></td>
			<td class="pacrudFormFields"><?php $crudUsers->drawControls(); ?></td>
		</tr>
	</table>
	
	<fieldset id="crudSysloginGroups_conteiner" style="display:none">
	<legend><?php echo _('Grupos que este usuário participa'); ?></legend>
		<div id="crudSysloginGroups_form" style="display:none">
			<table class="pacrudFormTable">
				<tr>
					<td class="pacrudFormLabel"><?php echo _('Grupo'); ?>:</td>
					<td class="pacrudFormFields"><input id="groupname" type="text" size="45" /><?php $searchGroups->makeButton(); ?>*</td>
				</tr>
				<tr>
					<td class="pacrudFormLabel"></td>
					<td class="pacrudFormFields"><?php $crudSysloginGroups->drawControls(); ?></td>
				</tr>
			</table>
		</div>
		<?php $crudSysloginGroups->drawCrudList(); ?>
	</fieldset>
	<br />
	* <?php echo _('campos de preenchimento obrigatório'); ?>
</div>

<?php
$crudUsers->drawCrudList();
$searchGroups->addFieldReturn('groupname','groupname');
$searchGroups->crudState('crudSysloginGroups');
?>

</fieldset>
