<?php

/* *********************************************************************
 *
 *  paCRUD - PHP Ajax CRUD Framework é um framework para
 *  desenvolvimento rápido de sistemas de informação web.
 *  Copyright (C) 2010 Emerson Casas Salvador <salvaemerson@gmail.com>
 *  e Odair Rubleski <orubleski@gmail.com>
 *
 *  This file is part of paCRUD.
 *
 *  paCRUD is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * ******************************************************************* */

?>

		<h1><?php echo _('Bem vindo ao paCRUD Framework!'); ?></h1>

		<p><?php echo _('A equipe paCRUD preparou para você, algumas ferramentas que permitirão personalizar a aparência da sua aplicação. Veja a seguir algumas dicas de como configurar o paCRUD Framework.'); ?></p>

		<h2><?php echo _('Painel de Controle'); ?></h2>
		<p><?php echo _('No painel de controle você encontra alguns parâmetros e configurações para a sua aplicação. Você pode acessar o painel de controle através do menu sistema ou clicando <a href="index.php?page=pacrud_controlPanel">aqui</a>.'); ?></p>

		<h2><?php echo _('Por onde começar?'); ?></h2>
		<p><?php echo str_replace('%paCRUD%','<a href="index.php?page=pacrud_obj_crud">paCRUD</a>',str_replace('%pacrudSearch%','<a href="index.php?page=pacrud_obj_search">pacrudSearch</a>',
		_('Após as confgurações iniciais no painel de controle, você está pronto para criar seus objetos %paCRUD% e %pacrudSearch% utilizando os contrutores de objetos, disponíveis no menu "SISTEMA", lá é possível gerar o código para view, controller e ddl.')
		)); ?></p>

		<h2><?php echo _('Área de trabalho'); ?></h2>
		<p><?php echo _('Esta página que você está visualizando é a Área de trabalho da sua aplicação, ela ser pode facilmente personalizada. Basta criar um arquivo desktop.php na raiz da sua aplicação com o conteúdo que você desejar.'); ?></p>

		<h2><?php echo _('Pasta de trabalho'); ?></h2>
		<p><?php echo _('Existe um arquivo na raiz do paCRUD denominado "config_default.php", semelhante o app/pacrud.php. Atenção não altere este arquivo, ele poderá ser sobrescrito quando você atualizar o paCRUD. Mantenha suas configurações no arquivo app/pacrud.php.'); ?></p>

		<h2><?php echo _('Menu e controle de acesso'); ?></h2>
		<p><?php echo _('O paCRUD possui um sistema de menus dinâmicos, é possível definir permissões de acesso por grupos de usuários, de maneira que cada grupo de tenha seu menu personalizado, basta cadastrar suas configurações de acesso no menu sistema');
		echo '. <a href="http://wiki.pacrud.com.br/index.php/Entendendo_as_rotinas_e_menus" target="_blank">'._('Clique aqui').'</a> ';
		echo _('para conhecer melhor a ferramenta de controle de acesso e gerenciamento de menus.'); ?></p>
		<p><?php
		$pacrudUrlMenu = 'http://'.$_SERVER["SERVER_NAME"].$pacrudConfig['pacrudWebPath'].'/view/menu_xml.php?language='.$pacrudConfig['language'];
		$link = '<a href="'.$pacrudUrlMenu.'">'.$pacrudUrlMenu.'</a>';
		printf(_('Outra opção é criar um menu estático em formato XML, se essa for a sua escolha crie um arquivo menu.xml na pasta app seguindo o mesmo formato do menu de exemplo que pode pode ser acessado em %s. Recomendamos salvar o conteúdo deste link com o nome menu.xml e fazer alterações de acordo com suas necessidades.'),$link);
		?></p>

