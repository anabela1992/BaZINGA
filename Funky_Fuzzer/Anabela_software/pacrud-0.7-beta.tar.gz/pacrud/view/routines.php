<?php
require_once('pacrud.php');
pProtect('pacrud_routines');

require_once($pacrudConfig['pacrudPath'].'/controller/routines.php');
require_once($pacrudConfig['pacrudPath'].'/controller/routines_groups.php');
require_once($pacrudConfig['pacrudPath'].'/controller/routines_menus.php');
require_once($pacrudConfig['pacrudPath'].'/controller/search_groups.php');
require_once($pacrudConfig['pacrudPath'].'/controller/search_menus.php');

$image = pFileLocal2Web(pListFiles(dirname($_SERVER["SCRIPT_FILENAME"]),'(\.(png|jpg|jpeg|gif))','(\.(svn|git|md))'));
$datalistIcons = '<datalist id="list_icon">'."\n";
$datalistIcons .= '				  <option value="view/images/icons/example.png">'."\n";
$datalistIcons .= '				  <option value="view/images/icons/exclamation.png">'."\n";
$datalistIcons .= '				  <option value="view/images/icons/key.png">'."\n";
$datalistIcons .= '				  <option value="view/images/icons/system.png">'."\n";
$datalistIcons .= '				  <option value="view/images/icons/users.png">'."\n";
for ($i=0; $i < count($image); $i++) {
	$datalistIcons .= '				  <option value="app/'.$image[$i].'">'."\n";
}
$datalistIcons .= '				</datalist>'."\n";
?>

<fieldset>
<legend><?php echo _('Rotinas, permissões e menus'); ?></legend>

	<div id="crudRoutines_form">
		<br />
		<table class="pacrudFormTable">
			<tr>
				<td class="pacrudFormLabel"><?php echo _('Identificação'); ?>:</td>
				<td class="pacrudFormFields"><input id="routine" type="text" size="45" autofocus="autofocus" />* (<?php echo _('Não usar espaços') ?>)</td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><?php echo _('Link'); ?>:</td>
				<td class="pacrudFormFields"><input id="link" type="text" size="45" /></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><?php echo _('Descrição'); ?>:</td>
				<td class="pacrudFormFields"><input id="description" type="text" size="45" /></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"></td>
				<td class="pacrudFormFields"><input id="enabled" type="checkbox" checked="checked" /> <?php echo _('Ativo'); ?></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"></td>
				<td class="pacrudFormFields"><?php $crudRoutines->drawControls(); ?></td>
			</tr>
		</table>
	</div>

	<?php 
	$crudRoutines->drawCrudList();

	$pTabRoutines = new pacrudTab('pTabRoutines');
	$pTabRoutines->visible = false;
	$pTabRoutines->addTab('groups',_('Permissões por grupo de usuário'));
	$pTabRoutines->addTab('menus',_('Entradas no menu'));
	$pTabRoutines->htmlOpen(true);

	$pTabRoutines->htmlOpenTab(true,_('Permissões por grupo de usuário'));
	?>
	<div id="crudRoutinesGroups_form" style="display:none">
		<table class="pacrudFormTable">
			<tr>
				<td class="pacrudFormLabel"><?php echo _('Grupo'); ?>:</td>
				<td class="pacrudFormFields"><input id="groupname" type="text" size="45" /><?php $searchGroups->makeButton(); ?>*</td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"></td>
				<td class="pacrudFormFields"><input id="c" type="checkbox" checked="checked" /> <?php echo _('Inserir'); ?></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"></td>
				<td class="pacrudFormFields"><input id="r" type="checkbox" checked="checked" /> <?php echo _('Visualizar'); ?></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"></td>
				<td class="pacrudFormFields"><input id="u" type="checkbox" checked="checked" /> <?php echo _('Alterar'); ?></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"></td>
				<td class="pacrudFormFields"><input id="d" type="checkbox" checked="checked" /> <?php echo _('Apagar'); ?></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"></td>
				<td class="pacrudFormFields"><?php $crudRoutinesGroups->drawControls(); ?></td>
			</tr>
		</table>
	</div>
	<?php 
	$crudRoutinesGroups->drawCrudList();
	
	$pTabRoutines->htmlCloseTab(true);

	$pTabRoutines->htmlOpenTab(true,_('Entradas no menu'));
	
	?>
	<div id="crudRoutinesMenus_form">
		<input id="cod" type="hidden" />
		<table class="pacrudFormTable">
			<tr>
				<td class="pacrudFormLabel"><?php echo _('Menu Pai'); ?>:</td>
				<td class="pacrudFormFields" colspan="2"><input id="parent" type="text" size="5" /> <input id="parent_name" type="text" size="32" /> <?php $searchMenus->makeButton(); ?></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"><?php echo _('Rótulo'); ?>:</td>
				<td class="pacrudFormFields" colspan="2"><input id="caption" type="text" size="45" />*</td>
			</tr>
			<tr>
				<td class="pacrudFormLabel">Ícone:</td>
				<td class="pacrudFormFields" colspan="2">
					<input id="icon" list="list_icon" type="text" size="45" onChange="iconChange()" />
					<?php echo $datalistIcons; ?>
				</td>
				<td style="text-align:left" width="30%"><img id="icon_example" src="" alt="_" /></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"></td>
				<td class="pacrudFormFields" colspan="2"><input id="opened" type="checkbox" checked="checked" /> <?php echo _('Aberto'); ?></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"></td>
				<td class="pacrudFormFields" colspan="2"><input id="menuEnabled" type="checkbox" checked="checked" /> <?php echo _('Ativo'); ?></td>
			</tr>
			<tr>
				<td class="pacrudFormLabel"></td>
				<td class="pacrudFormFields" colspan="2"><?php $crudRoutinesMenus->drawControls(); ?></td>
			</tr>
		</table>
	</div>
	<?php
	$crudRoutinesMenus->drawCrudList();
	
	$pTabRoutines->htmlCloseTab(true);
	
	$pTabRoutines->htmlClose(true);
	
	echo '<br />'."\n";
	echo '* '._('campos de preenchimento obrigatório'); 
	
	$searchGroups->addFieldReturn('groupname','groupname');
	$searchGroups->crudState('crudRoutinesGroups');
	
	$searchMenus->addFieldReturn('cod','parent');
	$searchMenus->addFieldReturn('tree','parent_name');
	$searchMenus->crudState('crudRoutinesMenus');
	
	?>

</fieldset>

<script type="text/javascript">	
	crudRoutines.onStateChange = function() {
		if (crudRoutines.state == 'view') {			
			pTabRoutines.showTab('groups');
		}
		else {
			pTabRoutines.hide();
		}
	}
	
	function iconChange() {
		var icon = document.getElementById('icon').value;
		var iconExample = document.getElementById('icon_example');
		iconExample.src = '<?php echo $pacrudConfig['pacrudWebPath']; ?>/' + icon;
		if (icon == '') {
			iconExample.style.display = 'none';
		}
		else {
			iconExample.style.display = 'block';
		}
	}
	
	crudRoutinesMenus.onStateChange = function() {
		if (this.state == 'view') {
			iconChange();
		}
	}
</script>
