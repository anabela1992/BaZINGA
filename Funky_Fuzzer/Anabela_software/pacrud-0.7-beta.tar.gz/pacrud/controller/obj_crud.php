<?php

/* *********************************************************************
 *
 *  paCRUD - PHP Ajax CRUD Framework é um framework para
 *  desenvolvimento rápido de sistemas de informação web.
 *  Copyright (C) 2010 Emerson Casas Salvador <salvaemerson@gmail.com>
 *  e Odair Rubleski <orubleski@gmail.com>
 *
 *  This file is part of paCRUD.
 *
 *  paCRUD is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * ******************************************************************* */

require_once('../config_default.php');
require_once('../app/pacrud.php');
require_once($pacrudConfig['pacrudPath'].'/controller/connection_admin.php');

$schema = $pacrudConfig['loginSchema_pacrud'];
$xmlFile = $pacrudConfig['pacrudWebPath'].'/controller/obj_crud.php';

$crudObjCrud = new paCRUD('objName=crudObjCrud,xmlFile='.$xmlFile.',schema='.$schema.',tableName=obj_crud,title='._('Objetos "paCRUD"').',routine=pacrud_obj_crud');
$crudObjCrud->setConnection($pConnectionPacrud);
$crudObjCrud->addField('name=obj_name,label='._('Nome do Objeto').',notNull,pk');
$crudObjCrud->addField('name=obj_title,label='._('Título da Janela').' (title)');
$crudObjCrud->addField('name=obj_schema,label='._('Schema da Tabela').' (schema)');
$crudObjCrud->addField('name=obj_tablename,label='._('Nome da Tabela').' (tableName),notNull');
$crudObjCrud->addField('name=obj_routine,label='._('Rotina').' (routine)');
$crudObjCrud->addField('name=obj_capslock,label='._('Tudo maiúsculo').' (capsLock),type=boolean,notNull,visible=false');
/*********************************************************/
$crudObjCrud->addField('name=obj_parent1x1,label='._('Relacionamento 1x1').',type=boolean,visible=false');
$crudObjCrud->addField('name=obj_parent1xn,label='._('Relacionamento 1xN').' (parent1xN),visible=false');
$crudObjCrud->addField('name=obj_pagelines,label='._('Qtd Linhas da Tabela').' (pageLines),type=integer,visible=false');
$crudObjCrud->addField('name=obj_permission,label='._('Permissao Fixa').' (permission),visible=false');
$crudObjCrud->addField('name=obj_include_head,label='._('Incluir arquivo de cabeçalho').' (includeHead),visible=false');
$crudObjCrud->addField('name=obj_include_footer,label='._('Incluir arquivo de Rodapé').' (includeFooter),visible=false');
$crudObjCrud->addField('name=obj_onduplicate,label='._('Ação ao duplicar registro').' (onDuplicate),visible=false');
$crudObjCrud->addField('name=obj_list,label='._('List').' (list),type=boolean,visible=false,default=t');
$crudObjCrud->addField('name=obj_drawform,label='._('Desenhar Formulário').' (drawForm),type=boolean,visible=false');
$crudObjCrud->addField('name=obj_autoclick,label='._('Auto Click').' (autoclick),type=boolean,visible=false');
$crudObjCrud->addField('name=obj_debug,label='._('Modo Depuração').' (debug),type=boolean,visible=false');

$crudObjCrud1x1 = new paCRUD('objName=crudObjCrud1x1,xmlFile='.$xmlFile.',schema='.$schema.',tableName=obj_crud_1x1');
$crudObjCrud1x1->setConnection($pConnectionPacrud);
$crudObjCrud1x1->addField('name=obj_name,pk');
$crudObjCrud1x1->addField('name=obj_name_parent1x1,label=Pai 1x1,notNull');
$crudObjCrud1x1->addField('name=obj_parent_field_condition,label=Campo Condicional,notNull');
$crudObjCrud1x1->addField('name=obj_condition_value,label=Valor da Condição,notNull');
$crudObjCrud1x1->addParent1x1($crudObjCrud,'obj_parent1x1','t');

$crudObjCrud->autoInit();
