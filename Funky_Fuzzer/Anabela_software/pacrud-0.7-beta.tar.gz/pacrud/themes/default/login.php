<div class="pacrudLoginBackground">

	<div style="height:50px">&nbsp;</div>

	<span class="pacrudHeaderCenter">:appIdent: - :appName:</span>

	<div style="height:20px">&nbsp;</div>


	<fieldset class="pacrudLogin">
	<legend class="pacrudLoginLegend">:autentication:</legend>
		<br />
		<table align="center">
			<tr>
				<td style="text-align:right">:username:</td>
				<td>:inputUsername:</td>
			</tr>
			<tr>
				<td style="text-align:right">:password:</td>
				<td>:inputPassword:</td>
			</tr>
			<tr>
				<td><br /></td>
				<td style="text-align:left">:submit:</td>
			</tr>
		</table>
		<br />
	</fieldset>

	<div style="height:50px">&nbsp;</div>

	<div>
	:pacrudLogo:
	</div>

</div>
