<div class="pacrudContainer">
<div class="pacrudHeader">
	<div class="pacrudHeaderLeft">:shortcuts:</div>
	<div class="pacrudHeaderRight">:logoff:</div>
	<div class="pacrudHeaderCenter">:appIdent: - :appName:</div>
</div>
<div class="pacrudBody">
	<div class="pacrudMenuArea">
		<div class="pacrudFullName">:fullName: (:logoff:)</div>
		<div>:menu:</div>
	</div>
	<div class="pacrudDesktop">:desktop:</div>
</div>
<div class="clear"></div>
<div class="pacrudFooter">:footer:</div>
</div>
