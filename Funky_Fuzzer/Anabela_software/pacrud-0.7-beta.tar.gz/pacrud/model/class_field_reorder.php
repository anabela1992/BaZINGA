<?php

/* *********************************************************************
 *
 *  paCRUD - PHP Ajax CRUD Framework é um framework para
 *  desenvolvimento rápido de sistemas de informação web.
 *  Copyright (C) 2010 Emerson Casas Salvador <salvaemerson@gmail.com>
 *  e Odair Rubleski <orubleski@gmail.com>
 *
 *  This file is part of paCRUD.
 *
 *  paCRUD is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * ******************************************************************* */
 
class classFieldReorder extends paCRUD {
	
	private function reorderBefore() {
		$tableName = $this->param['tablename'];
		$schema = pGetSchema($this->param['schema'],$this->pConnection->sgdb());
		$objName = pFormatSql($_POST['new_obj_name'],'string');
		$fieldName = pFormatSql($_POST['new_field_name'],'string');
		$order = $_POST['new_field_order'];
		
		if ($order == '') {
			if ($this->pConnection->sqlQuery('SELECT count(*) FROM '.$schema.$tableName.' WHERE obj_name='.$objName.' AND NOT field_name='.$fieldName.';') == 0) {
				$order = 1;
			}
			else {
				$order = $this->pConnection->sqlQuery('SELECT max(field_order)+1 FROM '.$schema.$tableName.' WHERE obj_name='.$objName.' AND NOT field_name='.$fieldName.';');
			}
			$_POST['new_field_order'] = $order;
		}
		
		$sqlMore = 'SELECT * FROM '.$schema.$tableName.' WHERE obj_name='.$objName.' AND field_order >= '.$order.' AND NOT field_name='.$fieldName.' ORDER BY field_order;';
		$field = $this->pConnection->sql2Array($sqlMore);
		for ($i=0; $i < count($field); $i++) {
			$newOrder = $order + $i + 1;
			$fieldNameMore = pFormatSql($field[$i]['field_name'],'string');
			
			$sqlUpdate = 'UPDATE '.$schema.$tableName.' SET field_order='.$newOrder.' WHERE obj_name='.$objName.' AND field_name='.$fieldNameMore.';';
			$this->pConnection->sqlQuery($sqlUpdate);
		}
		
		return true;
	}
	
	public function beforeCreate() {
		return $this->reorderBefore();
	}
	
	public function beforeUpdate() {
		return $this->reorderBefore();
	}
	
	private function reorderAfter() {
		$tableName = $this->param['tablename'];
		$schema = pGetSchema($this->param['schema'],$this->pConnection->sgdb());
		$objName = pFormatSql($_POST['new_obj_name'],'string');
		
		$sqlMore = 'SELECT * FROM '.$schema.$tableName.' WHERE obj_name='.$objName.' ORDER BY field_order;';
		$field = $this->pConnection->sql2Array($sqlMore);
		for ($i=0; $i < count($field); $i++) {
			$newOrder = $i + 1;
			$fieldName = pFormatSql($field[$i]['field_name'],'string');
			
			if ($field[$i]['field_order'] != $newOrder) {
				$sqlUpdate = 'UPDATE '.$schema.$tableName.' SET field_order='.$newOrder.' WHERE obj_name='.$objName.' AND field_name='.$fieldName.';';
				$this->pConnection->sqlQuery($sqlUpdate);
			}
		}
		
		return true;
	}
	
	public function afterCreate() {
		return $this->reorderAfter();
	}
	
	public function afterUpdate() {
		return $this->reorderAfter();
	}
	
}

