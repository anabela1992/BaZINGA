<?php
require_once 'PHPUnit/Framework.php';

class classPacrudMysqlConnectionTest extends PHPUnit_Framework_TestCase {
	protected $fixtureConnection;

	protected function setUp() {
		// carrega as dependências
		require_once('../functions_globals.php');
		require_once('../class_mysql_connection.php');
		require_once('../class_connection.php');
		require_once('../../language/pt_br.php');
		
		// instancia a conexão
		$this->fixtureConnection = new pacrudConnection('sgdb=mysql,dbHost=localhost,dbPort=3306,dbName=db_pacrud,dbUserName=pacrud,dbPassword=pacrud');
	}

	public function testConstruct() {

		$this->assertFalse($this->fixtureConnection->connected());
	}
	
	public function testGetConnectionTrue() {
		$this->assertFalse(!$this->fixtureConnection->getConnection());
	}
	
	public function testGetConnectionFalse() {
		global $pacrudText;
		$this->fixtureConnection = new pacrudConnection('sgdb=mysql,dbHost=localhost,dbPort=3306,dbName=unknow,dbUserName=unknow,dbPassword=unknow');
		$this->assertFalse($this->fixtureConnection->getConnection());
		$this->assertEquals($this->fixtureConnection->getErr(),$pacrudText[23]);
	}
	
	public function testSqlQuery() {
		$this->assertEquals('hello world',$this->fixtureConnection->sqlQuery('SELECT \'hello world\';'));
	}
	
    protected function tearDown() {
    	// fecha conexão com o banco de dados
    	$this->fixtureConnection->disconnect();
    }
}
