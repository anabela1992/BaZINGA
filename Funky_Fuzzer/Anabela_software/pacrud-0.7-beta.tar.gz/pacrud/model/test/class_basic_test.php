<?php
require_once 'PHPUnit/Framework.php';

class classBasicTest extends PHPUnit_Framework_TestCase {
	protected $fixtureBasic;
	
	protected function setUp() {
		require_once('../class_basic.php');
		require_once('../functions_globals.php');
		$this->fixtureBasic = new pacrudBasic('test','');
	}

	public function testConstruct() {
		$this->assertEquals($this->fixtureBasic->error,'');
		$this->assertTrue(isset($this->fixtureBasic->field));
		$this->assertEquals('test',$this->fixtureBasic->name);
	}
	
	public function testAddField() {
		$testField = $this->fixtureBasic->addField('name=teste');
		$this->assertEquals($testField['name'],'teste');
		$this->assertEquals($testField['label'],'teste');
		$this->assertNull($testField['size']);
		$this->assertEquals($testField['type'],'string');
		$this->assertFalse($testField['notNull']);
	}
	
	public function testAddFieldLabel() {
		$testField = $this->fixtureBasic->addField('name=teste,label=TTT');
		$this->assertTrue($testField['label'] == 'TTT');
	}
	
	public function testAddFieldSize() {
		$testField = $this->fixtureBasic->addField('name=teste,size=10');
		$this->assertTrue($testField['size'] == '10');
	}
	
	public function testAddFieldType() {
		$testField = $this->fixtureBasic->addField('name=teste,type=integer');
		$this->assertTrue($testField['type'] == 'integer');
	}

	public function testAddFieldNotNull() {
		$testField = $this->fixtureBasic->addField('name=teste,notNull=true');
		$this->assertTrue($testField['notNull']);
		
		$testField = $this->fixtureBasic->addField('name=teste,notNull');
		$this->assertTrue($testField['notNull']);
		
		$testField = $this->fixtureBasic->addField('name=teste');
		$this->assertFalse($testField['notNull']);
	}
	
	public function testFieldCount() {
		$this->assertEquals($this->fixtureBasic->fieldCount(),0);
		$testField = $this->fixtureBasic->addField('name=teste');
		$this->assertEquals($this->fixtureBasic->fieldCount(),1);
		$testField = $this->fixtureBasic->addField('name=teste2');
		$this->assertEquals($this->fixtureBasic->fieldCount(),2);
	}
	
	public function testAddFieldNotNullFalse() {
		$testField = $this->fixtureBasic->addField('name=teste,notNull=false');
		$this->assertFalse($testField['notNull']);
	}
	
	public function testFieldByNameOk() {
		$this->fixtureBasic->addField('name=teste,label=TTT');
		$testField = $this->fixtureBasic->fieldByName('teste');
		$this->assertEquals($testField['name'],'teste');
	}

	public function testFieldByNameNull() {
		$this->assertNull($this->fixtureBasic->fieldByName('teste'));
	}

}
