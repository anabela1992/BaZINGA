<?php

require_once 'class_pg_connection_test.php';
require_once 'class_login_test.php';
require_once 'class_basic_test.php';
require_once 'class_search_test.php';
require_once 'class_crud_test.php';
// ...
 
class AllTests {
	public static function suite() {
		$suite = new PHPUnit_Framework_TestSuite('PHPUnit Framework');

		$suite->addTestSuite('classPacrudPgConnectionTest');
		$suite->addTestSuite('classPacrudLoginTest');
		$suite->addTestSuite('classBasicTest');
		$suite->addTestSuite('classSearchTest');
		$suite->addTestSuite('classCrudTest');
		// ...

		return $suite;
	}
}
?>
