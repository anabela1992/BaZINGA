<?php
require_once 'PHPUnit/Framework.php';

class classPacrudLoginTest extends PHPUnit_Framework_TestCase {
	protected $fixtureConnection;
	
	protected function setUp() {	
		// carrega as dependências
		require_once('../functions_globals.php');
		require_once('../class_pg_connection.php');
		require_once('../class_connection.php');
    	require_once('../class_login.php');
		
		// instancia a conexão
		$this->fixtureConnection = new pacrudConnection('sgdb=pgsql,dbHost=localhost,dbPort=5432,dbName=db_pacrud,dbUserName=pacrud,dbPassword=pacrud');
	}
	
    public function testLoginSucess() {
		$pLogin = new pacrudLogin('paCRUD',$this->fixtureConnection,'admin',md5('admin'));
        $this->assertTrue($pLogin->login());
    }
    
    public function testLoginFailed() {
   		$pLogin = new pacrudLogin('paCRUD',$this->fixtureConnection,'admin',md5(''));
        $this->assertFalse($pLogin->login());
    }
    
    public function testSessionRegister() {
		$pLogin = new pacrudLogin('paCRUD',$this->fixtureConnection,'admin',md5('admin'));
		$pLogin->login();
        $this->assertTrue(isset($_SESSION['paCRUD_pacrudUserName']));
        $this->assertTrue(isset($_SESSION['paCRUD_pacrudUserPassword']));
    }
    
	public function testSessionUnregister() {
		$pLogin = new pacrudLogin('paCRUD',$this->fixtureConnection,'admin',md5('admin'));
		$pLogin->login();
		$this->assertTrue($pLogin->logoff());
        $this->assertFalse(isset($_SESSION['paCRUD_pacrudUserName']));
        $this->assertFalse(isset($_SESSION['paCRUD_pacrudUserPassword']));
    }
    
    protected function tearDown() {
    	// fecha conexão com o banco de dados
    	$this->fixtureConnection->disconnect();
    }
}
?>
