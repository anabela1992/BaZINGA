<?php
require_once 'PHPUnit/Framework.php';

class classSearchTest extends PHPUnit_Framework_TestCase {
	protected $fixtureSearch;
	
	protected function setUp() {
		require_once('../functions_globals.php');
		require_once('../class_basic.php');
		require_once('../class_search.php');
		require_once('../class_grid.php');
		$this->fixtureSearch = new pacrudSearch('test','xmlFile=default.xml');
	}

	public function testConstruct() {
		$this->assertEquals($this->fixtureSearch->error,'');
		$this->assertTrue(isset($this->fixtureSearch->field));
		$this->assertEquals('test',$this->fixtureSearch->name);
	}

	public function testMakeButton() {
		$button = $this->fixtureSearch->makeButton(false);
		$buttonFinal = '<a href="javascript:test.goSearch();"><img src="/themes/default/icons/pacrudSearch.png" alt="pacrudSearch" /></a>';
	
		$this->assertEquals($button,$buttonFinal);
	}

}
