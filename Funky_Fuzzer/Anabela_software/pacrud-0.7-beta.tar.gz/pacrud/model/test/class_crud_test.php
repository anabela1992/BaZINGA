<?php
require_once 'PHPUnit/Framework.php';

class classCrudTest extends PHPUnit_Framework_TestCase {
	protected $fixtureCrud;
	
	protected function setUp() {
		require_once('../functions_globals.php');
		require_once('../class_basic.php');
		require_once('../class_grid.php');
		require_once('../class_filter.php');
		require_once('../class_search.php');
		require_once('../class_crud.php');
		require_once('../class_pg_connection.php');
		require_once('../class_connection.php');
		$this->fixtureCrud = new paCRUD('test','xmlFile=default.xml');
		$this->fixtureCrud->pConnection = new pacrudConnection('sgdb=pgsql,dbHost=localhost,dbPort=5432,dbName=pacrud,dbUserName=pacrud,dbPassword=pacrud');
	}

	public function testConstruct() {
		$this->assertFalse(!$this->fixtureCrud->pSearch);
	}
	
	public function testAddField() {
		$this->fixtureCrud->addField('name=field1');
		$this->assertTrue($this->fixtureCrud->field[0]['pk'] == false);
		
		$this->fixtureCrud->addField('name=field2,pk');
		$this->assertTrue($this->fixtureCrud->field[1]['pk'] == true);
		
		$this->fixtureCrud->addField('name=field3,fieldId=idtest');
		$this->assertTrue($this->fixtureCrud->field[2]['fieldId'] == 'idtest');
		
		$this->assertEquals($this->fixtureCrud->fieldCount(),$this->fixtureCrud->pSearch->fieldCount());
	}
	
	public function testSqlCreate() {
		$this->fixtureCrud->addField('name=field1,pk');
		$this->assertEquals($this->fixtureCrud->sqlCreate(),'INSERT INTO test (field1) VALUES (:new_field1:);');
		$this->fixtureCrud->addField('name=field2');
		$this->assertEquals($this->fixtureCrud->sqlCreate(),'INSERT INTO test (field1,field2) VALUES (:new_field1:,:new_field2:);');
	}

	public function testSqlRetrieve() {
		$this->fixtureCrud->addField('name=field1,pk');
		$this->assertEquals($this->fixtureCrud->sqlRetrieve(),'SELECT field1 FROM test WHERE field1=:new_field1:;');
		$this->fixtureCrud->addField('name=field2,pk');
		$this->assertEquals($this->fixtureCrud->sqlRetrieve(),'SELECT field1,field2 FROM test WHERE field1=:new_field1: AND field2=:new_field2:;');
		$this->fixtureCrud->addField('name=field3');
		$this->assertEquals($this->fixtureCrud->sqlRetrieve(),'SELECT field1,field2,field3 FROM test WHERE field1=:new_field1: AND field2=:new_field2:;');
	}
	
	public function testSqlUpdate() {
		$this->fixtureCrud->addField('name=field1,pk');
		$sql = 'UPDATE test SET field1=:new_field1: WHERE field1=:old_field1:;';
		$this->assertEquals($this->fixtureCrud->sqlUpdate(),$sql);
		
		$this->fixtureCrud->addField('name=field2');
		$sql = 'UPDATE test SET field1=:new_field1:,field2=:new_field2: WHERE field1=:old_field1:;';
		$this->assertEquals($this->fixtureCrud->sqlUpdate(),$sql);
	}
	
	public function testSqlDelete() {
		$this->fixtureCrud->addField('name=field1,pk');
		$sql = 'DELETE FROM test WHERE field1=:new_field1:;';
		$this->assertEquals($this->fixtureCrud->sqlDelete(),$sql);
	}
	
	public function testSqlGetSerials() {
		$this->fixtureCrud->addField('name=field1,type=serial,pk');
		$this->fixtureCrud->addField('name=field2');
		$this->fixtureCrud->addField('name=field3');
		$sql = 'SELECT field1 FROM test WHERE field2=:new_field2: AND field3=:new_field3: ORDER BY field1 DESC LIMIT 1;';
		$this->assertEquals($this->fixtureCrud->sqlGetSerials(),$sql);
	}

}
