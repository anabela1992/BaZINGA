<?php

/* *********************************************************************
 *
 *	paCRUD - PHP Ajax CRUD Framework é um framework para
 *	desenvolvimento rápido de sistemas de informação web.
 *	Copyright (C) 2010 Emerson Casas Salvador <salvaemerson@gmail.com>
 *	e Odair Rubleski <orubleski@gmail.com>
 *
 *	This file is part of paCRUD.
 *
 *	paCRUD is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 3, or (at your option)
 *	any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * ******************************************************************* */

class pacrudConnection {
	private $connection;
	public $param;
	public $encoding;

	function __construct($params) {
		$this->param = pParameters($params);
		$this->err = '';
		
		switch ($this->param['sgdb']) {
			case 'pgsql':
				$this->connection = new pacrudPgConnection($params);
				break;
			case 'mysql':
				$this->connection = new pacrudMysqlConnection($params);
				break;
			case 'sqlite3':
				$this->connection = new pacrudSqlite3Connection($params);
				break;
		}
		
		if (isset($this->param['encoding']) and $this->param['encoding'] != 'default') {
			$this->encoding = $this->param['encoding'];
		}
		else {
			$this->encoding = 'UTF-8';
		}
	}
	
	function getErr() {
		return $this->connection->getErr();
	}

	function getConnection() {
		return $this->connection->getConnection();
	}

	function connected($reconnect=false) {
		return $this->connection->connected($reconnect);
	}
	
	function sqlQuery($sql) {
	    return $this->connection->sqlQuery($sql);
	}
	
	function fetch_assoc($sql) {
		return $this->connection->fetch_assoc($sql);
	}
	
	function sql2Array($sql) {
		return $this->connection->sql2Array($sql);
	}
	
	function sqlXml($sql,$tableName) {
		return $this->connection->sqlXml($sql,$tableName);
	}
	
	function getSqlOperator($operator) {
		return $this->connection->sqlOperator[$operator];
	}

	function disconnect() {
		$this->connection->disconnect();
	}
	
	function sgdb() {
		return $this->param['sgdb'];
	}
	
	function dbType($type) {
		return $this->connection->dbType($type);
	}
	
	/*
	 * Substitui as variáveis globais em um comando sql (exemplo: substitui :pacrudUser: pelo usuário logado)
	 */
	function replacePacrudGlobals($sqlIn) {
		global $pacrudConfig;
		$sqlOut = $sqlIn;
		
		$sessionName = $pacrudConfig['appIdent'].'_pacrudUserName';
		if (!isset($_SESSION[$sessionName])) {
			session_start();
		}

		if (isset($_SESSION[$sessionName])) {
			$pacrudUser = $_SESSION[$sessionName];
			
			if ($pacrudUser != '') {
				$pacrudUser = pFormatSql($pacrudUser,'string');
				$sqlOut = str_replace(':pacrudUser:',$pacrudUser,$sqlOut);
				$sqlOut = str_replace(':new_pacrudUser:',$pacrudUser,$sqlOut);
				$sqlOut = str_replace(':old_pacrudUser:',$pacrudUser,$sqlOut);
			}
		}
		
		return $sqlOut;
	}
}
