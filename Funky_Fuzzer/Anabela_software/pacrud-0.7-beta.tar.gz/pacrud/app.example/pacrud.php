<?php
/**
 * Este arquivo contém a configuração inicial do framework, as demais configurações estão disponíveis no painel de
 * controle do paCRUD no menu Sistema.
 */

// configuração default (não remover esta linha)
if (file_exists('../config_default.php')) {
	require_once('../config_default.php');
}

/**
 * Banco de dados do paCRUD
 *
 * Esta configuração, define as opções de conectividade com o banco de dados do framework, onde serão armazenadas
 * informações sobre usuários, grupos, rotinas, menus, permissões e demais configurações.
 *
 * A configuração padrão é sqlite3, que deve atender a grande maioria dos casos e não necessita de configuração inicial.
 * Use esta opções se você esta iniciando ou simplesmente testando o framework. (Se esta for a sua escolha não é 
 * necessário alterar este arquivo).
 *
 * Para a aplicação é possível usar um banco distinto do banco de dados do framework, ou se preferir, você também pode 
 * colocar as tabelas do paCRUD Framework na mesma base de dados da sua aplicação (apenas mysql ou postgresql).
 *
 * A segui exemplos de configuração para o banco do framework em mysql e postgresql.
 * A estrutura do banco está disponivel na pasta app.example na raiz do framework.
 */
 
/* Exemplo de banco de dados pacrud com pgsql */
//$pacrudConfig['sgdb_pacrud']       = 'mysql';
//$pacrudConfig['dbHost_pacrud']     = 'localhost';
//$pacrudConfig['dbPort_pacrud']     = '3306';
//$pacrudConfig['dbName_pacrud']     = 'db_pacrud';
//$pacrudConfig['dbUserName_pacrud'] = 'root';
//$pacrudConfig['dbPassword_pacrud'] = '';

/* Exemplo de banco de dados pacrud com pgsql */
//$pacrudConfig['sgdb_pacrud']       = 'pgsql';
//$pacrudConfig['dbHost_pacrud']     = 'localhost';
//$pacrudConfig['dbPort_pacrud']     = '5432';
//$pacrudConfig['dbName_pacrud']     = 'db_pacrud';
//$pacrudConfig['dbUserName_pacrud'] = 'pacrud';
//$pacrudConfig['dbPassword_pacrud'] = '123456';


// configuração final (não remover esta linha)
require_once($pacrudConfig['pacrudPath'].'/controller/ambient.php');
