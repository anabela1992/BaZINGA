CREATE TABLE pacrud_config
(
  config_name VARCHAR(40) NOT NULL,
  config_value VARCHAR(255),
  CONSTRAINT config_pkey PRIMARY KEY (config_name)
);

CREATE TABLE pacrud_syslogin
(
  username VARCHAR(30) NOT NULL,
  fullname VARCHAR(50) NOT NULL,
  password VARCHAR(40),
  enabled VARCHAR(1) NOT NULL DEFAULT 't',
  CONSTRAINT syslogin_pkey PRIMARY KEY (username)
);

CREATE TABLE pacrud_groups
(
  enabled VARCHAR(1) NOT NULL DEFAULT 't',
  groupname VARCHAR(30) NOT NULL,
  CONSTRAINT groups_pkey PRIMARY KEY (groupname)
);

CREATE TABLE pacrud_groups_syslogin
(
  groupname VARCHAR(30) NOT NULL,
  username VARCHAR(30) NOT NULL,
  CONSTRAINT groups_syslogin_pkey PRIMARY KEY (groupname, username)
);

CREATE TABLE pacrud_routines
(
  routine VARCHAR(40) NOT NULL,
  link VARCHAR(255),
  enabled VARCHAR(1) NOT NULL DEFAULT 't',
  description text,
  CONSTRAINT routines_pkey PRIMARY KEY (routine)
);

CREATE TABLE pacrud_routines_groups
(
  routine VARCHAR(40) NOT NULL,
  groupname VARCHAR(40) NOT NULL,
  c VARCHAR(1) NOT NULL DEFAULT 'f',
  r VARCHAR(1) NOT NULL DEFAULT 'f',
  u VARCHAR(1) NOT NULL DEFAULT 'f',
  d VARCHAR(1) NOT NULL DEFAULT 'f',
  CONSTRAINT routines_groups_pkey PRIMARY KEY (routine, groupname),
  CONSTRAINT routines_groups_routine_fkey FOREIGN KEY (routine)
      REFERENCES pacrud_routines (routine) MATCH SIMPLE
      ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE pacrud_menu
(
  cod INT AUTO_INCREMENT,
  parent INT,
  caption VARCHAR(40) NOT NULL,
  routine VARCHAR(40) NOT NULL,
  icon VARCHAR(255),
  enabled VARCHAR(1) NOT NULL DEFAULT 't',
  opened VARCHAR(1) NOT NULL DEFAULT 't',
  CONSTRAINT menu_pkey PRIMARY KEY (cod),
  CONSTRAINT menu_parent_fkey FOREIGN KEY (parent)
      REFERENCES pacrud_menu (cod) MATCH SIMPLE
      ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT menu_routine_fkey FOREIGN KEY (routine)
      REFERENCES pacrud_routines (routine) MATCH SIMPLE
      ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT menu_parent_key UNIQUE (parent, caption)
);

CREATE TABLE pacrud_obj_search
(
  obj_name VARCHAR(40) NOT NULL,
  obj_title VARCHAR(100),
  obj_tablename VARCHAR(40) NOT NULL,
  obj_pagelines INT,
  obj_debug VARCHAR(1) NOT NULL DEFAULT 'f',
  obj_modal VARCHAR(1) NOT NULL DEFAULT 't',
  obj_schema VARCHAR(40),
  obj_autofilter VARCHAR(1) NOT NULL DEFAULT 't',
  CONSTRAINT obj_search_pkey PRIMARY KEY (obj_name )
);

CREATE TABLE pacrud_obj_search_field
(
  obj_name VARCHAR(40) NOT NULL,
  field_name VARCHAR(40) NOT NULL,
  field_label VARCHAR(40),
  field_type VARCHAR(40) NOT NULL,
  field_pk VARCHAR(1) NOT NULL,
  field_visible VARCHAR(1) NOT NULL,
  field_order INT NOT NULL DEFAULT 0,
  CONSTRAINT obj_search_field_pkey PRIMARY KEY (obj_name , field_name ),
  CONSTRAINT obj_search_field_obj_name_fkey FOREIGN KEY (obj_name)
      REFERENCES pacrud_obj_search (obj_name) MATCH SIMPLE
      ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE pacrud_obj_crud
(
  obj_name VARCHAR(40) NOT NULL,
  obj_parent1xn VARCHAR(40),
  obj_tablename VARCHAR(40),
  obj_title VARCHAR(100),
  obj_schema VARCHAR(40),
  obj_pagelines INT,
  obj_routine VARCHAR(40),
  obj_permission VARCHAR(40),
  obj_list VARCHAR(1) NOT NULL,
  obj_autoclick VARCHAR(1) NOT NULL,
  obj_debug VARCHAR(1) NOT NULL,
  obj_drawform VARCHAR(1) NOT NULL,
  obj_parent1x1 VARCHAR(1),
  obj_include_head VARCHAR(100),
  obj_include_footer VARCHAR(100),
  obj_capslock VARCHAR(1) NOT NULL,
  obj_onduplicate VARCHAR(40),
  CONSTRAINT obj_crud_pkey PRIMARY KEY (obj_name ),
  CONSTRAINT obj_crud_obj_parent1xn_fkey FOREIGN KEY (obj_parent1xn)
      REFERENCES pacrud_obj_crud (obj_name) MATCH SIMPLE
      ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE pacrud_obj_crud_1x1
(
  obj_name VARCHAR(40) NOT NULL,
  obj_name_parent1x1 VARCHAR(40) NOT NULL,
  obj_parent_field_condition VARCHAR(40),
  obj_condition_value VARCHAR(100),
  CONSTRAINT obj_crud_1x1_pkey PRIMARY KEY (obj_name),
  CONSTRAINT obj_crud_1x1_obj_parent1x1_fkey FOREIGN KEY (obj_name_parent1x1)
      REFERENCES pacrud_obj_crud (obj_name) MATCH SIMPLE
      ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE pacrud_obj_crud_field
(
  obj_name VARCHAR(40) NOT NULL,
  field_pk VARCHAR(1) NOT NULL,
  field_name VARCHAR(40) NOT NULL,
  field_label VARCHAR(40),
  field_type VARCHAR(40) NOT NULL,
  field_fieldid VARCHAR(40),
  field_search VARCHAR(40),
  field_formcode VARCHAR(255),
  field_readonly VARCHAR(1) NOT NULL,
  field_nocreate VARCHAR(1) NOT NULL,
  field_nohtml VARCHAR(1) NOT NULL,
  field_notnull VARCHAR(1) NOT NULL,
  field_visible VARCHAR(1) NOT NULL,
  field_size VARCHAR(40),
  field_default VARCHAR(255),
  field_virtual VARCHAR(1) NOT NULL,
  field_capslock VARCHAR(1) NOT NULL,
  field_order INT NOT NULL DEFAULT 0,
  CONSTRAINT obj_crud_field_pkey PRIMARY KEY (obj_name, field_name),
  CONSTRAINT obj_crud_field_field_search_fkey FOREIGN KEY (field_search)
      REFERENCES pacrud_obj_search (obj_name) MATCH SIMPLE
      ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT obj_crud_field_obj_name_fkey FOREIGN KEY (obj_name)
      REFERENCES pacrud_obj_crud (obj_name) MATCH SIMPLE
      ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE VIEW pacrud_v_menu_base AS
		SELECT 
			cod,
			(SELECT caption FROM pacrud_menu WHERE cod=(SELECT parent FROM pacrud_menu WHERE cod=(SELECT parent FROM pacrud_menu WHERE cod=(SELECT parent FROM pacrud_menu WHERE cod=m5.parent)))) as level1,
			(SELECT caption FROM pacrud_menu WHERE cod=(SELECT parent FROM pacrud_menu WHERE cod=(SELECT parent FROM pacrud_menu WHERE cod=m5.parent))) as level2,
			(SELECT caption FROM pacrud_menu WHERE cod=(SELECT parent FROM pacrud_menu WHERE cod=m5.parent)) as level3,
			(SELECT caption FROM pacrud_menu WHERE cod=m5.parent) as level4,
			caption as level5,
			5 as nivel,
			parent,
			routine
		FROM pacrud_menu m5
		WHERE m5.cod IN (
			SELECT cod FROM pacrud_menu WHERE parent IN (
				SELECT cod FROM pacrud_menu WHERE parent IN (
					SELECT cod FROM pacrud_menu WHERE parent IN (
						SELECT cod FROM pacrud_menu WHERE parent IN (
							SELECT cod FROM pacrud_menu WHERE parent IS NULL
						)
					)
				)
			)
		)

		UNION

		SELECT 
			cod,
			(SELECT caption FROM pacrud_menu WHERE cod=(SELECT parent FROM pacrud_menu WHERE cod=(SELECT parent FROM pacrud_menu WHERE cod=m4.parent))) as level1,
			(SELECT caption FROM pacrud_menu WHERE cod=(SELECT parent FROM pacrud_menu WHERE cod=m4.parent)) as level2,
			(SELECT caption FROM pacrud_menu WHERE cod=m4.parent) as level3,
			caption as level4,
			CAST('_' as CHAR) as level5,
			4 as nivel,
			parent,
			routine
		FROM pacrud_menu m4
		WHERE m4.cod IN (
			SELECT cod FROM pacrud_menu WHERE parent IN (
				SELECT cod FROM pacrud_menu WHERE parent IN (
					SELECT cod FROM pacrud_menu WHERE parent IN (
						SELECT cod FROM pacrud_menu WHERE parent IS NULL
					)
				)
			)
		)

		UNION

		SELECT 
			cod,
			(SELECT caption FROM pacrud_menu WHERE cod=(SELECT parent FROM pacrud_menu WHERE cod=m3.parent)) as level1,
			(SELECT caption FROM pacrud_menu WHERE cod=m3.parent) as level2,
			caption as level3,
			CAST('_' as CHAR) as level4,
			CAST(NULL as CHAR) as level5,
			3 as nivel,
			parent,
			routine
		FROM pacrud_menu m3
		WHERE m3.cod IN (
			SELECT cod FROM pacrud_menu WHERE parent IN (
				SELECT cod FROM pacrud_menu WHERE parent IN (
					SELECT cod FROM pacrud_menu WHERE parent IS NULL
				)
			)
		)

		UNION

		SELECT 
			cod,
			(SELECT caption FROM pacrud_menu WHERE cod=m2.parent) as level1,
			caption as level2,
			CAST('_' as CHAR) as level3,
			CAST(NULL as CHAR) as level4,
			CAST(NULL as CHAR) as level5,
			2 as nivel,
			parent,
			routine
		FROM pacrud_menu m2
		WHERE m2.cod IN (
			SELECT cod FROM pacrud_menu WHERE parent IN (
				SELECT cod FROM pacrud_menu WHERE parent IS NULL
			)
		)

		UNION

		SELECT 
			cod,
			caption as level1,
			CAST('_' as CHAR) as level2,
			CAST(NULL as CHAR) as level3,
			CAST(NULL as CHAR) as level4,
			CAST(NULL as CHAR) as level5,
			1 as nivel,
			parent,
			routine
		FROM pacrud_menu m1
		WHERE m1.parent IS NULL
;

CREATE VIEW pacrud_v_menu AS
SELECT
	cod,
	CASE
		WHEN level2='_' THEN level1
		WHEN level3='_' THEN CONCAT(level1,' > ',level2)
		WHEN level4='_' THEN CONCAT(level1,' > ',level2,' > ',level3)
		WHEN level5='_' THEN CONCAT(level1,' > ',level2,' > ',level3,' > ',level4)
		ELSE CONCAT(level1,' > ',level2,' > ',level3,' > ',level4,' > ',level5)
	END as tree,
	routine
FROM pacrud_v_menu_base
ORDER BY level1,level2,level3,level4,level5;

INSERT INTO pacrud_routines (routine, link, enabled, description) VALUES ('pacrud_groups', NULL, 't', NULL);
INSERT INTO pacrud_routines (routine, link, enabled, description) VALUES ('pacrud_controlPanel', NULL, 't', NULL);
INSERT INTO pacrud_routines (routine, link, enabled, description) VALUES ('pacrud_changePassword', NULL, 't', NULL);
INSERT INTO pacrud_routines (routine, link, enabled, description) VALUES ('pacrud_about', NULL, 't', NULL);
INSERT INTO pacrud_routines (routine, link, enabled, description) VALUES ('pacrud_system', NULL, 't', NULL);
INSERT INTO pacrud_routines (routine, link, enabled, description) VALUES ('pacrud_users', NULL, 't', NULL);
INSERT INTO pacrud_routines (routine, link, enabled, description) VALUES ('pacrud_routines', NULL, 't', NULL);
INSERT INTO pacrud_routines (routine, link, enabled, description) VALUES ('pacrud_submission', NULL, 't', NULL);
INSERT INTO pacrud_routines (routine, link, enabled, description) VALUES ('pacrud_access_control', NULL, 't', NULL);
INSERT INTO pacrud_routines (routine, link, enabled, description) VALUES ('pacrud_update', NULL, 't', NULL);
INSERT INTO pacrud_routines (routine, link, enabled, description) VALUES ('pacrud_obj_search', NULL, 't', NULL);
INSERT INTO pacrud_routines (routine, link, enabled, description) VALUES ('pacrud_obj_crud', NULL, 't', NULL);

INSERT INTO pacrud_menu (parent, caption, routine, icon, enabled, opened) VALUES (NULL, 'SISTEMA', 'pacrud_system', 'view/images/icons/example.png', 't', 't');
INSERT INTO pacrud_menu (parent, caption, routine, icon, enabled, opened) VALUES (1, 'Alterar Senha', 'pacrud_changePassword', 'view/images/icons/key.png', 't', 't');
INSERT INTO pacrud_menu (parent, caption, routine, icon, enabled, opened) VALUES (1, 'Atualização', 'pacrud_update', 'view/images/icons/system.png', 't', 't');
INSERT INTO pacrud_menu (parent, caption, routine, icon, enabled, opened) VALUES (1, 'Controle de Acesso', 'pacrud_access_control', 'view/images/icons/key.png', 't', 't');
INSERT INTO pacrud_menu (parent, caption, routine, icon, enabled, opened) VALUES (4, 'Grupos de Usuários', 'pacrud_groups', 'view/images/icons/users.png', 't', 't');
INSERT INTO pacrud_menu (parent, caption, routine, icon, enabled, opened) VALUES (4, 'Permissões e Menus', 'pacrud_routines', 'view/images/icons/users.png', 't', 't');
INSERT INTO pacrud_menu (parent, caption, routine, icon, enabled, opened) VALUES (4, 'Usuários', 'pacrud_users', 'view/images/icons/users.png', 't', 't');
INSERT INTO pacrud_menu (parent, caption, routine, icon, enabled, opened) VALUES (1, 'Instruções iniciais', 'pacrud_submission', 'view/images/icons/exclamation.png', 't', 't');
INSERT INTO pacrud_menu (parent, caption, routine, icon, enabled, opened) VALUES (1, 'Objetos paCRUD', 'pacrud_obj_crud', 'view/images/icons/system.png', 't', 't');
INSERT INTO pacrud_menu (parent, caption, routine, icon, enabled, opened) VALUES (1, 'Objetos pacrudSearch', 'pacrud_obj_search', 'view/images/icons/system.png', 't', 't');
INSERT INTO pacrud_menu (parent, caption, routine, icon, enabled, opened) VALUES (1, 'Painel de Controle', 'pacrud_controlPanel', 'view/images/icons/system.png', 't', 't');
INSERT INTO pacrud_menu (parent, caption, routine, icon, enabled, opened) VALUES (1, 'Sobre o paCRUD', 'pacrud_about', 'view/images/icons/exclamation.png', 't', 't');

INSERT INTO pacrud_syslogin(username, fullname, password) VALUES ('admin', 'Administrador do sistema', '21232f297a57a5a743894a0e4a801fc3');

INSERT INTO pacrud_groups(enabled, groupname) VALUES ('t', 'sysadmin');
INSERT INTO pacrud_groups_syslogin(groupname, username) VALUES ('sysadmin', 'admin');

INSERT INTO pacrud_routines_groups(routine, groupname, c, r, u, d) VALUES ('pacrud_groups', 'sysadmin', 't', 't', 't', 't');
INSERT INTO pacrud_routines_groups(routine, groupname, c, r, u, d) VALUES ('pacrud_controlPanel', 'sysadmin', 't', 't', 't', 't');
INSERT INTO pacrud_routines_groups(routine, groupname, c, r, u, d) VALUES ('pacrud_changePassword', 'sysadmin', 't', 't', 't', 't');
INSERT INTO pacrud_routines_groups(routine, groupname, c, r, u, d) VALUES ('pacrud_about', 'sysadmin', 't', 't', 't', 't');
INSERT INTO pacrud_routines_groups(routine, groupname, c, r, u, d) VALUES ('pacrud_system', 'sysadmin', 't', 't', 't', 't');
INSERT INTO pacrud_routines_groups(routine, groupname, c, r, u, d) VALUES ('pacrud_users', 'sysadmin', 't', 't', 't', 't');
INSERT INTO pacrud_routines_groups(routine, groupname, c, r, u, d) VALUES ('pacrud_routines', 'sysadmin', 't', 't', 't', 't');
INSERT INTO pacrud_routines_groups(routine, groupname, c, r, u, d) VALUES ('pacrud_submission', 'sysadmin', 't', 't', 't', 't');
INSERT INTO pacrud_routines_groups(routine, groupname, c, r, u, d) VALUES ('pacrud_access_control', 'sysadmin', 't', 't', 't', 't');
INSERT INTO pacrud_routines_groups(routine, groupname, c, r, u, d) VALUES ('pacrud_update', 'sysadmin', 't', 't', 't', 't');
INSERT INTO pacrud_routines_groups(routine, groupname, c, r, u, d) VALUES ('pacrud_obj_search', 'sysadmin', 't', 't', 't', 't');
INSERT INTO pacrud_routines_groups(routine, groupname, c, r, u, d) VALUES ('pacrud_obj_crud', 'sysadmin', 't', 't', 't', 't');

INSERT INTO pacrud_groups(enabled, groupname) VALUES ('t', 'change_password');
INSERT INTO pacrud_routines_groups(routine, groupname, c, r, u, d) VALUES ('pacrud_system', 'change_password', 'f', 't', 'f', 'f');
INSERT INTO pacrud_routines_groups(routine, groupname, c, r, u, d) VALUES ('pacrud_changePassword', 'change_password', 'f', 't', 't', 'f');

