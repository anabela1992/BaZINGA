<html><head><title>Directory Reader</title>

<style type="text/css">
.link		{font-family:arial;
		 font-size: 14px;
		 color:FFFFFF;
		 font-weight: heavy;
		 text-decoration: none;}
.link2		{font-family:arial;
		 font-size: 12px;
		 color:990000;
		 text-decoration: none;}
</style>
</head>


<body bgcolor="#9999BB">


<TABLE WIDTH=100% CELLPADDING="0" CELLSPACING="0">
  <TR>
    <TD WIDTH=50% ALIGN="LEFT" VALIGN="TOP">

<?php
$dirname = "../call";
$dh = opendir($dirname) or die ("This script is on strike and refuses to work.");

while (!(($file = readdir($dh)) === false ) ) {
    if (is_file("$dirname/$file")) {
	echo "$file &nbsp;&nbsp;&nbsp;- <a target=\"_top\" href=\"changer.php?edit=$file\"><font class=\"link\"><b>edit</b></font></a> &nbsp;&nbsp;&nbsp;- <a href=\"promptdestroyer.php?delete=$file\"><font class=\"link2\">delete</font></a><br>";
    }
    
}
closedir($dh);
?>

    </TD>
    <TD WIDTH=50% VALIGN="TOP">


<TABLE WIDTH="300" ALIGN="CENTER" CELLSPACING="0" CELLPADDING="0"><TR><TD ALIGN="CENTER">
<fieldset style="border-color:#777799">
<legend><font style="font-size:8pt;font-family:verdana;color:333355;font-weight:bold;">Create a new file:</font></legend>
	<form action="creater.php" method="POST">
	<input style="background: 777799;color:ffffff;" type="text" name="newfile">
	<input type="submit" value="Create">
	</form>
</fieldset></TD></TR></TABLE>

   </TD>
  </TR>
</TABLE>

</body>
</html> 