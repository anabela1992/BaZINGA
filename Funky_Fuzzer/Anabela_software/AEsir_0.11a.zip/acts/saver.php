<html><body bgcolor="#9999BB">

<?php

$filename = "../call/".$_GET[page];
$fp = fopen($filename, "w") or die ("Error performing write to $filename");
$towrite = $_POST[change];
$towrite = stripslashes($towrite);
fwrite($fp, $towrite);
fclose($fp);

echo "<table height=100% width=100%><tr><td align=center valign=center>";
echo "<font style='font-family:arial;font-size:32px;text-decoration:none;color:ffffff;'>Save Successful</font><br/><br/>";
echo "<br/><br/><a style='font-family:arial;font-size:18px;text-decoration:none;color:ffffff;' href=\"changer.php\">Click to Continue</a>";
echo "</td></tr></table>";
?>
</BODY></HTML>