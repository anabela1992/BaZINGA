<BODY BGCOLOR="#9999BB">
<center>
<?php

echo "<br/><font style='font-family:verdana;color:ffffff;font-size:12px;'><b>Are you sure you want to delete <i>$_GET[delete]</i>?</b>"; 
echo "<br/><br/><br/>";
echo "<form action='destroyer.php?delete=$_GET[delete]' method='POST'>";
echo "<input type='submit' name='confirm' value='Yes, delete it.'>";
echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
echo "<input type='reset' name='cancel' value='No, Keep it!' onClick='history.go(-1)'>";
echo "</form>";
?>
</center>
</BODY>