
<BODY BGCOLOR="#9999BB">
<CENTER>
<?php

$newfilename = "../call/" . $_POST[newfile] . ".txt";
echo "Finished Creating: $_POST[newfile]";
echo "<br/><br/><br/>";
touch($newfilename);
echo "<a style='font-family:arial;font-size:24px;text-decoration:none;color:ffffff;' href=\"reader.php\"><b>Back to Reader</b></a>";
?>
</BODY>