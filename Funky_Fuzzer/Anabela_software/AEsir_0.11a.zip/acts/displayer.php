<html>
<head>

<TITLE>[: RCR Business Ventures :]</TITLE>
<META name="resource-type" content="document">
<META name="description" content="RCR Business Ventures is a progressive business to busines development organization.  We offer support services, business products, buiness and sustainable practice consulting, and technological support."> 
<META name="keywords" content="rcr, business, ventures, florida, lakeland, tampa, orlando, develop, development, org, organization, co, comp, company, corp, corporation, consulting, help, small, biz, entrepreneur, entrapranure, sustainable, sustainability, technology, support, consult, servics, products, b2b, to"> 
<META HTTP-EQUIV="Content-Language" CONTENT="en">
<META NAME="robots" CONTENT="nofollow"> 




</head>

<body bgcolor="#ffffff">
<P ALIGN="RIGHT">
<A HREF="changer.php">Edit this Page</A>
<HR><BR><BR>

<TABLE WIDTH="300" ALIGN="CENTER" CELLPADDING="0" CELLSPACING="0">
  <TR>
    <TD>

<?php

$switcheroo = $_GET[view];

if ($switcheroo == "") {

		$filename = "../call/index.txt";
		$fp = fopen($filename, "r") or die ("Can not open pod bay doors.");
		while (!feof($fp)) {
			$line = fgets($fp);
			$line = stripslashes($line);
			echo "$line";
		}
	
} else {
		$filename = "../call/" . $_GET[view] . ".txt";
		$fp = fopen($filename, "r") or die("Can not open pod bay doors.");
		while (!feof($fp)) {
			$line = fgets($fp);
			$line = stripslashes($line);
			echo "$line";
		}
}


?>

<BR/><BR/>
    </TD>
  </TR>
</TABLE>


<BR><BR><HR>
<P ALIGN="RIGHT">
<A HREF="changer.php">Edit this Page</A>


</body>