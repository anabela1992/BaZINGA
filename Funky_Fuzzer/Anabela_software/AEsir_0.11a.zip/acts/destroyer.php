<body bgcolor="#9999BB">
<center>
<?php

$destroyfilename = "../call/" . $_GET[delete];
echo "Finished Destroying: $destroyfilename";
echo "<br/><br/><br/>";
unlink($destroyfilename);
echo "<a style='font-family:arial;font-size:24px;text-decoration:none;color:ffffff;' href=\"reader.php\"><b>Back to Reader</b></a>";
?>

</center>
</body>