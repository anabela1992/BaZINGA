

<HTML><HEAD><TITLE>{: RCR �sir :} - [Access and Editing System for Information Recall]</TITLE>

<style type="text/css">
.2button	{font-size:10px;
		 font-family:arial;
		 height:20;
		 width:70}
.2text	{font-size:10px;
	 font-family:arial;
	 color:#000000}
.indicator 	{font-size:12px;
		 font-family:arial;
		 color:ffffff;}
</style>


<script language="JavaScript" type="text/javascript" src="richtext_compressed.js"></script>

</HEAD>
<BODY onload="document.editor.change.focus();" bgcolor="#777777" BACKGROUND="background.jpg" TOPMARGIN="0" LEFTMARGIN="0" RIGHTMARGIN"0" SCROLL="NO">
<IFRAME HEIGHT="150" WIDTH=100% SRC="reader.php" ALIGN=CENTER></IFRAME>

<?php
$savename = $_GET[edit];
echo "<TABLE WIDTH=100% ALIGN=CENTER CELLPADDING='0' CELLSPACING='0' BGCOLOR='444444'><TR><TD>";
echo "<font class=\"indicator\">&nbsp;You are working on file: <b>$savename</b></font>";
echo "</TD></TR></TABLE>";
echo "<form name='editor' action='saver.php?page=$_GET[edit]' method='POST'>";
?>

<script language="JavaScript" type="text/javascript">
<!--
function submitForm() {
updateRTE('change'); 
}
//Usage: initRTE(imagesPath, includesPath, cssFile)
initRTE("images/", "", "");
//-->
</script>

<BR/>

<TABLE WIDTH="920" ALIGN="CENTER" CELLPADDING="0" CELLSPACING="0">
  <TR>
    <TD WIDTH="800" ALIGN="RIGHT">

<? 
$thetext = file_get_contents("../call/".$_GET[edit]); 
$thetext = addslashes(preg_replace('`[\r\n]`','',$thetext));

?> 
<script language="JavaScript" type="text/javascript"> 
writeRichText('change', '<?=$thetext?>', 800, 250, true, false); 
</script> 


    </TD>
    <TD WIDTH="120" VALIGN="TOP">

	<TABLE WIDTH="120" CELLPADDING="0" CELLSPACING="0" BGCOLOR="#9999BB"><TR><TD ALIGN="CENTER">
	<input type="submit" value="PUBLISH!" onClick="submitForm()" />
	</TD></TR></TABLE>
	<TABLE WIDTH="120" HEIGHT="280" CELLPADDING="0" CELLSPACING="0" BGCOLOR="#666688"><TR><TD ALIGN="RIGHT">
	</TD></TR></TABLE><BR/>


    </TD>
  </TR>
</TABLE>


</FORM>






</BODY></HTML>

