============================================================================================
For ease of reading, resize this window
to at least the width of the line above.




                                 ==  ==  ==  ==  ==  ==  ==
                                //\\//\\//\\//\\//\\//\\//\\
                                }}                        {{
                                }}                        {{
                                }}   RCR AEsir Ver 1.10   {{
                                }}                        {{
                                }}           by           {{
                                }}                        {{
                                }}  R. Chase Razabdouski  {{
                                }}                        {{
                                }}                        {{
			        \\//\\//\\//\\//\\//\\//\\//
				 ==  ==  ==  ==  ==  ==  ==





=====INTRODUCTION===========================================================================

RCR AEsir is the name of this particular software hodgepodge.  Actually, the AEsir is only
one part, the backend.  As a joking refrence to Nordic mythology, the actual lines of code
in the index.php file to make everything come together are called the Vanir.  The joke, of
course, is that the AEsir and Vanir are the two groups of gods in Norse belief systems.

AEsir (war gods who bring oddly bring unity) is an acronym for "Access and Editing System 
for Information Recall"

Vanir (rich fertility gods of peace) is an acronym for"Visual Access Node for Information
Recall"






=====FILE OVERVIEW==========================================================================


01) .htaccess - This file defines the location of the .htpasswd file to secure access
		to the PHP files.  In the future, if the AEsir is continued, this feature
		will be abandoned and the login will be based entirely in PHP by accessing
		a MySQL database with a proper username/password combination.  By doing so,
		it will be possible to run ALL sites utilizing AEsir from one set of scripts
		and files rather than redundantly requiring one copy for each site.

02) background.jpg - The textured background file to make the interface for the AEsir look
		all nice and pretty.

03) blank.html - A file that is a part of the JScript RichText editor integrated into the 
		AEsir.  Since I did not create the WYSIWYG editor, I will not explain it, 
		plus if curious, the file contents are self explainatory HTML markup.

04) changer.php - The file which loads the WYSIWYG Rich Text editor and loads it up with 
		the contents of a text file based on which file the user selected to edit
		while inside the AEsir interface's "Reader" section (See reader.php). 
		Changer and Reader are the primary two parts of the AEsir interface.

05) creater.php - When the user tells AEsir to create a file within the Reader section of
		the interface, the desired file name they enter is passed to this script 
		which does the actual work of making the new file on the server and 
		presents a link to return to the Reader view to select another file to edit
		or the option to create yet another new file.

06) destroyer.php - If the user verifies the desire to delete a file in promptdestroy.php, 
		the name of the file is sent to this script which deletes the unwanted file
		and then presents a link to return to the Reader.

07) displayer.php - The Vanir code, in its most basic form, is archived in this file for safe
		keeping.  It's presence here with the AEsir is to ensure that if anything
		were to happen to a site's index.php page, the somewhat complex Vanir code
		could quickly and easily be accessed to minimize down time.  Maybe the 
		Norse joke should be continued by calling this file Freyja, as she was a 
		Vanir goddess of love and sexuality who lived among the AEsir.

08) index.html - An outdated file that I am too lazy to change.  Once a successful log-in 
		occurs, this file sits there and basically says "Welcome!" and requires the
		user to click once more to access the main AEsir interface.  All of this is
		completely unnecessary, but I have no desire to change it until I know the
		future of the AEsir project overall.

09) insert_link.html - Another file from the Rich Text editor.  This is the one that
		collects information about a link from the user in order to auto-generate
		the HTML code for that link.  

10) insert_table.html - Similar to above, but this one gathers information on what type of
		HTML table to autogenerate.

11) palette.html - Yet another Rich Text editor file.  This one displays colors that the 
		user can select to shade items with.

12) promptdestroyer.php - When the user tells AEsire to delete a file within the Reader 
		section of the interface, the unwanted file name is retained as a variable
		ready to be passed on to the destroyer.php file.  This particular script
		asks for the user to confirm or deny the wish to delete a particular file
		before passing on the variable or throwing it out, respectively.

13) protection.php - Something from a long time ago that I've been too lazy to delete until
		I know the future of the AEsir project.  This is a left over script from 
		the former password protection script.  Take a look if you're bored and you
		can see just how weak the previous protection was and why we switched to 
		server-based protection.  The next step will be to phase to security based
		on matching a username password combination in a database in order to easily
		access more user information and to reduce the reliance on a particular
		set of server abilities.

14) reader.php - The file you've all been waiting for!  This one pulls the directory listing
		of the /call directory and then populates each item with the ability to be
		pulled up and edited by the Rich Text editor or sent to promptdestroyer.php
		for deletion confirmation.  A secondary function of this script is to
		accept the filename variable to be passed to creator.php if the user decides
		to create a new txt file in the /call directory.

15) richtext_compressed.js - Self explainatory.  The compressed JScript file for the WYSIWYG
		Rich Text editor.  I've never looked at it, and don't care to much yet.  I
		have never extremely liked this editor, but it's the best I could get to 
		integrate in a reasonable amount of time.  If the project is warranted for
		continuation, I will eventually change to another editor and customize from
		that point forward.

16) rte.css - The Cascading Style Sheet information for the Rich Text editor.

17) saver.php - When a file is modified in the Rich Text editor, the user can choose to save
		those changes by pressing the "Publish" button to the right of the editor.
		When this is done, all the contents of the editor is taken and used to over-	
		write the contents of the active file that was edited.  Currently this
		script displays a full page message and link to return to edit another file,
		but in the future the return to the main screen will be made automatic. 






=====VERSION HISTORY========================================================================


Version 1.0

Initial development of the RCR AEsir CMS.  Launched with the ability to edit files in the 
"call" directory, create new files, and delete unwanted files.  Implemented first on RCR.biz
then on client sites FuLLFlip.com and JohnFoxxMusic.com.


Version 1.10

Security update.  Removes the PHP password script and places all editing files in one 
directory to be protected by .htaccess on the serverside.  This decesion converts the 
AEsir into a CMS for those with moderate technical skills and above only.  This ain't no 
Mambo we're runnin' here!  Also, RCR Business Ventures becomes RCR BeenBusted.

============================================================================================